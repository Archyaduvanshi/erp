package com.erp.backend.platform.service;

import java.time.LocalDate;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class PlatformProvisioningService {
    private final JdbcTemplate jdbc;

    public PlatformProvisioningService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public void assertRegistrationEnabled() {
        String value = jdbc.queryForObject("select setting_value from platform_settings where setting_key = 'registrationEnabled'", String.class);
        if (!Boolean.parseBoolean(value)) throw new IllegalStateException("New institute registration is temporarily disabled.");
    }

    public void provisionTrial(Long instituteId) {
        String defaultPlan = setting("defaultPlan", "BASIC");
        int trialDays = Integer.parseInt(setting("defaultTrialDays", "14"));
        jdbc.update("""
                insert into institute_subscriptions(institute_id, plan_id, status, billing_cycle,
                    start_date, end_date, amount, change_reason)
                select ?, p.id, 'TRIAL', 'CUSTOM', ?, ?, 0, 'Automatic registration trial'
                from subscription_plans p where p.code = ? and p.status = 'ACTIVE'
                """, instituteId, LocalDate.now(), LocalDate.now().plusDays(trialDays), defaultPlan);
    }

    private String setting(String key, String fallback) {
        return jdbc.query("select setting_value from platform_settings where setting_key = ?", rs -> rs.next() ? rs.getString(1) : fallback, key);
    }
}
