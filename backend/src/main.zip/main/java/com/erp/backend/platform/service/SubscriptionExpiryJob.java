package com.erp.backend.platform.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SubscriptionExpiryJob {
    private final JdbcTemplate jdbc;

    public SubscriptionExpiryJob(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Scheduled(cron = "0 10 0 * * *", zone = "Asia/Kolkata")
    public void expireEndedSubscriptions() {
        jdbc.update("""
                update institute_subscriptions
                set status = 'EXPIRED', updated_at = now(), version = version + 1
                where status in ('TRIAL','ACTIVE','PAST_DUE') and end_date < current_date
                """);
    }
}
