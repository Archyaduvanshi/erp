package com.erp.backend.platform.service;

import static com.erp.backend.platform.dto.PlatformDtos.*;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.erp.backend.auth.AuthPrincipal;
import com.erp.backend.exception.ResourceNotFoundException;
import com.erp.backend.platform.FeatureCode;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class PlatformConsoleService {
    private static final Set<Integer> PAGE_SIZES = Set.of(25, 50, 100);
    private static final Map<String, String> INSTITUTE_SORTS = Map.of(
            "registeredAt", "i.registered_date", "instituteName", "i.institute_name",
            "studentCount", "student_count", "subscriptionExpiry", "subscription_expiry"
    );
    private final JdbcTemplate jdbc;
    private final NamedParameterJdbcTemplate namedJdbc;
    private final PlatformAuditService audit;

    public PlatformConsoleService(JdbcTemplate jdbc, NamedParameterJdbcTemplate namedJdbc, PlatformAuditService audit) {
        this.jdbc = jdbc;
        this.namedJdbc = namedJdbc;
        this.audit = audit;
    }

    public Overview overview() {
        Map<String, Object> row = jdbc.queryForMap("""
                select
                  (select count(*) from institutes) total_institutes,
                  (select count(*) from institutes where status = 'ACTIVE') active_institutes,
                  (select count(distinct institute_id) from institute_subscriptions where status = 'TRIAL' and end_date >= current_date) trial_institutes,
                  (select count(*) from institutes where status = 'SUSPENDED') suspended_institutes,
                  (select count(distinct institute_id) from institute_subscriptions where status = 'EXPIRED' or end_date < current_date) expired_institutes,
                  (select count(*) from students where lower(coalesce(status,'active')) <> 'archived') total_students,
                  (select count(*) from teachers where lower(coalesce(status,'active')) <> 'archived') total_teachers,
                  (select count(*) from institute_subscriptions where status = 'ACTIVE' and end_date >= current_date) active_subscriptions,
                  (select count(*) from institute_subscriptions where status in ('TRIAL','ACTIVE') and end_date between current_date and current_date + 7) expiring_7,
                  (select count(*) from institute_subscriptions where status in ('TRIAL','ACTIVE') and end_date between current_date and current_date + 30) expiring_30,
                  (select count(*) from cashfree_merchant_accounts where payments_enabled = true) gateway_enabled,
                  (select coalesce(sum(total_amount),0) from platform_invoices where status='PAID' and paid_at >= date_trunc('month', current_date)) monthly_revenue,
                  (select coalesce(sum(total_amount),0) from platform_invoices where status='PAID' and paid_at >= date_trunc('year', current_date)) yearly_revenue
                """);
        List<RecentInstitute> recent = jdbc.query("""
                select id, institute_name, username, status, registered_date
                from institutes order by registered_date desc limit 6
                """, (rs, n) -> new RecentInstitute(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), timestamp(rs, 5)));
        List<ExpiringSubscription> expiring = jdbc.query("""
                select i.id, i.institute_name, p.name, s.end_date, (s.end_date-current_date)
                from institute_subscriptions s join institutes i on i.id=s.institute_id
                join subscription_plans p on p.id=s.plan_id
                where s.status in ('TRIAL','ACTIVE') and s.end_date between current_date and current_date + 30
                order by s.end_date asc limit 8
                """, (rs, n) -> new ExpiringSubscription(rs.getLong(1), rs.getString(2), rs.getString(3), date(rs, 4), rs.getLong(5)));
        return new Overview(number(row, "total_institutes"), number(row, "active_institutes"), number(row, "trial_institutes"),
                number(row, "suspended_institutes"), number(row, "expired_institutes"), number(row, "total_students"),
                number(row, "total_teachers"), number(row, "active_subscriptions"), number(row, "expiring_7"),
                number(row, "expiring_30"), number(row, "gateway_enabled"), decimal(row, "monthly_revenue"),
                decimal(row, "yearly_revenue"), recent, expiring);
    }

    public PageResponse<InstituteRow> institutes(int requestedPage, int requestedSize, String search, String status,
                                                  String type, String plan, String state, String city,
                                                  String subscriptionStatus, String gatewayStatus,
                                                  LocalDate registeredFrom, LocalDate registeredTo,
                                                  LocalDate expiryFrom, LocalDate expiryTo, String sort, String direction) {
        int page = Math.max(0, requestedPage);
        int size = PAGE_SIZES.contains(requestedSize) ? requestedSize : 25;
        List<String> where = new ArrayList<>(List.of("1=1"));
        MapSqlParameterSource params = new MapSqlParameterSource();
        if (StringUtils.hasText(search)) {
            where.add("lower(concat_ws(' ',i.institute_name,i.username,i.email,i.contact,i.affiliation_no,i.city,i.state)) like :search");
            params.addValue("search", "%" + search.trim().toLowerCase() + "%");
        }
        addEquals(where, params, "i.status", "status", status);
        addEquals(where, params, "i.type", "type", type);
        addEquals(where, params, "i.state", "state", state);
        addEquals(where, params, "i.city", "city", city);
        addEquals(where, params, "p.code", "plan", plan);
        addEquals(where, params, "s.status", "subscriptionStatus", subscriptionStatus);
        if (StringUtils.hasText(gatewayStatus)) {
            where.add("upper(coalesce(g.onboarding_status,'NOT_CONFIGURED')) = :gatewayStatus");
            params.addValue("gatewayStatus", gatewayStatus.trim().toUpperCase());
        }
        addDateRange(where, params, "i.registered_date", "registeredFrom", registeredFrom, true);
        addDateRange(where, params, "i.registered_date", "registeredTo", registeredTo, false);
        addDateRange(where, params, "s.end_date", "expiryFrom", expiryFrom, true);
        addDateRange(where, params, "s.end_date", "expiryTo", expiryTo, false);
        String clause = String.join(" and ", where);
        String base = """
                from institutes i
                left join lateral (select sx.* from institute_subscriptions sx where sx.institute_id=i.id order by sx.created_at desc limit 1) s on true
                left join subscription_plans p on p.id=s.plan_id
                left join cashfree_merchant_accounts g on g.institute_id=i.id
                left join lateral (select count(*) student_count from students st where st.institute_id=i.id and lower(coalesce(st.status,'active')) <> 'archived') sc on true
                left join lateral (select count(*) teacher_count from teachers t where t.institute_id=i.id and lower(coalesce(t.status,'active')) <> 'archived') tc on true
                """;
        Long total = namedJdbc.queryForObject("select count(*) " + base + " where " + clause, params, Long.class);
        String order = INSTITUTE_SORTS.getOrDefault(sort, "i.registered_date");
        String dir = "asc".equalsIgnoreCase(direction) ? "asc" : "desc";
        params.addValue("limit", size).addValue("offset", page * size);
        List<InstituteRow> content = namedJdbc.query("""
                select i.id,i.institute_name,i.username,i.type,i.city,i.state,i.status,p.name,
                  sc.student_count,tc.teacher_count,
                  (select count(*) from (
                    select pf.feature_code from subscription_plan_features pf
                    where pf.plan_id=s.plan_id and not exists(select 1 from institute_feature_overrides ox where ox.institute_id=i.id and ox.feature_code=pf.feature_code)
                    union all select ox.feature_code from institute_feature_overrides ox where ox.institute_id=i.id and ox.enabled=true
                  ) ef) enabled_features,
                  i.registered_date,s.end_date,s.status,coalesce(g.onboarding_status,'NOT_CONFIGURED') gateway_status
                """ + base + " where " + clause + " order by " + order + " " + dir + " limit :limit offset :offset",
                params, (rs, n) -> mapInstituteRow(rs));
        long count = total == null ? 0 : total;
        return new PageResponse<>(content, page, size, count, (int) Math.ceil((double) count / size));
    }

    public InstituteDetail institute(Long id) {
        return jdbc.query("""
                select i.id,i.institute_name,i.username,i.type,i.affiliation_no,i.affiliated_from,i.email,i.contact,
                  i.website,i.address,i.city,i.state,i.pincode,i.status,i.status_reason,i.registered_date,
                  (select count(*) from students x where x.institute_id=i.id and lower(coalesce(x.status,'active')) <> 'archived'),
                  (select count(*) from teachers x where x.institute_id=i.id and lower(coalesce(x.status,'active')) <> 'archived'),
                  (select count(*) from school_classes x where x.institute_id=i.id),
                  (select count(*) from class_sections x where x.institute_id=i.id and lower(coalesce(x.status,'active')) <> 'archived'),
                  p.name,s.status,s.end_date,
                  (select count(*) from (
                    select pf.feature_code from subscription_plan_features pf where pf.plan_id=s.plan_id
                      and not exists(select 1 from institute_feature_overrides o where o.institute_id=i.id and o.feature_code=pf.feature_code)
                    union all select o.feature_code from institute_feature_overrides o where o.institute_id=i.id and o.enabled=true
                  ) ef),
                  case when g.id is null then null else 'CASHFREE' end,coalesce(g.onboarding_status,'NOT_CONFIGURED'),coalesce(g.payments_enabled,false),i.version
                from institutes i
                left join lateral (select sx.* from institute_subscriptions sx where sx.institute_id=i.id order by sx.created_at desc limit 1) s on true
                left join subscription_plans p on p.id=s.plan_id
                left join cashfree_merchant_accounts g on g.institute_id=i.id
                where i.id=?
                """, rs -> rs.next() ? mapInstituteDetail(rs) : null, id);
    }

    public List<FeatureAccess> features(Long instituteId) {
        ensureInstitute(instituteId);
        Map<String, Map<String, Object>> rows = new HashMap<>();
        jdbc.query("""
                select f.code,
                  exists(select 1 from subscription_plan_features pf where pf.plan_id=s.plan_id and pf.feature_code=f.code) plan_enabled,
                  o.enabled override_enabled,o.reason,o.updated_at,o.version
                from (values ('STUDENT_MANAGEMENT'),('TEACHER_MANAGEMENT'),('COURSE_SUBJECT'),('ATTENDANCE'),
                  ('TIMETABLE'),('EXAMINATION'),('RESULT'),('FEES'),('LIBRARY'),('HOSTEL'),('TRANSPORT'),
                  ('SALARY'),('REPORTS'),('NOTICES'),('HOLIDAYS'),('CASHBOOK'),('LIVE_TRANSPORT_TRACKING')) f(code)
                left join lateral (select sx.plan_id from institute_subscriptions sx where sx.institute_id=? order by sx.created_at desc limit 1) s on true
                left join institute_feature_overrides o on o.institute_id=? and o.feature_code=f.code
                """, rs -> {
            Map<String, Object> value = new HashMap<>();
            value.put("plan", rs.getBoolean(2));
            value.put("override", rs.getObject(3));
            value.put("reason", rs.getString(4));
            value.put("updated", timestamp(rs, 5));
            value.put("version", rs.getObject(6));
            rows.put(rs.getString(1), value);
        }, instituteId, instituteId);
        return FeatureCode.registry().stream().map(def -> {
            Map<String, Object> row = rows.get(def.code());
            boolean planEnabled = Boolean.TRUE.equals(row.get("plan"));
            Boolean override = (Boolean) row.get("override");
            return new FeatureAccess(def.code(), def.legacyKey(), def.label(), planEnabled, override,
                    override == null ? planEnabled : override, override == null ? "PLAN" : "MANUAL_OVERRIDE",
                    (String) row.get("reason"), (LocalDateTime) row.get("updated"), asLong(row.get("version")));
        }).toList();
    }

    @Transactional
    public FeatureAccess updateFeature(Long instituteId, FeatureUpdate payload, AuthPrincipal actor, HttpServletRequest request) {
        ensureInstitute(instituteId);
        FeatureCode code = FeatureCode.valueOf(payload.featureCode().trim().toUpperCase());
        Map<String, Object> old = jdbc.query("select enabled,reason,version from institute_feature_overrides where institute_id=? and feature_code=?",
                rs -> rs.next() ? Map.of("enabled", rs.getBoolean(1), "reason", safe(rs.getString(2)), "version", rs.getLong(3)) : Map.of(), instituteId, code.name());
        Long currentVersion = asLong(old.get("version"));
        if (currentVersion != null && (payload.version() == null || !currentVersion.equals(payload.version()))) {
            throw new OptimisticLockingFailureException("Feature was updated by another platform user.");
        }
        int changed = jdbc.update("""
                insert into institute_feature_overrides(institute_id,feature_code,enabled,reason,updated_by_platform_user_id)
                values (?,?,?,?,?)
                on conflict (institute_id,feature_code) do update set enabled=excluded.enabled,reason=excluded.reason,
                  updated_by_platform_user_id=excluded.updated_by_platform_user_id,updated_at=now(),version=institute_feature_overrides.version+1
                """, instituteId, code.name(), payload.enabled(), payload.reason().trim(), actor.accountId());
        if (changed != 1) throw new OptimisticLockingFailureException("Feature was updated by another platform user.");
        audit.record(actor.accountId(), payload.enabled() ? "FEATURE_ENABLED" : "FEATURE_DISABLED", "FEATURE", code.name(), instituteId,
                old, Map.of("enabled", payload.enabled()), payload.reason(), request.getRemoteAddr(), request.getHeader("User-Agent"));
        return features(instituteId).stream().filter(item -> item.code().equals(code.name())).findFirst().orElseThrow();
    }

    public List<Plan> plans() {
        Map<Long, List<String>> features = new HashMap<>();
        jdbc.query("select plan_id,feature_code from subscription_plan_features order by feature_code", (org.springframework.jdbc.core.RowCallbackHandler) rs ->
                features.computeIfAbsent(rs.getLong(1), ignored -> new ArrayList<>()).add(rs.getString(2)));
        return jdbc.query("select id,code,name,monthly_price,yearly_price,max_students,max_teachers,max_users,max_storage_mb,trial_days,status,version from subscription_plans order by monthly_price,id",
                (rs, n) -> new Plan(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getBigDecimal(4),rs.getBigDecimal(5),
                        integer(rs,6),integer(rs,7),integer(rs,8),integer(rs,9),rs.getInt(10),rs.getString(11),
                        features.getOrDefault(rs.getLong(1),List.of()),rs.getLong(12)));
    }

    @Transactional
    public Plan savePlan(PlanPayload payload, AuthPrincipal actor, HttpServletRequest request) {
        String code = payload.code().trim().toUpperCase();
        List<String> featureCodes = payload.features() == null ? List.of() : payload.features().stream()
                .map(value -> FeatureCode.valueOf(value.trim().toUpperCase()).name()).distinct().toList();
        Long id;
        Object old = null;
        if (payload.id() == null) {
            id = jdbc.queryForObject("""
                    insert into subscription_plans(code,name,monthly_price,yearly_price,max_students,max_teachers,max_users,max_storage_mb,trial_days,status)
                    values (?,?,?,?,?,?,?,?,?,?) returning id
                    """, Long.class, code, payload.name().trim(), payload.monthlyPrice(), payload.yearlyPrice(), payload.maxStudents(),
                    payload.maxTeachers(), payload.maxUsers(), payload.maxStorageMb(), payload.trialDays(), payload.status().trim().toUpperCase());
        } else {
            old = plans().stream().filter(plan -> plan.id().equals(payload.id())).findFirst()
                    .orElseThrow(() -> new ResourceNotFoundException("Subscription plan not found."));
            int changed = jdbc.update("""
                    update subscription_plans set code=?,name=?,monthly_price=?,yearly_price=?,max_students=?,max_teachers=?,
                      max_users=?,max_storage_mb=?,trial_days=?,status=?,updated_at=now(),version=version+1
                    where id=? and version=?
                    """, code,payload.name().trim(),payload.monthlyPrice(),payload.yearlyPrice(),payload.maxStudents(),payload.maxTeachers(),
                    payload.maxUsers(),payload.maxStorageMb(),payload.trialDays(),payload.status().trim().toUpperCase(),payload.id(),payload.version());
            if (changed != 1) throw new OptimisticLockingFailureException("Plan was updated by another platform user.");
            id = payload.id();
        }
        jdbc.update("delete from subscription_plan_features where plan_id=?", id);
        featureCodes.forEach(feature -> jdbc.update("insert into subscription_plan_features(plan_id,feature_code) values (?,?)", id, feature));
        Plan saved = plans().stream().filter(plan -> plan.id().equals(id)).findFirst().orElseThrow();
        audit.record(actor.accountId(), payload.id()==null?"PLAN_CREATED":"PLAN_UPDATED", "SUBSCRIPTION_PLAN", String.valueOf(id), null,
                old, saved, payload.reason(), request.getRemoteAddr(), request.getHeader("User-Agent"));
        return saved;
    }

    public List<Subscription> subscriptions(Long instituteId) {
        ensureInstitute(instituteId);
        return jdbc.query("""
                select s.id,s.institute_id,s.plan_id,p.code,p.name,s.status,s.billing_cycle,s.start_date,s.end_date,
                  s.amount,s.currency,s.auto_renew,s.change_reason,s.created_at,s.version
                from institute_subscriptions s join subscription_plans p on p.id=s.plan_id
                where s.institute_id=? order by s.created_at desc
                """, (rs,n)->mapSubscription(rs), instituteId);
    }

    @Transactional
    public Subscription changeSubscription(Long instituteId, SubscriptionChange payload, AuthPrincipal actor, HttpServletRequest request) {
        ensureInstitute(instituteId);
        if (payload.endDate().isBefore(payload.startDate())) throw new IllegalArgumentException("Subscription end date cannot be before start date.");
        List<Subscription> old = subscriptions(instituteId);
        jdbc.update("""
                update institute_subscriptions set status='CANCELLED',updated_at=now(),version=version+1
                where institute_id=? and status in ('TRIAL','ACTIVE','PAST_DUE')
                """, instituteId);
        Long id = jdbc.queryForObject("""
                insert into institute_subscriptions(institute_id,plan_id,status,billing_cycle,start_date,end_date,amount,currency,auto_renew,change_reason,created_by_platform_user_id)
                values (?,?,?,?,?,?,?,?,?,?,?) returning id
                """, Long.class, instituteId,payload.planId(),normalizeStatus(payload.status()),normalizeCycle(payload.billingCycle()),
                payload.startDate(),payload.endDate(),payload.amount(),"INR",payload.autoRenew(),payload.reason().trim(),actor.accountId());
        Subscription current = subscriptions(instituteId).stream().filter(value -> value.id().equals(id)).findFirst().orElseThrow();
        audit.record(actor.accountId(), "SUBSCRIPTION_CHANGED", "SUBSCRIPTION", String.valueOf(id), instituteId,
                old.isEmpty()?null:old.get(0), current, payload.reason(), request.getRemoteAddr(), request.getHeader("User-Agent"));
        return current;
    }

    public Usage usage(Long instituteId) {
        ensureInstitute(instituteId);
        Map<String,Object> r=jdbc.queryForMap("""
                select
                  (select count(*) from students where institute_id=? and lower(coalesce(status,'active'))<>'archived') students,
                  (select count(*) from teachers where institute_id=? and lower(coalesce(status,'active'))<>'archived') teachers,
                  (select count(*) from user_accounts where institute_id=? and status='ACTIVE') accounts,
                  (select count(*) from school_classes where institute_id=?) classes,
                  (select count(*) from class_sections where institute_id=? and lower(coalesce(status,'active'))<>'archived') sections,
                  (select count(*) from exams where institute_id=?) exams,
                  (select count(*) from library_books where institute_id=?) books,
                  (select count(*) from hostel_residents where institute_id=? and lower(coalesce(status,'active'))='active') residents,
                  (select count(*) from transport_assignments where institute_id=? and lower(coalesce(status,'active'))='active') transport
                """, instituteId,instituteId,instituteId,instituteId,instituteId,instituteId,instituteId,instituteId,instituteId);
        return new Usage(instituteId,number(r,"students"),number(r,"teachers"),number(r,"accounts"),number(r,"classes"),
                number(r,"sections"),number(r,"exams"),number(r,"books"),number(r,"residents"),number(r,"transport"));
    }

    public Gateway gateway(Long instituteId) {
        ensureInstitute(instituteId);
        return jdbc.query("""
                select merchant_id,onboarding_status,product_status,payments_enabled,updated_at
                from cashfree_merchant_accounts where institute_id=?
                """, rs -> rs.next() ? new Gateway(instituteId,"CASHFREE",mask(rs.getString(1)),rs.getString(2),rs.getString(3),rs.getBoolean(4),timestamp(rs,5))
                : new Gateway(instituteId,"NOT_CONFIGURED",null,"NOT_CONFIGURED",null,false,null), instituteId);
    }

    public PageResponse<Invoice> invoices(int page, int size, Long instituteId, String status) {
        int safePage=Math.max(0,page), safeSize=PAGE_SIZES.contains(size)?size:25;
        String where=" where (? is null or v.institute_id=?) and (?='' or v.status=?) ";
        Long count=jdbc.queryForObject("select count(*) from platform_invoices v"+where,Long.class,instituteId,instituteId,safe(status),safe(status));
        List<Invoice> content=jdbc.query("""
                select v.id,v.invoice_number,v.institute_id,i.institute_name,p.name,s.start_date,s.end_date,
                  v.amount,v.tax,v.total_amount,v.due_date,v.paid_at,v.status,v.payment_reference,v.notes,v.created_at,v.version
                from platform_invoices v join institutes i on i.id=v.institute_id
                left join institute_subscriptions s on s.id=v.subscription_id left join subscription_plans p on p.id=s.plan_id
                """+where+" order by v.created_at desc limit ? offset ?",(rs,n)->mapInvoice(rs),instituteId,instituteId,safe(status),safe(status),safeSize,safePage*safeSize);
        long total=count==null?0:count;
        return new PageResponse<>(content,safePage,safeSize,total,(int)Math.ceil((double)total/safeSize));
    }

    @Transactional
    public Invoice createInvoice(InvoicePayload payload, AuthPrincipal actor, HttpServletRequest request) {
        ensureInstitute(payload.instituteId());
        BigDecimal total = payload.amount().add(payload.tax());
        Long id = jdbc.queryForObject("""
                insert into platform_invoices(institute_id,subscription_id,invoice_number,amount,tax,total_amount,due_date,status,payment_reference,notes)
                values (?,?,?,?,?,?,?,?,?,?) returning id
                """, Long.class,payload.instituteId(),payload.subscriptionId(),payload.invoiceNumber().trim(),payload.amount(),payload.tax(),total,
                payload.dueDate(),payload.status().trim().toUpperCase(),payload.paymentReference(),payload.notes());
        Invoice saved = jdbc.query("""
                select v.id,v.invoice_number,v.institute_id,i.institute_name,p.name,s.start_date,s.end_date,
                  v.amount,v.tax,v.total_amount,v.due_date,v.paid_at,v.status,v.payment_reference,v.notes,v.created_at,v.version
                from platform_invoices v join institutes i on i.id=v.institute_id
                left join institute_subscriptions s on s.id=v.subscription_id left join subscription_plans p on p.id=s.plan_id
                where v.id=?
                """, rs -> rs.next()?mapInvoice(rs):null,id);
        audit.record(actor.accountId(),"INVOICE_CREATED","PLATFORM_INVOICE",String.valueOf(id),payload.instituteId(),null,saved,
                "Platform subscription invoice created",request.getRemoteAddr(),request.getHeader("User-Agent"));
        return saved;
    }

    public List<InternalNote> notes(Long instituteId) {
        ensureInstitute(instituteId);
        return jdbc.query("""
                select n.id,n.institute_id,n.platform_user_id,u.display_name,n.note,n.created_at
                from institute_internal_notes n join platform_users u on u.id=n.platform_user_id
                where n.institute_id=? order by n.created_at desc limit 100
                """,(rs,n)->new InternalNote(rs.getLong(1),rs.getLong(2),rs.getLong(3),rs.getString(4),rs.getString(5),timestamp(rs,6)),instituteId);
    }

    @Transactional
    public InternalNote addNote(Long instituteId, NotePayload payload, AuthPrincipal actor, HttpServletRequest request) {
        ensureInstitute(instituteId);
        Long id=jdbc.queryForObject("insert into institute_internal_notes(institute_id,platform_user_id,note) values (?,?,?) returning id",
                Long.class,instituteId,actor.accountId(),payload.note().trim());
        audit.record(actor.accountId(),"INTERNAL_NOTE_ADDED","INSTITUTE_NOTE",String.valueOf(id),instituteId,null,null,
                "Internal support note added",request.getRemoteAddr(),request.getHeader("User-Agent"));
        return notes(instituteId).stream().filter(note->note.id().equals(id)).findFirst().orElseThrow();
    }

    public PageResponse<AuditRow> audits(int page,int size,Long instituteId,String action) {
        int safePage=Math.max(0,page),safeSize=PAGE_SIZES.contains(size)?size:25;
        String where=" where (? is null or a.target_institute_id=?) and (?='' or a.action=?) ";
        Long count=jdbc.queryForObject("select count(*) from platform_audit_logs a"+where,Long.class,instituteId,instituteId,safe(action),safe(action));
        List<AuditRow> content=jdbc.query("""
                select a.id,a.platform_user_id,u.display_name,a.action,a.target_type,a.target_id,a.target_institute_id,
                  i.institute_name,a.reason,a.old_value_json,a.new_value_json,a.ip_address,a.created_at
                from platform_audit_logs a join platform_users u on u.id=a.platform_user_id
                left join institutes i on i.id=a.target_institute_id
                """+where+" order by a.created_at desc limit ? offset ?",(rs,n)->new AuditRow(rs.getLong(1),rs.getLong(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),
                        nullableLong(rs,7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12),timestamp(rs,13)),
                instituteId,instituteId,safe(action),safe(action),safeSize,safePage*safeSize);
        long total=count==null?0:count;
        return new PageResponse<>(content,safePage,safeSize,total,(int)Math.ceil((double)total/safeSize));
    }

    public List<PlatformSetting> settings() {
        return jdbc.query("select setting_key,setting_value,updated_at from platform_settings order by setting_key",
                (rs,n)->new PlatformSetting(rs.getString(1),rs.getString(2),timestamp(rs,3)));
    }

    @Transactional
    public List<PlatformSetting> updateSettings(SettingsUpdate payload,AuthPrincipal actor,HttpServletRequest request) {
        validateSettings(payload);
        Map<String,String> updates=new LinkedHashMap<>();
        updates.put("defaultTrialDays",payload.defaultTrialDays()); updates.put("defaultPlan",payload.defaultPlan());
        updates.put("platformSupportEmail",payload.platformSupportEmail()); updates.put("platformSupportPhone",payload.platformSupportPhone());
        updates.put("maintenanceBanner",payload.maintenanceBanner()); updates.put("registrationEnabled",payload.registrationEnabled());
        Map<String,String> old=new LinkedHashMap<>(); settings().forEach(value->old.put(value.key(),value.value()));
        updates.forEach((key,value)->{ if(value!=null) jdbc.update("""
                insert into platform_settings(setting_key,setting_value,updated_by_platform_user_id) values (?,?,?)
                on conflict(setting_key) do update set setting_value=excluded.setting_value,updated_by_platform_user_id=excluded.updated_by_platform_user_id,updated_at=now()
                """,key,value.trim(),actor.accountId()); });
        audit.record(actor.accountId(),"PLATFORM_SETTINGS_CHANGED","PLATFORM_SETTINGS","global",null,old,updates,payload.reason(),request.getRemoteAddr(),request.getHeader("User-Agent"));
        return settings();
    }

    @Transactional
    public InstituteDetail changeInstituteStatus(Long instituteId,String status,StatusChange payload,AuthPrincipal actor,HttpServletRequest request) {
        InstituteDetail old=requiredInstitute(instituteId);
        if (payload.version()!=null && payload.version()!=old.version()) throw new OptimisticLockingFailureException("Institute was updated by another platform user.");
        int changed=jdbc.update("update institutes set status=?,status_reason=?,suspended_at=case when ?='SUSPENDED' then now() else null end,updated_at=now(),version=version+1 where id=? and version=?",
                status,payload.reason().trim(),status,instituteId,old.version());
        if(changed!=1) throw new OptimisticLockingFailureException("Institute was updated by another platform user.");
        InstituteDetail next=requiredInstitute(instituteId);
        audit.record(actor.accountId(),"SUSPENDED".equals(status)?"INSTITUTE_SUSPENDED":"INSTITUTE_REACTIVATED","INSTITUTE",String.valueOf(instituteId),instituteId,
                Map.of("status",old.status()),Map.of("status",next.status()),payload.reason(),request.getRemoteAddr(),request.getHeader("User-Agent"));
        return next;
    }

    private InstituteDetail requiredInstitute(Long id){InstituteDetail value=institute(id);if(value==null)throw new ResourceNotFoundException("Institute not found with id: "+id);return value;}
    private void ensureInstitute(Long id){requiredInstitute(id);}
    private InstituteRow mapInstituteRow(ResultSet rs)throws SQLException{return new InstituteRow(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getLong(9),rs.getLong(10),rs.getLong(11),timestamp(rs,12),date(rs,13),rs.getString(14),rs.getString(15));}
    private InstituteDetail mapInstituteDetail(ResultSet rs)throws SQLException{return new InstituteDetail(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14),rs.getString(15),timestamp(rs,16),rs.getLong(17),rs.getLong(18),rs.getLong(19),rs.getLong(20),rs.getString(21),rs.getString(22),date(rs,23),rs.getLong(24),rs.getString(25),rs.getString(26),rs.getBoolean(27),rs.getLong(28));}
    private Subscription mapSubscription(ResultSet rs)throws SQLException{return new Subscription(rs.getLong(1),rs.getLong(2),rs.getLong(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),date(rs,8),date(rs,9),rs.getBigDecimal(10),rs.getString(11),rs.getBoolean(12),rs.getString(13),timestamp(rs,14),rs.getLong(15));}
    private Invoice mapInvoice(ResultSet rs)throws SQLException{return new Invoice(rs.getLong(1),rs.getString(2),rs.getLong(3),rs.getString(4),rs.getString(5),date(rs,6),date(rs,7),rs.getBigDecimal(8),rs.getBigDecimal(9),rs.getBigDecimal(10),date(rs,11),timestamp(rs,12),rs.getString(13),rs.getString(14),rs.getString(15),timestamp(rs,16),rs.getLong(17));}
    private void addEquals(List<String>w,MapSqlParameterSource p,String col,String key,String value){if(StringUtils.hasText(value)){w.add("lower("+col+")=lower(:"+key+")");p.addValue(key,value.trim());}}
    private void addDateRange(List<String>w,MapSqlParameterSource p,String col,String key,LocalDate value,boolean from){if(value!=null){w.add(col+(from?" >= ":" < ")+":"+key+(from?"":" + interval '1 day'"));p.addValue(key,value);}}
    private long number(Map<String,Object>r,String key){Object v=r.get(key);return v instanceof Number n?n.longValue():0;}
    private BigDecimal decimal(Map<String,Object>r,String key){Object v=r.get(key);return v instanceof BigDecimal b?b:new BigDecimal(String.valueOf(v==null?0:v));}
    private Integer integer(ResultSet rs,int index)throws SQLException{int v=rs.getInt(index);return rs.wasNull()?null:v;}
    private Long nullableLong(ResultSet rs,int index)throws SQLException{long v=rs.getLong(index);return rs.wasNull()?null:v;}
    private Long asLong(Object value){return value instanceof Number n?n.longValue():null;}
    private LocalDate date(ResultSet rs,int index)throws SQLException{Date v=rs.getDate(index);return v==null?null:v.toLocalDate();}
    private LocalDateTime timestamp(ResultSet rs,int index)throws SQLException{Timestamp v=rs.getTimestamp(index);return v==null?null:v.toLocalDateTime();}
    private String safe(String value){return value==null?"":value;}
    private String mask(String value){if(!StringUtils.hasText(value)||value.length()<5)return value;return value.substring(0,3)+"***"+value.substring(value.length()-3);}
    private String normalizeStatus(String value){String v=value.trim().toUpperCase();if(!Set.of("TRIAL","ACTIVE","PAST_DUE","EXPIRED","CANCELLED").contains(v))throw new IllegalArgumentException("Invalid subscription status.");return v;}
    private String normalizeCycle(String value){String v=value.trim().toUpperCase();if(!Set.of("MONTHLY","YEARLY","CUSTOM").contains(v))throw new IllegalArgumentException("Invalid billing cycle.");return v;}
    private void validateSettings(SettingsUpdate payload) {
        if (StringUtils.hasText(payload.defaultTrialDays())) {
            try {
                int days = Integer.parseInt(payload.defaultTrialDays().trim());
                if (days < 0 || days > 365) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Default trial days must be between 0 and 365.");
            }
        }
        if (StringUtils.hasText(payload.registrationEnabled())
                && !Set.of("true", "false").contains(payload.registrationEnabled().trim().toLowerCase())) {
            throw new IllegalArgumentException("Registration enabled must be true or false.");
        }
        if (StringUtils.hasText(payload.defaultPlan())) {
            Integer count = jdbc.queryForObject("select count(*) from subscription_plans where code=? and status='ACTIVE'",
                    Integer.class, payload.defaultPlan().trim().toUpperCase());
            if (count == null || count == 0) throw new IllegalArgumentException("Default plan must be an active plan code.");
        }
    }
}
