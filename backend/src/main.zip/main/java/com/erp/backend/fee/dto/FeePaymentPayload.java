package com.erp.backend.fee.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record FeePaymentPayload(
        String structureId,
        Long studentId,
        String transactionId,
        String gatewayRef,
        String mode,
        String paymentStatus,
        String paymentTarget,
        @NotNull @Positive BigDecimal paidAmount,
        LocalDate paymentDate,
        String coverageLabel,
        String activeFromMonth,
        Integer billedMonthsCount,
        String billingType,
        String receiptNumber,
        String taxBreakdown,
        BigDecimal balanceRemaining,
        String downloadLink,
        String idempotencyKey,
        Long academicSessionId,
        List<String> coveredMonths,
        List<String> resolvedMonths,
        List<Map<String, Object>> allocations
) {
}
