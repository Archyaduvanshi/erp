package com.erp.backend.platform.service;

import com.erp.backend.platform.FeatureCode;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.erp.backend.settings.dto.FeatureAccessResponse;

@Service
public class EntitlementService {
    private final JdbcTemplate jdbc;

    public EntitlementService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public boolean hasFeature(Long instituteId, FeatureCode feature) {
        if (instituteId == null || feature == null) return false;
        Boolean allowed = jdbc.queryForObject("""
                select exists(
                    select 1
                    from institutes i
                    join institute_subscriptions s on s.institute_id = i.id
                      and s.status in ('TRIAL','ACTIVE') and s.end_date >= current_date
                    where i.id = ? and i.status = 'ACTIVE'
                      and coalesce(
                        (select o.enabled from institute_feature_overrides o
                         where o.institute_id = i.id and o.feature_code = ?),
                        exists(select 1 from subscription_plan_features pf
                               where pf.plan_id = s.plan_id and pf.feature_code = ?)
                      ) = true
                )
                """, Boolean.class, instituteId, feature.name(), feature.name());
        return Boolean.TRUE.equals(allowed);
    }

    public void validateFeature(Long instituteId, FeatureCode feature) {
        if (!hasFeature(instituteId, feature)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "This feature is not enabled for the institute subscription.");
        }
    }

    public void validateInstituteAccess(Long instituteId) {
        Boolean allowed = jdbc.queryForObject("""
                select exists(
                  select 1 from institutes i
                  join institute_subscriptions s on s.institute_id=i.id
                    and s.status in ('TRIAL','ACTIVE') and s.end_date >= current_date
                  where i.id = ? and i.status = 'ACTIVE'
                )
                """, Boolean.class, instituteId);
        if (!Boolean.TRUE.equals(allowed)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Institute access is suspended or archived.");
        }
    }

    public List<FeatureAccessResponse> effectivePermissions(Long instituteId) {
        Set<String> enabled = new HashSet<>(jdbc.queryForList("""
                select f.code
                from (values ('STUDENT_MANAGEMENT'),('TEACHER_MANAGEMENT'),('COURSE_SUBJECT'),('ATTENDANCE'),
                  ('TIMETABLE'),('EXAMINATION'),('RESULT'),('FEES'),('LIBRARY'),('HOSTEL'),('TRANSPORT'),
                  ('SALARY'),('REPORTS'),('NOTICES'),('HOLIDAYS'),('CASHBOOK'),('LIVE_TRANSPORT_TRACKING')) f(code)
                join lateral (select s.plan_id from institute_subscriptions s where s.institute_id=?
                  and s.status in ('TRIAL','ACTIVE') and s.end_date>=current_date order by s.created_at desc limit 1) s on true
                left join institute_feature_overrides o on o.institute_id=? and o.feature_code=f.code
                where coalesce(o.enabled, exists(select 1 from subscription_plan_features pf where pf.plan_id=s.plan_id and pf.feature_code=f.code))
                """, String.class, instituteId, instituteId));
        return FeatureCode.registry().stream()
                .map(feature -> new FeatureAccessResponse(feature.legacyKey(), null, null, null, "read_write",
                        enabled.contains(feature.code()), false, null))
                .toList();
    }
}
