export const db = {
  // Get currently logged-in college from session
  getTenantId: () => {
    const session = JSON.parse(localStorage.getItem('active_session'));
    return session ? session.username : null;
  },

  // Save data isolated by College (e.g., "mit_students")
  save: (module, data) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return null;

    const key = `${tenantId}_${module}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = [...existing, { ...data, id: Date.now(), createdAt: new Date().toISOString() }];
    
    localStorage.setItem(key, JSON.stringify(updated));
    return updated;
  },

  update: (module, id, updater) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return null;

    const key = `${tenantId}_${module}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.map((entry) => {
      if (String(entry.id) !== String(id)) return entry;
      const nextValue = typeof updater === 'function' ? updater(entry) : { ...entry, ...updater };
      return {
        ...entry,
        ...nextValue,
        updatedAt: new Date().toISOString(),
      };
    });

    localStorage.setItem(key, JSON.stringify(updated));
    return updated;
  },

  // Get only this college's data
  getAll: (module) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return [];
    return JSON.parse(localStorage.getItem(`${tenantId}_${module}`)) || [];
  },

  // Logout / Clear Session
  logout: () => {
    localStorage.removeItem('active_session');
    window.location.href = '/login';
  }
};
