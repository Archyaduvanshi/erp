const currencyFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

export const getMonthKey = (value = new Date()) => {
  const date = value instanceof Date ? value : new Date(value);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
};

export const getMonthLabel = (monthKey) => {
  if (!monthKey) return 'Not available';
  const [year, month] = monthKey.split('-');
  return new Date(Number(year), Number(month) - 1, 1).toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  });
};

export const formatSalary = (value) => {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount <= 0) return 'Not set';
  return currencyFormatter.format(amount);
};

export const normalizeTeacherSalary = (teacher) => {
  if (!teacher) return null;
  const salary = Number(teacher?.salary);
  const joiningDateSource = teacher?.joiningDate || teacher?.createdAt || new Date().toISOString();
  return {
    ...teacher,
    salary: Number.isFinite(salary) && salary > 0 ? salary : '',
    joiningDate: String(joiningDateSource).slice(0, 10),
    paymentHistory: Array.isArray(teacher?.paymentHistory) ? teacher.paymentHistory : [],
  };
};

export const buildSalaryTimeline = (teacher, now = new Date()) => {
  const normalizedTeacher = normalizeTeacherSalary(teacher);
  if (!normalizedTeacher) return [];
  if (!normalizedTeacher.joiningDate) return [];

  const startDate = new Date(normalizedTeacher.joiningDate);
  const timeline = [];
  const pointer = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth(), 1);

  while (pointer <= end) {
    const monthKey = getMonthKey(pointer);
    const payment = normalizedTeacher.paymentHistory.find((entry) => entry.monthKey === monthKey) || null;

    timeline.push({
      monthKey,
      label: getMonthLabel(monthKey),
      amount: payment?.amount ?? normalizedTeacher.salary,
      isPaid: Boolean(payment),
      paidOn: payment?.paidOn || '',
      note: payment?.note || '',
    });

    pointer.setMonth(pointer.getMonth() + 1);
  }

  return timeline.reverse();
};

export const getCurrentMonthSalaryStatus = (teacher, now = new Date()) => {
  const monthKey = getMonthKey(now);
  const timeline = buildSalaryTimeline(teacher, now);
  return timeline.find((entry) => entry.monthKey === monthKey) || null;
};

export const markSalaryPaid = (teacher, monthKey, paidOn = new Date().toISOString()) => {
  const normalizedTeacher = normalizeTeacherSalary(teacher);
  if (!normalizedTeacher) return teacher;
  const existingPayments = normalizedTeacher.paymentHistory.filter((entry) => entry.monthKey !== monthKey);

  return {
    ...normalizedTeacher,
    paymentHistory: [
      ...existingPayments,
      {
        monthKey,
        amount: normalizedTeacher.salary || 0,
        paidOn,
      },
    ].sort((a, b) => a.monthKey.localeCompare(b.monthKey)),
  };
};
