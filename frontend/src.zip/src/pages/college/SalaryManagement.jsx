import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Banknote, Briefcase, CalendarDays, CheckCircle2, IndianRupee, Save, Search } from 'lucide-react';
import { db } from '../../utils/db';
import { buildSalaryTimeline, formatSalary, getMonthKey, getMonthLabel, markSalaryPaid, normalizeTeacherSalary } from '../../utils/salaryUtils';

const SalaryManagement = () => {
  const navigate = useNavigate();
  const [teachers, setTeachers] = useState(() => db.getAll('teachers').map(normalizeTeacherSalary));
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMonth, setSelectedMonth] = useState(getMonthKey(new Date()));
  const [drafts, setDrafts] = useState({});

  const filteredTeachers = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    return teachers.filter((teacher) => {
      if (!query) return true;
      const fullName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.toLowerCase();
      return (
        fullName.includes(query) ||
        String(teacher.employeeId || '').toLowerCase().includes(query) ||
        String(teacher.teacherSystemId || '').toLowerCase().includes(query) ||
        String(teacher.assignedClass || '').toLowerCase().includes(query)
      );
    });
  }, [searchTerm, teachers]);

  const payrollByStatus = useMemo(() => {
    return filteredTeachers.reduce(
      (groups, teacher) => {
        const selectedMonthEntry = buildSalaryTimeline(teacher).find((entry) => entry.monthKey === selectedMonth);
        const isPaid = Boolean(selectedMonthEntry?.isPaid);

        if (isPaid) {
          groups.paid.push({ teacher, selectedMonthEntry });
        } else {
          groups.pending.push({ teacher, selectedMonthEntry });
        }

        return groups;
      },
      { paid: [], pending: [] },
    );
  }, [filteredTeachers, selectedMonth]);

  const totalPayroll = filteredTeachers.reduce((sum, teacher) => sum + (Number(teacher.salary) || 0), 0);
  const paidCount = payrollByStatus.paid.length;
  const pendingCount = payrollByStatus.pending.length;

  const handleDraftChange = (teacherId, field, value) => {
    setDrafts((current) => ({
      ...current,
      [teacherId]: {
        ...current[teacherId],
        [field]: value,
      },
    }));
  };

  const handleSaveCompensation = (teacher) => {
    const draft = drafts[teacher.id] || {};
    const nextSalary = Number(draft.salary ?? teacher.salary);
    const nextJoiningDate = draft.joiningDate || teacher.joiningDate;
    const updatedTeachers = db.update('teachers', teacher.id, {
      salary: Number.isFinite(nextSalary) && nextSalary > 0 ? nextSalary : '',
      joiningDate: nextJoiningDate,
    });

    if (updatedTeachers) {
      setTeachers(updatedTeachers.map(normalizeTeacherSalary));
      setDrafts((current) => {
        const next = { ...current };
        delete next[teacher.id];
        return next;
      });
    }
  };

  const handleMarkPaid = (teacher) => {
    const updatedTeacher = markSalaryPaid(teacher, selectedMonth);
    const updatedTeachers = db.update('teachers', teacher.id, updatedTeacher);
    if (updatedTeachers) setTeachers(updatedTeachers.map(normalizeTeacherSalary));
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#eefbf5_52%,#fdfefe_100%)] pb-16 text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              Dashboard
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Salary Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Teacher Payroll Desk</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl border border-slate-200/80 bg-slate-950 text-white shadow-[0_30px_80px_-40px_rgba(15,23,42,0.9)]">
          <div className="grid gap-8 px-7 py-8 lg:grid-cols-[1.4fr_1fr] lg:px-10 lg:py-10">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.32em] text-emerald-300">College Control</p>
              <h2 className="mt-3 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Decide salary at onboarding, revise it later, and mark each teaching month as paid from the college side only.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-300">
                Teachers can view their salary timeline in the teacher portal, but only the college can set salary, update compensation, and confirm salary payment for a month.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
              <PayrollStat label="Monthly Payroll" value={formatSalary(totalPayroll)} icon={IndianRupee} />
              <PayrollStat label="Paid This Month" value={String(paidCount)} icon={CheckCircle2} />
              <PayrollStat label="Pending This Month" value={String(pendingCount)} icon={Briefcase} />
            </div>
          </div>
        </section>

        <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-5 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-6">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Faculty Payroll Register</h3>
              <p className="mt-1 text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">
                {filteredTeachers.length} teacher record(s) for {getMonthLabel(selectedMonth)}
              </p>
            </div>

            <div className="flex flex-col gap-3 md:flex-row">
              <div className="relative min-w-70">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search teacher, employee ID, class..."
                  className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
                />
              </div>

              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="rounded-2xl border-2 border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-700 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
              />
            </div>
          </div>

          <div className="mt-6 space-y-8">
            <SalarySection
              title="Unpaid Section"
              description={`Teachers still pending for ${getMonthLabel(selectedMonth)}`}
              emptyMessage="No unpaid teachers for the selected month."
              tone="amber"
              items={payrollByStatus.pending}
              drafts={drafts}
              onDraftChange={handleDraftChange}
              onSaveCompensation={handleSaveCompensation}
              onMarkPaid={handleMarkPaid}
              selectedMonth={selectedMonth}
            />

            <SalarySection
              title="Paid Section"
              description={`Teachers already paid for ${getMonthLabel(selectedMonth)}`}
              emptyMessage="No paid teachers for the selected month yet."
              tone="emerald"
              items={payrollByStatus.paid}
              drafts={drafts}
              onDraftChange={handleDraftChange}
              onSaveCompensation={handleSaveCompensation}
              onMarkPaid={handleMarkPaid}
              selectedMonth={selectedMonth}
            />
          </div>
        </section>
      </div>
    </div>
  );
};

const SalarySection = ({
  title,
  description,
  emptyMessage,
  tone,
  items,
  drafts,
  onDraftChange,
  onSaveCompensation,
  onMarkPaid,
  selectedMonth,
}) => (
  <section>
    <div className="flex items-center justify-between gap-3">
      <div>
        <h4 className="font-serif text-xl font-black italic tracking-tight text-slate-950">{title}</h4>
        <p className="mt-1 text-sm font-semibold text-slate-500">{description}</p>
      </div>
      <span
        className={`inline-flex rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] ${
          tone === 'emerald' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
        }`}
      >
        {items.length} teacher(s)
      </span>
    </div>

    {items.length > 0 ? (
      <div className="mt-4 grid gap-5">
        {items.map(({ teacher, selectedMonthEntry }) => {
          const draft = drafts[teacher.id] || {};
          const timeline = buildSalaryTimeline(teacher);

          return (
            <article key={teacher.id} className="rounded-[1.9rem] border border-slate-200/80 bg-slate-50 p-5 shadow-sm">
              <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
                <div>
                  <p className="text-lg font-black tracking-tight text-slate-950">
                    {teacher.firstName} {teacher.lastName}
                  </p>
                  <p className="mt-1 text-sm font-semibold text-slate-500">
                    {teacher.teacherSystemId || 'Pending'} | {teacher.employeeId || 'No employee ID'} | {teacher.assignedClass || 'Class not assigned'}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Tag icon={IndianRupee} text={`Current salary ${formatSalary(teacher.salary)}`} />
                    <Tag icon={CalendarDays} text={`Joined ${teacher.joiningDate || 'Not set'}`} />
                    <Tag icon={Banknote} text={selectedMonthEntry?.isPaid ? `${getMonthLabel(selectedMonth)} paid` : `${getMonthLabel(selectedMonth)} pending`} />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onMarkPaid(teacher)}
                  disabled={!selectedMonthEntry || selectedMonthEntry.isPaid || !teacher.salary}
                  className={`inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-[11px] font-black uppercase tracking-[0.18em] transition ${
                    !selectedMonthEntry || selectedMonthEntry.isPaid || !teacher.salary
                      ? 'cursor-not-allowed bg-slate-200 text-slate-400'
                      : 'bg-emerald-600 text-white shadow-lg shadow-emerald-100 hover:bg-emerald-700'
                  }`}
                >
                  <CheckCircle2 size={14} />
                  {selectedMonthEntry?.isPaid ? 'Already Paid' : 'Mark Selected Month Paid'}
                </button>
              </div>

              <div className="mt-5 grid gap-4 lg:grid-cols-[0.9fr_0.9fr_0.7fr]">
                <Field label="Monthly Salary">
                  <input
                    type="number"
                    min="0"
                    value={draft.salary ?? teacher.salary}
                    onChange={(e) => onDraftChange(teacher.id, 'salary', e.target.value)}
                    className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
                    placeholder="35000"
                  />
                </Field>

                <Field label="Teaching Start Date">
                  <input
                    type="date"
                    value={draft.joiningDate ?? teacher.joiningDate}
                    onChange={(e) => onDraftChange(teacher.id, 'joiningDate', e.target.value)}
                    className="w-full rounded-2xl border-2 border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
                  />
                </Field>

                <Field label="Update Salary">
                  <button
                    type="button"
                    onClick={() => onSaveCompensation(teacher)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-4 py-3 text-[11px] font-black uppercase tracking-[0.18em] text-white transition hover:bg-emerald-600"
                  >
                    <Save size={14} />
                    Save Compensation
                  </button>
                </Field>
              </div>

              <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                {timeline.slice(0, 8).map((entry) => (
                  <div
                    key={entry.monthKey}
                    className={`rounded-2xl border px-4 py-3 ${
                      entry.isPaid
                        ? 'border-emerald-200 bg-emerald-50'
                        : 'border-amber-200 bg-amber-50'
                    }`}
                  >
                    <p className="text-[11px] font-black uppercase tracking-[0.16em] text-slate-500">{entry.label}</p>
                    <p className="mt-2 text-sm font-black text-slate-950">{formatSalary(entry.amount)}</p>
                    <p className={`mt-1 text-xs font-semibold ${entry.isPaid ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {entry.isPaid ? `Paid on ${new Date(entry.paidOn).toLocaleDateString('en-IN')}` : 'Pending'}
                    </p>
                  </div>
                ))}
              </div>
            </article>
          );
        })}
      </div>
    ) : (
      <div className="mt-4 rounded-[1.6rem] border border-dashed border-slate-200 bg-slate-50 px-5 py-6 text-sm font-semibold text-slate-500">
        {emptyMessage}
      </div>
    )}
  </section>
);

const PayrollStat = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-300">{label}</p>
        <p className="mt-3 text-3xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-400/20 bg-emerald-400/10 text-emerald-100">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const Tag = ({ icon, text }) => (
  <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-slate-600">
    {React.createElement(icon, { size: 14, className: 'text-emerald-700' })}
    {text}
  </span>
);

const Field = ({ label, children }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    {children}
  </div>
);

export default SalaryManagement;
