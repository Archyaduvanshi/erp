import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Bus,
  IdCard,
  MapPin,
  Phone,
  Plus,
  Route,
  Search,
  Trash2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const initialDriverForm = {
  driverName: '',
  driverPhone: '',
  driverLicense: '',
  salary: '',
  busNumber: '',
  routeName: '',
  vehicleType: 'School Bus',
  seatCapacity: '',
  pickupPoints: '',
};

const initialStudentForm = {
  studentId: '',
  studentName: '',
  className: '',
  pickupStop: '',
  assignedDriverId: '',
  driverName: '',
  driverPhone: '',
  busNumber: '',
  routeName: '',
};

const syncStudentTransportStatus = (studentId, isActive) => {
  const tenantId = db.getTenantId();
  if (!tenantId || !studentId) return;

  const key = `${tenantId}_students`;
  const existing = JSON.parse(localStorage.getItem(key)) || [];
  const updated = existing.map((student) => {
    if (String(student.id) !== String(studentId)) return student;
    return {
      ...student,
      transportOptIn: 'yes',
      transportStatus: isActive ? 'active' : 'inactive',
      facilities: {
        transport: {
          requested: true,
          active: isActive,
          status: isActive ? 'active' : 'inactive',
        },
        hostel: {
          requested: student.hostelOptIn === 'yes' || student.hostelOptIn === true,
          active: student.hostelStatus === 'active',
          status: student.hostelStatus || 'inactive',
        },
      },
    };
  });

  localStorage.setItem(key, JSON.stringify(updated));
};

const TransportManagement = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('home');
  const [drivers, setDrivers] = useState([]);
  const [transportStudents, setTransportStudents] = useState([]);
  const [students, setStudents] = useState([]);
  const [driverSearch, setDriverSearch] = useState('');
  const [studentSearch, setStudentSearch] = useState('');
  const [driverForm, setDriverForm] = useState(initialDriverForm);
  const [studentForm, setStudentForm] = useState(initialStudentForm);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setDrivers(db.getAll('transport_drivers'));
    setTransportStudents(db.getAll('transport_students'));
    setStudents(db.getAll('students'));
  };

  const removeRecord = (module, recordId, message) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;
    if (!window.confirm(message)) return;

    const key = `${tenantId}_${module}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const removedRecord = existing.find((record) => record.id === recordId);
    const updated = existing.filter((record) => record.id !== recordId);
    localStorage.setItem(key, JSON.stringify(updated));

    if (module === 'transport_drivers') {
      const studentKey = `${tenantId}_transport_students`;
      const existingStudents = JSON.parse(localStorage.getItem(studentKey)) || [];
      const impactedStudentIds = existingStudents
        .filter((record) => record.assignedDriverId === recordId)
        .map((record) => record.studentId)
        .filter(Boolean);
      const clearedStudents = existingStudents.map((record) =>
        record.assignedDriverId === recordId
          ? {
              ...record,
              assignedDriverId: '',
              driverName: '',
              busNumber: '',
              routeName: '',
            }
          : record,
      );
      localStorage.setItem(studentKey, JSON.stringify(clearedStudents));
      impactedStudentIds.forEach((studentId) => syncStudentTransportStatus(studentId, false));
    }

    if (module === 'transport_students' && removedRecord?.studentId) {
      syncStudentTransportStatus(removedRecord.studentId, false);
    }

    refreshData();
  };

  const handleDriverSave = (e) => {
    e.preventDefault();
    const payload = {
      ...driverForm,
      salary: driverForm.salary ? Number(driverForm.salary) : '',
      status: 'Active',
      routeCode: `ROUTE-${driverForm.routeName.trim().replace(/\s+/g, '-').toUpperCase() || Math.floor(100 + Math.random() * 900)}`,
    };

    db.save('transport_drivers', payload);
    setDriverForm(initialDriverForm);
    refreshData();
    setActiveSection('drivers');
  };

  const handleStudentSelect = (studentId) => {
    const selectedStudent = students.find((student) => String(student.id) === studentId);
    if (!selectedStudent) {
      setStudentForm((current) => ({
        ...current,
        studentId,
        studentName: '',
        className: '',
      }));
      return;
    }

    setStudentForm((current) => ({
      ...current,
      studentId,
      studentName: `${selectedStudent.firstName || ''} ${selectedStudent.lastName || ''}`.trim(),
      className: selectedStudent.assignedClass || '',
    }));
  };

  const handleStudentDriverSelect = (driverId) => {
    const selectedDriver = drivers.find((driver) => String(driver.id) === driverId);
    setStudentForm((current) => ({
      ...current,
      assignedDriverId: driverId,
      driverName: selectedDriver?.driverName || '',
      driverPhone: selectedDriver?.driverPhone || '',
      busNumber: selectedDriver?.busNumber || '',
      routeName: selectedDriver?.routeName || '',
    }));
  };

  const handleStudentSave = (e) => {
    e.preventDefault();
    const selectedDriver = drivers.find((driver) => String(driver.id) === studentForm.assignedDriverId);
    const payload = {
      ...studentForm,
      driverName: selectedDriver?.driverName || '',
      driverPhone: selectedDriver?.driverPhone || '',
      busNumber: selectedDriver?.busNumber || '',
      routeName: selectedDriver?.routeName || '',
    };

    db.save('transport_students', payload);
    syncStudentTransportStatus(payload.studentId, true);
    setStudentForm(initialStudentForm);
    refreshData();
    setActiveSection('students');
  };

  const filteredDrivers = useMemo(() => {
    const query = driverSearch.trim().toLowerCase();
    return drivers.filter((driver) => {
      if (!query) return true;
      return (
        driver.driverName?.toLowerCase().includes(query) ||
        driver.busNumber?.toLowerCase().includes(query) ||
        driver.routeName?.toLowerCase().includes(query) ||
        driver.driverPhone?.toLowerCase().includes(query) ||
        String(driver.salary || '').includes(query)
      );
    });
  }, [driverSearch, drivers]);

  const filteredTransportStudents = useMemo(() => {
    const query = studentSearch.trim().toLowerCase();
    return transportStudents.filter((record) => {
      if (!query) return true;
      return (
        record.studentName?.toLowerCase().includes(query) ||
        record.className?.toLowerCase().includes(query) ||
        record.driverName?.toLowerCase().includes(query) ||
        record.busNumber?.toLowerCase().includes(query) ||
        record.routeName?.toLowerCase().includes(query)
      );
    });
  }, [studentSearch, transportStudents]);

  const assignedStudentsCount = transportStudents.filter((record) => record.assignedDriverId).length;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#ecfeff_45%,#f8fafc_100%)] text-slate-900 selection:bg-sky-400 selection:text-slate-950">
      <div className="border-b border-slate-200/70 bg-white/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-sky-300 hover:text-sky-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-sky-600">Transport Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Driver and Student Transport Desk</h1>
            </div>
          </div>

          {activeSection !== 'home' ? (
            <button
              onClick={() => setActiveSection('home')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] text-slate-600 transition hover:border-sky-300 hover:text-sky-700"
            >
              <X size={14} />
              Close Section
            </button>
          ) : (
            <div className="hidden rounded-full border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 md:inline-flex">
              Choose Drivers or Students
            </div>
          )}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        {activeSection === 'home' && (
          <TransportHome
            drivers={drivers}
            transportStudents={transportStudents}
            assignedStudentsCount={assignedStudentsCount}
            onOpenDrivers={() => setActiveSection('drivers')}
            onOpenStudents={() => setActiveSection('students')}
          />
        )}

        {activeSection === 'drivers' && (
          <DriverSection
            driverForm={driverForm}
            setDriverForm={setDriverForm}
            filteredDrivers={filteredDrivers}
            onSearch={setDriverSearch}
            searchValue={driverSearch}
            onSave={handleDriverSave}
            onDelete={(driverId) => removeRecord('transport_drivers', driverId, 'Delete this driver and bus record?')}
            onBack={() => setActiveSection('home')}
          />
        )}

        {activeSection === 'students' && (
          <StudentSection
            studentForm={studentForm}
            setStudentForm={setStudentForm}
            students={students}
            drivers={drivers}
            filteredTransportStudents={filteredTransportStudents}
            onStudentSelect={handleStudentSelect}
            onDriverSelect={handleStudentDriverSelect}
            onSearch={setStudentSearch}
            searchValue={studentSearch}
            onSave={handleStudentSave}
            onDelete={(recordId) => removeRecord('transport_students', recordId, 'Delete this student transport assignment?')}
            onBack={() => setActiveSection('home')}
          />
        )}
      </div>
    </div>
  );
};

const TransportHome = ({ drivers, transportStudents, assignedStudentsCount, onOpenDrivers, onOpenStudents }) => (
  <div className="space-y-8">
    <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#082f49_0%,#0f172a_52%,#020617_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(8,47,73,0.75)] lg:px-10 lg:py-10">
      <div className="grid gap-8 lg:grid-cols-[1.3fr_0.7fr]">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.3em] text-sky-300">Transport Console</p>
          <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
            Open drivers or student transport from two clear cards and manage both separately.
          </h2>
          <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-300">
            Driver records hold bus and route details. Student assignments connect each student with the selected driver, bus number, and route name.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
          <MetricCard label="Drivers" value={drivers.length} icon={Users} />
          <MetricCard label="Student Entries" value={transportStudents.length} icon={UserPlus} />
          <MetricCard label="Assigned Students" value={assignedStudentsCount} icon={Bus} />
        </div>
      </div>
    </section>

    <section className="grid gap-6 lg:grid-cols-2">
      <EntryCard
        icon={Users}
        title="Driver Management"
        description="Add or remove drivers and save driver, salary, bus, route, phone, license, and pickup details."
        meta={`${drivers.length} driver records`}
        buttonLabel="Open Drivers"
        onClick={onOpenDrivers}
      />
      <EntryCard
        icon={Bus}
        title="Student Transport"
        description="Assign students under a driver with the connected bus number and route name in one place."
        meta={`${transportStudents.length} student transport records`}
        buttonLabel="Open Students"
        onClick={onOpenStudents}
      />
    </section>
  </div>
);

const DriverSection = ({ driverForm, setDriverForm, filteredDrivers, onSearch, searchValue, onSave, onDelete, onBack }) => (
  <div className="space-y-8">
    <SectionHeader
      eyebrow="Driver Section"
      title="Drivers, buses, and routes"
      description="Save every driver with bus and route details, then remove records whenever the transport roster changes."
      onBack={onBack}
    />

    <div className="grid gap-8 xl:grid-cols-[0.95fr_1.05fr]">
      <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
        <FormTitle title="Add Driver Record" description="This saves the driver with the bus number and route name together." />
        <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={onSave}>
          <CreativeInput label="Driver Name" value={driverForm.driverName} onChange={(e) => setDriverForm({ ...driverForm, driverName: e.target.value })} placeholder="Ramesh Kumar" />
          <CreativeInput label="Driver Phone" value={driverForm.driverPhone} onChange={(e) => setDriverForm({ ...driverForm, driverPhone: e.target.value })} placeholder="+91 9876543210" />
          <CreativeInput label="License Number" value={driverForm.driverLicense} onChange={(e) => setDriverForm({ ...driverForm, driverLicense: e.target.value })} placeholder="DL-XX-2026-001" />
          <CreativeInput label="Salary" type="number" min="0" value={driverForm.salary} onChange={(e) => setDriverForm({ ...driverForm, salary: e.target.value })} placeholder="18000" />
          <CreativeInput label="Bus Number" value={driverForm.busNumber} onChange={(e) => setDriverForm({ ...driverForm, busNumber: e.target.value.toUpperCase() })} placeholder="UP16 AB 1234" />
          <CreativeInput label="Route Name" value={driverForm.routeName} onChange={(e) => setDriverForm({ ...driverForm, routeName: e.target.value })} placeholder="North Campus Route" />
          <CreativeSelect
            label="Vehicle Type"
            value={driverForm.vehicleType}
            onChange={(e) => setDriverForm({ ...driverForm, vehicleType: e.target.value })}
            options={['School Bus', 'Mini Bus', 'Van']}
          />
          <CreativeInput label="Seat Capacity" type="number" value={driverForm.seatCapacity} onChange={(e) => setDriverForm({ ...driverForm, seatCapacity: e.target.value })} placeholder="42" />
          <div className="md:col-span-2">
            <CreativeTextarea label="Pickup Points" value={driverForm.pickupPoints} onChange={(e) => setDriverForm({ ...driverForm, pickupPoints: e.target.value })} placeholder="Sector 10, Main Road, Station Circle, College Gate" />
          </div>
          <div className="md:col-span-2">
            <PrimaryButton type="submit" icon={Plus} label="Save Driver Record" />
          </div>
        </form>
      </section>

      <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <FormTitle title="Saved Drivers" description="Each card includes the linked bus and route details." />
          <SearchInput value={searchValue} onChange={onSearch} placeholder="Search driver, salary, bus, route, phone..." />
        </div>

        {filteredDrivers.length > 0 ? (
          <div className="mt-8 grid gap-5">
            {filteredDrivers.map((driver) => (
              <article key={driver.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
                        <Users size={20} />
                      </div>
                      <div>
                        <h3 className="text-lg font-black tracking-tight text-slate-950">{driver.driverName}</h3>
                        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-sky-700">{driver.routeName || 'Route pending'}</p>
                      </div>
                    </div>
                    <InfoPill icon={Bus} text={driver.busNumber || 'Bus number not added'} />
                    <InfoPill icon={Phone} text={driver.driverPhone || 'Phone not added'} />
                    <InfoPill icon={IdCard} text={driver.driverLicense || 'License not added'} />
                    <InfoPill icon={Route} text={driver.salary ? `Salary INR ${driver.salary}` : 'Salary not added'} />
                    <InfoPill icon={MapPin} text={driver.pickupPoints || 'Pickup points not added'} />
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">
                      {driver.vehicleType || 'Vehicle'} {driver.seatCapacity ? `• ${driver.seatCapacity} seats` : ''}
                    </span>
                    <button
                      onClick={() => onDelete(driver.id)}
                      className="inline-flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Users}
            title="No driver records yet"
            description="Add the first driver with bus and route details to start transport mapping."
          />
        )}
      </section>
    </div>
  </div>
);

const StudentSection = ({
  studentForm,
  setStudentForm,
  students,
  drivers,
  filteredTransportStudents,
  onStudentSelect,
  onDriverSelect,
  onSearch,
  searchValue,
  onSave,
  onDelete,
  onBack,
}) => (
  <div className="space-y-8">
    <SectionHeader
      eyebrow="Student Section"
      title="Students under drivers"
      description="Assign students to a saved driver and automatically show the related bus number and route name."
      onBack={onBack}
    />

    <div className="grid gap-8 xl:grid-cols-[0.95fr_1.05fr]">
      <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
        <FormTitle title="Add Student Transport" description="Pick a student, choose a driver, and save the assignment." />
        <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={onSave}>
          <CreativeSelect
            label="Select Student"
            value={studentForm.studentId}
            onChange={(e) => onStudentSelect(e.target.value)}
            options={['', ...students.map((student) => String(student.id))]}
            renderOptionLabel={(value) => {
              if (!value) return 'Choose saved student';
              const found = students.find((student) => String(student.id) === value);
              return found ? `${found.firstName || ''} ${found.lastName || ''}`.trim() : value;
            }}
          />
          <CreativeInput label="Student Name" value={studentForm.studentName} onChange={(e) => setStudentForm({ ...studentForm, studentName: e.target.value })} placeholder="Student full name" />
          <CreativeInput label="Class" value={studentForm.className} onChange={(e) => setStudentForm({ ...studentForm, className: e.target.value })} placeholder="BCA Semester 1" />
          <CreativeInput label="Pickup Stop" value={studentForm.pickupStop} onChange={(e) => setStudentForm({ ...studentForm, pickupStop: e.target.value })} placeholder="Main Chowk" />
          <div className="md:col-span-2">
            <CreativeSelect
              label="Assign Driver"
              value={studentForm.assignedDriverId}
              onChange={(e) => onDriverSelect(e.target.value)}
              options={['', ...drivers.map((driver) => String(driver.id))]}
              renderOptionLabel={(value) => {
                if (!value) return drivers.length ? 'Choose driver' : 'No drivers available';
                const found = drivers.find((driver) => String(driver.id) === value);
                return found ? `${found.driverName} • ${found.busNumber || 'Bus pending'} • ${found.routeName || 'Route pending'}` : value;
              }}
            />
          </div>
          <div className="rounded-[1.6rem] border border-slate-200 bg-slate-50 p-4">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">Driver Name</p>
            <p className="mt-2 text-sm font-semibold text-slate-900">{studentForm.driverName || 'Will appear after driver selection'}</p>
          </div>
          <div className="rounded-[1.6rem] border border-slate-200 bg-slate-50 p-4">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">Bus Number</p>
            <p className="mt-2 text-sm font-semibold text-slate-900">{studentForm.busNumber || 'Will appear after driver selection'}</p>
          </div>
          <div className="md:col-span-2 rounded-[1.6rem] border border-slate-200 bg-slate-50 p-4">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">Route Name</p>
            <p className="mt-2 text-sm font-semibold text-slate-900">{studentForm.routeName || 'Will appear after driver selection'}</p>
          </div>
          <div className="md:col-span-2">
            <PrimaryButton type="submit" icon={Plus} label="Save Student Transport" />
          </div>
        </form>
      </section>

      <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <FormTitle title="Saved Student Assignments" description="Each row shows the linked driver, bus, and route." />
          <SearchInput value={searchValue} onChange={onSearch} placeholder="Search student, class, driver, bus..." />
        </div>

        {filteredTransportStudents.length > 0 ? (
          <div className="mt-8 grid gap-5">
            {filteredTransportStudents.map((record) => (
              <article key={record.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-100 text-cyan-700">
                        <UserPlus size={20} />
                      </div>
                      <div>
                        <h3 className="text-lg font-black tracking-tight text-slate-950">{record.studentName || 'Unnamed student'}</h3>
                        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-cyan-700">{record.className || 'Class pending'}</p>
                      </div>
                    </div>
                    <InfoPill icon={Users} text={record.driverName || 'Driver not assigned'} />
                    <InfoPill icon={Bus} text={record.busNumber || 'Bus number not assigned'} />
                    <InfoPill icon={Route} text={record.routeName || 'Route name not assigned'} />
                    <InfoPill icon={MapPin} text={record.pickupStop || 'Pickup stop not added'} />
                  </div>

                  <button
                    onClick={() => onDelete(record.id)}
                    className="inline-flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Bus}
            title="No student transport assignments yet"
            description="Save a driver first, then attach students under that driver with the bus and route details."
          />
        )}
      </section>
    </div>
  </div>
);

const EntryCard = ({ icon: Icon, title, description, meta, buttonLabel, onClick }) => (
  <button
    onClick={onClick}
    className="group rounded-4xl border border-slate-200/80 bg-white p-7 text-left shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] transition hover:-translate-y-1.5 hover:border-sky-200 hover:shadow-[0_24px_60px_-30px_rgba(14,165,233,0.3)]"
  >
    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#dbeafe_0%,#cffafe_100%)] text-sky-700 transition group-hover:scale-105">
      <Icon size={24} />
    </div>
    <h3 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-3 max-w-lg text-sm leading-7 text-slate-500">{description}</p>
    <div className="mt-6 flex items-center justify-between gap-4">
      <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">
        {meta}
      </span>
      <span className="text-[11px] font-black uppercase tracking-[0.22em] text-sky-700">{buttonLabel}</span>
    </div>
  </button>
);

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-300">{label}</p>
        <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-sky-400/20 bg-sky-400/10 text-sky-100">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const SectionHeader = ({ eyebrow, title, description, onBack }) => (
  <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
    <div>
      <p className="text-[11px] font-black uppercase tracking-[0.3em] text-sky-600">{eyebrow}</p>
      <h2 className="mt-3 font-serif text-4xl font-black italic leading-none tracking-tight text-slate-950">{title}</h2>
      <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-500">{description}</p>
    </div>
    <button
      onClick={onBack}
      className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] text-slate-600 transition hover:border-sky-300 hover:text-sky-700"
    >
      <ArrowLeft size={14} />
      Back to Cards
    </button>
  </div>
);

const FormTitle = ({ title, description }) => (
  <div>
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative min-w-65">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-100"
    />
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option || 'empty-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
        </option>
      ))}
    </select>
  </div>
);

const CreativeTextarea = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <textarea
      className="min-h-32 w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-100"
      {...props}
    />
  </div>
);

const PrimaryButton = ({ type, icon: Icon, label }) => (
  <button
    type={type}
    className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-sky-600"
  >
    <Icon size={15} />
    {label}
  </button>
);

const InfoPill = ({ icon: Icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    <Icon size={15} className="text-sky-700" />
    <span>{text}</span>
  </div>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <Icon size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

export default TransportManagement;
