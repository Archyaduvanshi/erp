import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  CalendarDays,
  Download,
  FileText,
  Printer,
  ScrollText,
  Search,
  Ticket,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const initialDateSheetForm = {
  className: '',
  examType: '',
  fileName: '',
  fileData: '',
  fileType: '',
};

const initialQuestionPaperForm = {
  examTitle: '',
  className: '',
  subjectName: '',
  uploadedBy: '',
  fileName: '',
  fileData: '',
  fileType: '',
};

const initialAdmitCardForm = {
  examTitle: '',
  studentId: '',
  rollNo: '',
  className: '',
  centerName: '',
  reportingTime: '',
  examDate: '',
};

const ExaminationManagement = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('home');
  const [students, setStudents] = useState([]);
  const [dateSheets, setDateSheets] = useState([]);
  const [questionPapers, setQuestionPapers] = useState([]);
  const [admitCards, setAdmitCards] = useState([]);
  const [dateSheetForm, setDateSheetForm] = useState(initialDateSheetForm);
  const [questionPaperForm, setQuestionPaperForm] = useState(initialQuestionPaperForm);
  const [admitCardForm, setAdmitCardForm] = useState(initialAdmitCardForm);
  const [openDateSheetClass, setOpenDateSheetClass] = useState('');
  const [dateSheetSearch, setDateSheetSearch] = useState('');
  const [questionSearch, setQuestionSearch] = useState('');
  const [admitSearch, setAdmitSearch] = useState('');

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setStudents(db.getAll('students'));
    setDateSheets(db.getAll('exam_datesheets'));
    setQuestionPapers(db.getAll('exam_question_papers'));
    setAdmitCards(db.getAll('exam_admit_cards'));
  };

  const availableClasses = useMemo(() => {
    const classes = [...new Set(students.map((student) => student.assignedClass?.trim()).filter(Boolean))];
    return classes.sort((a, b) => a.localeCompare(b));
  }, [students]);

  const availableExamTitles = useMemo(() => {
    const examTitles = [
      ...dateSheets.map((record) => record.examType),
      ...questionPapers.map((record) => record.examTitle),
      ...admitCards.map((record) => record.examTitle),
    ].filter(Boolean);
    return [...new Set(examTitles)].sort((a, b) => a.localeCompare(b));
  }, [admitCards, dateSheets, questionPapers]);

  const filteredDateSheets = useMemo(() => {
    const query = dateSheetSearch.trim().toLowerCase();
    return dateSheets.filter((record) => {
      if (!query) return true;
      return (
        record.className?.toLowerCase().includes(query) ||
        record.examType?.toLowerCase().includes(query) ||
        record.fileName?.toLowerCase().includes(query)
      );
    });
  }, [dateSheetSearch, dateSheets]);

  const filteredQuestionPapers = useMemo(() => {
    const query = questionSearch.trim().toLowerCase();
    return questionPapers.filter((record) => {
      if (!query) return true;
      return (
        record.examTitle?.toLowerCase().includes(query) ||
        record.className?.toLowerCase().includes(query) ||
        record.subjectName?.toLowerCase().includes(query) ||
        record.uploadedBy?.toLowerCase().includes(query) ||
        record.fileName?.toLowerCase().includes(query)
      );
    });
  }, [questionPapers, questionSearch]);

  const filteredAdmitCards = useMemo(() => {
    const query = admitSearch.trim().toLowerCase();
    return admitCards.filter((record) => {
      if (!query) return true;
      return (
        record.examTitle?.toLowerCase().includes(query) ||
        record.studentName?.toLowerCase().includes(query) ||
        record.rollNo?.toLowerCase().includes(query) ||
        record.className?.toLowerCase().includes(query) ||
        record.centerName?.toLowerCase().includes(query)
      );
    });
  }, [admitCards, admitSearch]);

  const dateSheetMap = useMemo(() => {
    return filteredDateSheets.reduce((accumulator, record) => {
      accumulator[record.className] = record;
      return accumulator;
    }, {});
  }, [filteredDateSheets]);

  const handleDateSheetBrowse = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setDateSheetForm((current) => ({
        ...current,
        fileName: file.name,
        fileData: String(reader.result || ''),
        fileType: file.type || 'application/octet-stream',
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleOpenDateSheetClass = (className) => {
    const existingRecord = dateSheets.find((record) => record.className === className);
    setOpenDateSheetClass(className);
    setDateSheetForm(existingRecord ? {
      className,
      examType: existingRecord.examType || '',
      fileName: existingRecord.fileName || '',
      fileData: existingRecord.fileData || '',
      fileType: existingRecord.fileType || '',
    } : {
      ...initialDateSheetForm,
      className,
    });
  };

  const handleDateSheetSave = (e) => {
    e.preventDefault();
    if (!dateSheetForm.className || !dateSheetForm.examType.trim() || !dateSheetForm.fileData) return;

    const tenantId = db.getTenantId();
    if (!tenantId) return;

    const key = `${tenantId}_exam_datesheets`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const remaining = existing.filter((record) => record.className !== dateSheetForm.className);
    const nextRecord = {
      ...dateSheetForm,
      examType: dateSheetForm.examType.trim(),
      id: Date.now(),
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem(key, JSON.stringify([...remaining, nextRecord]));
    setDateSheetForm(initialDateSheetForm);
    setOpenDateSheetClass('');
    refreshData();
  };

  const handleQuestionPaperBrowse = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setQuestionPaperForm((current) => ({
        ...current,
        fileName: file.name,
        fileData: String(reader.result || ''),
        fileType: file.type || 'application/octet-stream',
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleQuestionPaperSave = (e) => {
    e.preventDefault();
    if (!questionPaperForm.fileData) return;

    db.save('exam_question_papers', {
      ...questionPaperForm,
      examTitle: questionPaperForm.examTitle.trim(),
      className: questionPaperForm.className.trim(),
      subjectName: questionPaperForm.subjectName.trim(),
      uploadedBy: questionPaperForm.uploadedBy.trim(),
    });
    setQuestionPaperForm(initialQuestionPaperForm);
    refreshData();
  };

  const handleStudentSelect = (studentId) => {
    const selectedStudent = students.find((student) => String(student.id) === studentId);
    if (!selectedStudent) {
      setAdmitCardForm((current) => ({
        ...current,
        studentId,
        rollNo: '',
        className: '',
      }));
      return;
    }

    setAdmitCardForm((current) => ({
      ...current,
      studentId,
      rollNo: selectedStudent.enrollmentNo || selectedStudent.systemId || '',
      className: selectedStudent.assignedClass || '',
    }));
  };

  const handleAdmitCardSave = (e) => {
    e.preventDefault();
    const selectedStudent = students.find((student) => String(student.id) === admitCardForm.studentId);
    if (!selectedStudent) return;

    db.save('exam_admit_cards', {
      ...admitCardForm,
      examTitle: admitCardForm.examTitle.trim(),
      studentId: selectedStudent.systemId || String(selectedStudent.id),
      studentName: `${selectedStudent.firstName || ''} ${selectedStudent.lastName || ''}`.trim(),
      rollNo: selectedStudent.enrollmentNo || selectedStudent.systemId || admitCardForm.rollNo,
      className: selectedStudent.assignedClass || admitCardForm.className,
      centerName: admitCardForm.centerName.trim(),
      reportingTime: admitCardForm.reportingTime.trim(),
      examDate: admitCardForm.examDate,
    });
    setAdmitCardForm(initialAdmitCardForm);
    refreshData();
  };

  const handleDelete = (module, recordId, message) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;
    if (!window.confirm(message)) return;

    const key = `${tenantId}_${module}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.filter((record) => record.id !== recordId);
    localStorage.setItem(key, JSON.stringify(updated));
    refreshData();
  };

  const handleDownloadPaper = (paper) => {
    if (!paper.fileData) return;
    const link = document.createElement('a');
    link.href = paper.fileData;
    link.download = paper.fileName || `${paper.subjectName || 'question-paper'}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPaper = (paper) => {
    if (!paper.fileData) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head><title>${paper.fileName || 'Question Paper'}</title></head>
        <body style="margin:0">
          <iframe src="${paper.fileData}" style="width:100%;height:100vh;border:none;"></iframe>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 500);
  };

  const handlePrintAdmitCard = (card) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head><title>Admit Card</title></head>
        <body style="font-family: Arial, sans-serif; padding: 32px;">
          <h1>${card.examTitle}</h1>
          <h2>Admit Card</h2>
          <p><strong>Student:</strong> ${card.studentName}</p>
          <p><strong>Roll No:</strong> ${card.rollNo}</p>
          <p><strong>Class:</strong> ${card.className}</p>
          <p><strong>Exam Date:</strong> ${card.examDate}</p>
          <p><strong>Reporting Time:</strong> ${card.reportingTime}</p>
          <p><strong>Center:</strong> ${card.centerName}</p>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 300);
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#eef2ff_45%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-indigo-300 hover:text-indigo-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-indigo-600">Examination Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Exam Control Room</h1>
            </div>
          </div>

          {activeSection !== 'home' ? (
            <button
              onClick={() => setActiveSection('home')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] text-slate-600 transition hover:border-indigo-300 hover:text-indigo-700"
            >
              <X size={14} />
              Close Section
            </button>
          ) : null}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        {activeSection === 'home' ? (
          <ExamHome
            dateSheetCount={dateSheets.length}
            questionPaperCount={questionPapers.length}
            admitCardCount={admitCards.length}
            onOpenDateSheet={() => setActiveSection('datesheet')}
            onOpenQuestionPaper={() => setActiveSection('questionpaper')}
            onOpenAdmitCard={() => setActiveSection('admitcard')}
          />
        ) : null}

        {activeSection === 'datesheet' ? (
          <DateSheetSection
            form={dateSheetForm}
            setForm={setDateSheetForm}
            classes={availableClasses}
            dateSheetMap={dateSheetMap}
            openClass={openDateSheetClass}
            searchValue={dateSheetSearch}
            onSearch={setDateSheetSearch}
            onOpenClass={handleOpenDateSheetClass}
            onBrowse={handleDateSheetBrowse}
            onSave={handleDateSheetSave}
            onDelete={(recordId) => handleDelete('exam_datesheets', recordId, 'Delete this exam date sheet entry?')}
          />
        ) : null}

        {activeSection === 'questionpaper' ? (
          <QuestionPaperSection
            form={questionPaperForm}
            setForm={setQuestionPaperForm}
            records={filteredQuestionPapers}
            classes={availableClasses}
            examTitles={availableExamTitles}
            searchValue={questionSearch}
            onSearch={setQuestionSearch}
            onBrowse={handleQuestionPaperBrowse}
            onSave={handleQuestionPaperSave}
            onDelete={(recordId) => handleDelete('exam_question_papers', recordId, 'Delete this uploaded question paper?')}
            onDownload={handleDownloadPaper}
            onPrint={handlePrintPaper}
          />
        ) : null}

        {activeSection === 'admitcard' ? (
          <AdmitCardSection
            form={admitCardForm}
            setForm={setAdmitCardForm}
            students={students}
            examTitles={availableExamTitles}
            records={filteredAdmitCards}
            searchValue={admitSearch}
            onSearch={setAdmitSearch}
            onStudentSelect={handleStudentSelect}
            onSave={handleAdmitCardSave}
            onDelete={(recordId) => handleDelete('exam_admit_cards', recordId, 'Delete this admit card record?')}
            onPrint={handlePrintAdmitCard}
          />
        ) : null}
      </div>
    </div>
  );
};

const ExamHome = ({ dateSheetCount, questionPaperCount, admitCardCount, onOpenDateSheet, onOpenQuestionPaper, onOpenAdmitCard }) => (
  <div className="space-y-8">
    <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#312e81_0%,#1e1b4b_55%,#0f172a_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(49,46,129,0.85)] lg:px-10 lg:py-10">
      <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.3em] text-indigo-200">Exam Console</p>
          <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
            Open the exam date sheet, question paper, or admit card desk from one clean control screen.
          </h2>
          <p className="mt-5 max-w-2xl text-sm leading-7 text-indigo-50/80">
            Manage date sheet uploads class by class, upload question papers by subject, and prepare admit cards for students.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
          <MetricCard label="Date Sheets" value={dateSheetCount} icon={CalendarDays} />
          <MetricCard label="Question Papers" value={questionPaperCount} icon={ScrollText} />
          <MetricCard label="Admit Cards" value={admitCardCount} icon={Ticket} />
        </div>
      </div>
    </section>

    <section className="grid gap-6 lg:grid-cols-3">
      <EntryCard icon={CalendarDays} title="Exam Date Sheet" description="Open class rows, choose exam type, and upload a date sheet file for each class." buttonLabel="Open Date Sheet" onClick={onOpenDateSheet} />
      <EntryCard icon={ScrollText} title="Question Paper" description="Upload question papers by subject so the college can view, download, and print them." buttonLabel="Open Question Paper" onClick={onOpenQuestionPaper} />
      <EntryCard icon={Ticket} title="Admit Card" description="Generate admit cards from saved student records and print them for examination day." buttonLabel="Open Admit Card" onClick={onOpenAdmitCard} />
    </section>
  </div>
);

const DateSheetSection = ({ form, setForm, classes, dateSheetMap, openClass, searchValue, onSearch, onOpenClass, onBrowse, onSave, onDelete }) => {
  const visibleClasses = classes.filter((className) => !searchValue.trim() || className.toLowerCase().includes(searchValue.trim().toLowerCase()));

  return (
    <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <FormTitle title="Class Date Sheet Upload" description="Click any class row, choose the exam type, upload the class date sheet, and save it." />
        <SearchInput value={searchValue} onChange={onSearch} placeholder="Search class or section..." />
      </div>

      {visibleClasses.length > 0 ? (
        <div className="mt-8 grid gap-5">
          {visibleClasses.map((className) => {
            const uploadedRecord = dateSheetMap[className];
            const isOpen = openClass === className;

            return (
              <article key={className} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-700">
                        <CalendarDays size={20} />
                      </div>
                      <div>
                        <h3 className="text-lg font-black tracking-tight text-slate-950">{className}</h3>
                        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700">
                          {uploadedRecord ? `${uploadedRecord.examType || 'Exam type pending'} | Uploaded` : 'No date sheet uploaded'}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <InfoPill icon={FileText} text={uploadedRecord?.examType || 'Exam type pending'} />
                      <InfoPill icon={Upload} text={uploadedRecord?.fileName || 'Date sheet not uploaded'} />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <ActionButton icon={CalendarDays} label={isOpen ? 'Open Row' : 'Open Upload'} onClick={() => onOpenClass(className)} />
                    {uploadedRecord ? <IconButton icon={Trash2} onClick={() => onDelete(uploadedRecord.id)} danger /> : null}
                  </div>
                </div>

                {isOpen ? (
                  <form className="mt-6 grid gap-5 rounded-[1.5rem] border border-slate-200 bg-white p-5 md:grid-cols-2" onSubmit={onSave}>
                    <CreativeInput
                      label="Exam Type"
                      value={form.examType}
                      onChange={(e) => setForm({ ...form, className, examType: e.target.value })}
                      placeholder="Mid Term / Unit Test / Annual"
                    />
                    <FileUploadField label="Upload Date Sheet" fileName={form.fileName} onBrowse={onBrowse} />
                    <div className="md:col-span-2">
                      <PrimaryButton type="submit" icon={Upload} label="Submit Date Sheet" />
                    </div>
                  </form>
                ) : null}
              </article>
            );
          })}
        </div>
      ) : (
        <EmptyState icon={CalendarDays} title="No classes available" description="Add students with assigned class or section first, then class rows will appear here." />
      )}
    </section>
  );
};

const QuestionPaperSection = ({ form, setForm, records, classes, examTitles, searchValue, onSearch, onBrowse, onSave, onDelete, onDownload, onPrint }) => (
  <div className="grid gap-8 xl:grid-cols-[0.92fr_1.08fr]">
    <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      <FormTitle title="Upload Question Paper" description="Upload a question paper by exam title, class, and subject so the college can download and print it." />
      <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={onSave}>
        <CreativeInput list="exam-title-options" label="Exam Title" value={form.examTitle} onChange={(e) => setForm({ ...form, examTitle: e.target.value })} placeholder="Mid Term Examination" />
        <CreativeSelect label="Class / Section" value={form.className} onChange={(e) => setForm({ ...form, className: e.target.value })} options={['', ...classes]} renderOptionLabel={(value) => value || 'Select class'} />
        <CreativeInput label="Subject Name" value={form.subjectName} onChange={(e) => setForm({ ...form, subjectName: e.target.value })} placeholder="Physics" />
        <CreativeInput label="Uploaded By Subject Teacher" value={form.uploadedBy} onChange={(e) => setForm({ ...form, uploadedBy: e.target.value })} placeholder="Teacher name" />
        <div className="md:col-span-2">
          <FileUploadField label="Question Paper File" fileName={form.fileName} onBrowse={onBrowse} />
        </div>
        <div className="md:col-span-2">
          <PrimaryButton type="submit" icon={Upload} label="Save Question Paper" />
        </div>
      </form>
      <datalist id="exam-title-options">
        {examTitles.map((examTitle) => (
          <option key={examTitle} value={examTitle} />
        ))}
      </datalist>
    </section>

    <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <FormTitle title="Uploaded Question Papers" description="College can view all uploaded subject papers and download or print them." />
        <SearchInput value={searchValue} onChange={onSearch} placeholder="Search title, class, subject..." />
      </div>
      {records.length > 0 ? (
        <div className="mt-8 grid gap-5">
          {records.map((record) => (
            <article key={record.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-700">
                      <ScrollText size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-black tracking-tight text-slate-950">{record.subjectName || 'Subject pending'}</h3>
                      <p className="text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700">{record.examTitle || 'Exam title pending'}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <InfoPill icon={FileText} text={record.className || 'Class pending'} />
                    <InfoPill icon={Upload} text={record.uploadedBy || 'Uploader not added'} />
                    <InfoPill icon={ScrollText} text={record.fileName || 'File missing'} />
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <ActionButton icon={Download} label="Download" onClick={() => onDownload(record)} />
                  <ActionButton icon={Printer} label="Print" onClick={() => onPrint(record)} />
                  <IconButton icon={Trash2} onClick={() => onDelete(record.id)} danger />
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState icon={ScrollText} title="No question papers yet" description="Upload the first subject paper so it can be viewed, downloaded, and printed." />
      )}
    </section>
  </div>
);

const AdmitCardSection = ({ form, setForm, students, examTitles, records, searchValue, onSearch, onStudentSelect, onSave, onDelete, onPrint }) => (
  <div className="grid gap-8 xl:grid-cols-[0.92fr_1.08fr]">
    <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      <FormTitle title="Generate Admit Card" description="Pick a student and exam details to save a printable admit card record." />
      <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={onSave}>
        <CreativeInput list="admit-exam-options" label="Exam Title" value={form.examTitle} onChange={(e) => setForm({ ...form, examTitle: e.target.value })} placeholder="Annual Examination" />
        <CreativeSelect
          label="Student"
          value={form.studentId}
          onChange={(e) => onStudentSelect(e.target.value)}
          options={['', ...students.map((student) => String(student.id))]}
          renderOptionLabel={(value) => {
            if (!value) return 'Select student';
            const student = students.find((record) => String(record.id) === value);
            return student ? `${student.firstName || ''} ${student.lastName || ''}`.trim() : value;
          }}
        />
        <CreativeInput label="Roll No" value={form.rollNo} onChange={(e) => setForm({ ...form, rollNo: e.target.value })} placeholder="Auto from student" />
        <CreativeInput label="Class / Section" value={form.className} onChange={(e) => setForm({ ...form, className: e.target.value })} placeholder="Auto from student" />
        <CreativeInput label="Exam Date" type="date" value={form.examDate} onChange={(e) => setForm({ ...form, examDate: e.target.value })} />
        <CreativeInput label="Reporting Time" type="time" value={form.reportingTime} onChange={(e) => setForm({ ...form, reportingTime: e.target.value })} />
        <div className="md:col-span-2">
          <CreativeInput label="Exam Center / Venue" value={form.centerName} onChange={(e) => setForm({ ...form, centerName: e.target.value })} placeholder="Main Examination Hall" />
        </div>
        <div className="md:col-span-2">
          <PrimaryButton type="submit" icon={Ticket} label="Save Admit Card" />
        </div>
      </form>
      <datalist id="admit-exam-options">
        {examTitles.map((examTitle) => (
          <option key={examTitle} value={examTitle} />
        ))}
      </datalist>
    </section>

    <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <FormTitle title="Saved Admit Cards" description="Review admit card records and print them for students." />
        <SearchInput value={searchValue} onChange={onSearch} placeholder="Search exam, student, roll no..." />
      </div>
      {records.length > 0 ? (
        <div className="mt-8 grid gap-5">
          {records.map((record) => (
            <article key={record.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-100 text-violet-700">
                      <Ticket size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-black tracking-tight text-slate-950">{record.studentName || 'Student pending'}</h3>
                      <p className="text-[11px] font-black uppercase tracking-[0.18em] text-violet-700">{record.examTitle || 'Exam title pending'}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <InfoPill icon={FileText} text={record.className || 'Class pending'} />
                    <InfoPill icon={Ticket} text={record.rollNo || 'Roll no pending'} />
                    <InfoPill icon={CalendarDays} text={record.examDate || 'Date pending'} />
                    <InfoPill icon={ScrollText} text={`${record.reportingTime || '--'} | ${record.centerName || 'Center pending'}`} />
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <ActionButton icon={Printer} label="Print" onClick={() => onPrint(record)} />
                  <IconButton icon={Trash2} onClick={() => onDelete(record.id)} danger />
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState icon={Ticket} title="No admit cards yet" description="Save the first admit card record to prepare students for examination day." />
      )}
    </section>
  </div>
);

const EntryCard = ({ icon: Icon, title, description, buttonLabel, onClick }) => (
  <button
    onClick={onClick}
    className="group rounded-4xl border border-slate-200/80 bg-white p-7 text-left shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] transition hover:-translate-y-1.5 hover:border-indigo-200 hover:shadow-[0_24px_60px_-30px_rgba(99,102,241,0.32)]"
  >
    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#e0e7ff_0%,#ede9fe_100%)] text-indigo-700 transition group-hover:scale-105">
      <Icon size={24} />
    </div>
    <h3 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-3 text-sm leading-7 text-slate-500">{description}</p>
    <span className="mt-6 inline-flex text-[11px] font-black uppercase tracking-[0.22em] text-indigo-700">{buttonLabel}</span>
  </button>
);

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-indigo-50/80">{label}</p>
        <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-indigo-200/20 bg-indigo-200/10 text-indigo-50">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const FormTitle = ({ title, description }) => (
  <div>
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative min-w-65">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
    />
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option || 'empty-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
        </option>
      ))}
    </select>
  </div>
);

const FileUploadField = ({ label, fileName, onBrowse }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <label className="flex w-full cursor-pointer items-center justify-between gap-4 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-sm font-semibold text-slate-700 transition hover:border-indigo-300 hover:bg-white">
      <div className="min-w-0">
        <p className={`truncate ${fileName ? 'text-slate-900' : 'text-slate-400'}`}>
          {fileName || 'Click to upload file'}
        </p>
      </div>
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-950 text-white">
        <Upload size={18} />
      </div>
      <input type="file" className="hidden" onChange={onBrowse} />
    </label>
  </div>
);

const PrimaryButton = ({ type, icon: Icon, label }) => (
  <button
    type={type}
    className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-indigo-600"
  >
    <Icon size={15} />
    {label}
  </button>
);

const InfoPill = ({ icon: Icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    <Icon size={15} className="text-indigo-700" />
    <span>{text}</span>
  </div>
);

const ActionButton = ({ icon: Icon, label, onClick }) => (
  <button
    onClick={onClick}
    className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-700 transition hover:border-indigo-300 hover:text-indigo-700"
  >
    <Icon size={14} />
    {label}
  </button>
);

const IconButton = ({ icon: Icon, onClick, danger = false }) => (
  <button
    onClick={onClick}
    className={`inline-flex h-11 w-11 items-center justify-center rounded-2xl transition ${
      danger ? 'text-slate-400 hover:bg-rose-50 hover:text-rose-600' : 'text-slate-500 hover:bg-slate-100'
    }`}
  >
    <Icon size={18} />
  </button>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <Icon size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

export default ExaminationManagement;
