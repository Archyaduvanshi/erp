import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  Calendar,
  CheckCircle2,
  ClipboardCheck,
  FileText,
  IdCard,
  LayoutGrid,
  List,
  Mail,
  MapPin,
  Phone,
  Plus,
  QrCode,
  Search,
  ShieldCheck,
  Trash2,
  Upload,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const initialFormData = {
  firstName: '',
  lastName: '',
  dob: '',
  gender: 'Male',
  email: '',
  mobile: '',
  regDate: new Date().toISOString().split('T')[0],
  bloodGroup: '',
  address: '',
  guardianName: '',
  guardianPhone: '',
  prevSchool: '',
  category: 'Gen',
  admissionDate: '',
  enrollmentNo: '',
  assignedClass: '',
  admissionCategory: 'Regular',
  transportOptIn: 'no',
  hostelOptIn: 'no',
  transportStatus: 'inactive',
  hostelStatus: 'inactive',
  studentPortalPassword: '',
  documentType: '',
  otherDocumentName: '',
  fileUploadPath: '',
  documents: [],
  qrCodeData: '',
  cardExpiryDate: '',
  photoUrl: '',
};

const StudentManagement = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('list');
  const [currentStep, setCurrentStep] = useState(1);
  const [students, setStudents] = useState([]);
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [courseFilter, setCourseFilter] = useState('All Courses');
  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    setStudents(db.getAll('students'));
  }, []);

  const refreshStudents = () => {
    setStudents(db.getAll('students'));
  };

  const draftSystemId = formData.enrollmentNo ? `EDU-${formData.enrollmentNo}` : 'EDU-AUTO-ID';
  const draftQrCodeData = formData.qrCodeData || `${draftSystemId}-${formData.mobile || 'QR-PENDING'}`;

  const handleDocumentAdd = () => {
    const resolvedDocumentType = formData.documentType === 'Other' ? formData.otherDocumentName.trim() : formData.documentType;
    if (!resolvedDocumentType || !formData.fileUploadPath.trim()) return;

    const nextDocument = {
      id: Date.now(),
      documentType: resolvedDocumentType,
      fileUploadPath: formData.fileUploadPath,
    };

    setFormData({
      ...formData,
      documents: [...formData.documents, nextDocument],
      documentType: '',
      otherDocumentName: '',
      fileUploadPath: '',
    });
  };

  const handleDocumentRemove = (documentId) => {
    setFormData({
      ...formData,
      documents: formData.documents.filter((document) => document.id !== documentId),
    });
  };

  const handleDocumentBrowse = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFormData({
      ...formData,
      fileUploadPath: file.name,
    });
  };

  const handleSave = (e) => {
    e.preventDefault();

    const studentId = `EDU-${Math.floor(1000 + Math.random() * 9000)}`;
    const resolvedQrCodeData = formData.qrCodeData || `${studentId}-${formData.enrollmentNo || formData.mobile || 'STUDENT'}`;
    const resolvedPortalPassword = formData.studentPortalPassword.trim() || (
      formData.mobile
        ? formData.mobile.replace(/\s+/g, '').slice(-6)
        : (formData.enrollmentNo || studentId).replace(/\s+/g, '').slice(-6)
    );
    const newStudent = {
      ...formData,
      transportStatus: formData.transportOptIn === 'yes' ? formData.transportStatus : 'inactive',
      hostelStatus: formData.hostelOptIn === 'yes' ? formData.hostelStatus : 'inactive',
      facilities: {
        transport: {
          requested: formData.transportOptIn === 'yes',
          active: formData.transportOptIn === 'yes' && formData.transportStatus === 'active',
          status: formData.transportOptIn === 'yes' ? formData.transportStatus : 'inactive',
        },
        hostel: {
          requested: formData.hostelOptIn === 'yes',
          active: formData.hostelOptIn === 'yes' && formData.hostelStatus === 'active',
          status: formData.hostelOptIn === 'yes' ? formData.hostelStatus : 'inactive',
        },
      },
      systemId: studentId,
      qrCodeData: resolvedQrCodeData,
      studentPortalPassword: resolvedPortalPassword,
      status: 'Verified',
      createdAt: new Date().toISOString(),
    };

    db.save('students', newStudent);
    refreshStudents();
    setFormData(initialFormData);
    setActiveTab('list');
    setCurrentStep(1);
  };

  const handleDelete = (studentId) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;

    const shouldDelete = window.confirm('Delete this student record?');
    if (!shouldDelete) return;

    const key = `${tenantId}_students`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.filter((student) => student.id !== studentId);
    localStorage.setItem(key, JSON.stringify(updated));
    setStudents(updated);
  };

  const updateStudentFacilities = (studentId, updates) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;

    const key = `${tenantId}_students`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.map((student) => {
      if (student.id !== studentId) return student;
      const nextStudent = { ...student, ...updates };
      return {
        ...nextStudent,
        facilities: {
          transport: {
            requested: nextStudent.transportOptIn === 'yes' || nextStudent.transportOptIn === true,
            active: nextStudent.transportStatus === 'active',
            status: nextStudent.transportStatus || 'inactive',
          },
          hostel: {
            requested: nextStudent.hostelOptIn === 'yes' || nextStudent.hostelOptIn === true,
            active: nextStudent.hostelStatus === 'active',
            status: nextStudent.hostelStatus || 'inactive',
          },
        },
      };
    });
    localStorage.setItem(key, JSON.stringify(updated));
    setStudents(updated);
  };

  const availableCourses = ['All Courses', ...new Set(students.map((student) => student.assignedClass).filter(Boolean))];
  const filteredStudents = students.filter((student) => {
    const fullName = `${student.firstName} ${student.lastName}`.toLowerCase();
    const searchValue = searchTerm.toLowerCase();
    const matchesSearch =
      !searchValue ||
      fullName.includes(searchValue) ||
      student.email?.toLowerCase().includes(searchValue) ||
      student.systemId?.toLowerCase().includes(searchValue) ||
      student.assignedClass?.toLowerCase().includes(searchValue);
    const matchesCourse = courseFilter === 'All Courses' || student.assignedClass === courseFilter;
    return matchesSearch && matchesCourse;
  });

  const verifiedCount = students.filter((student) => student.status === 'Verified').length;
  const pendingCount = Math.max(students.length - verifiedCount, 0);

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f4f7fb_0%,#eef4ff_55%,#f9fbff_100%)] text-slate-900 selection:bg-cyan-500 selection:text-slate-950">
      <div className="border-b border-slate-200/70 bg-white/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-cyan-300 hover:text-cyan-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-cyan-600">Student Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Enrollment Studio</h1>
            </div>
          </div>

          <button
            onClick={() => {
              setActiveTab(activeTab === 'list' ? 'add' : 'list');
              setCurrentStep(1);
            }}
            className={`inline-flex items-center gap-2 rounded-full px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] transition ${
              activeTab === 'list'
                ? 'bg-slate-950 text-white shadow-lg shadow-slate-300 hover:bg-cyan-600'
                : 'border border-slate-200 bg-white text-slate-600 hover:border-rose-200 hover:text-rose-600'
            }`}
          >
            {activeTab === 'list' ? <Plus size={14} /> : <X size={14} />}
            {activeTab === 'list' ? 'Add Student' : 'Close Form'}
          </button>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        {activeTab === 'list' ? (
          <DirectoryView
            students={students}
            filteredStudents={filteredStudents}
            verifiedCount={verifiedCount}
            pendingCount={pendingCount}
            viewMode={viewMode}
            setViewMode={setViewMode}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            courseFilter={courseFilter}
            setCourseFilter={setCourseFilter}
            availableCourses={availableCourses}
            onCreate={() => setActiveTab('add')}
            onDelete={handleDelete}
            onFacilityToggle={updateStudentFacilities}
          />
        ) : (
          <EnrollmentWizard
            currentStep={currentStep}
            setCurrentStep={setCurrentStep}
            formData={formData}
            setFormData={setFormData}
            handleSave={handleSave}
            draftSystemId={draftSystemId}
            draftQrCodeData={draftQrCodeData}
            handleDocumentAdd={handleDocumentAdd}
            handleDocumentRemove={handleDocumentRemove}
            handleDocumentBrowse={handleDocumentBrowse}
          />
        )}
      </div>
    </div>
  );
};

const DirectoryView = ({
  students,
  filteredStudents,
  verifiedCount,
  pendingCount,
  viewMode,
  setViewMode,
  searchTerm,
  setSearchTerm,
  courseFilter,
  setCourseFilter,
  availableCourses,
  onCreate,
  onDelete,
  onFacilityToggle,
}) => (
  <div className="space-y-8">
    <section className="overflow-hidden rounded-4xl border border-slate-200/80 bg-slate-950 text-white shadow-[0_30px_80px_-40px_rgba(15,23,42,0.9)]">
      <div className="grid gap-8 px-7 py-8 lg:grid-cols-[1.5fr_0.9fr] lg:px-10 lg:py-10">
        <div className="relative">
          <div className="absolute -left-16 -top-16 h-40 w-40 rounded-full bg-cyan-400/15 blur-3xl" />
          <div className="absolute bottom-0 right-10 h-32 w-32 rounded-full bg-blue-500/10 blur-3xl" />
          <div className="relative">
            <p className="mb-3 text-[11px] font-black uppercase tracking-[0.32em] text-cyan-300">Control Center</p>
            <h2 className="max-w-2xl font-serif text-4xl font-black italic leading-none tracking-tight">
              Student records, enrollment flow, and academic visibility in one place.
            </h2>
            <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-300">
              Review active records, search by student or course, and start fresh admissions from a calmer dashboard.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={onCreate}
                className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-950 transition hover:bg-cyan-300"
              >
                <UserPlus size={14} />
                Start Enrollment
              </button>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-300">
                <ShieldCheck size={14} />
                {verifiedCount} verified records
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
          <StatCard label="Total Students" value={students.length} tone="cyan" icon={Users} />
          <StatCard label="Verified" value={verifiedCount} tone="emerald" icon={CheckCircle2} />
          <StatCard label="Needs Review" value={pendingCount} tone="amber" icon={ClipboardCheck} />
        </div>
      </div>
    </section>

    <section className="rounded-4xl border border-slate-200/80 bg-white p-5 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Directory</h3>
          <p className="mt-1 text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">
            {filteredStudents.length} of {students.length} records visible
          </p>
        </div>

        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative min-w-65">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search name, email, ID, class..."
              className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:bg-white focus:ring-4 focus:ring-cyan-100"
            />
          </div>

          <select
            value={courseFilter}
            onChange={(e) => setCourseFilter(e.target.value)}
            className="rounded-2xl border-2 border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-700 outline-none transition focus:border-cyan-500 focus:bg-white focus:ring-4 focus:ring-cyan-100"
          >
            {availableCourses.map((course) => (
              <option key={course} value={course}>
                {course}
              </option>
            ))}
          </select>

          <div className="inline-flex rounded-2xl border border-slate-200 bg-slate-50 p-1.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`rounded-xl p-2.5 transition ${viewMode === 'grid' ? 'bg-slate-950 text-white' : 'text-slate-400 hover:bg-white'}`}
            >
              <LayoutGrid size={18} />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`rounded-xl p-2.5 transition ${viewMode === 'table' ? 'bg-slate-950 text-white' : 'text-slate-400 hover:bg-white'}`}
            >
              <List size={18} />
            </button>
          </div>
        </div>
      </div>

      {filteredStudents.length > 0 ? (
        viewMode === 'grid' ? (
          <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {filteredStudents.map((student) => (
              <StudentCard key={student.id} student={student} onDelete={onDelete} onFacilityToggle={onFacilityToggle} />
            ))}
          </div>
        ) : (
          <div className="mt-6 overflow-hidden rounded-[1.75rem] border border-slate-200">
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-white">
                <tr className="text-[11px] font-black uppercase tracking-[0.24em]">
                  <th className="px-6 py-4">Student</th>
                  <th className="px-6 py-4">Contact</th>
                  <th className="px-6 py-4">Class / Section</th>
                  <th className="px-6 py-4">Facilities</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                {filteredStudents.map((student) => (
                  <tr key={student.id} className="transition hover:bg-cyan-50/60">
                    <td className="px-6 py-5">
                      <p className="text-sm font-black text-slate-950">{student.firstName} {student.lastName}</p>
                      <p className="mt-1 text-xs font-semibold text-slate-500">{student.systemId}</p>
                    </td>
                    <td className="px-6 py-5 text-sm font-semibold text-slate-600">{student.email || student.mobile || 'Not provided'}</td>
                    <td className="px-6 py-5 text-sm font-semibold text-slate-700">{student.assignedClass || 'Unassigned'}</td>
                    <td className="px-6 py-5"><FacilitySummary student={student} compact /></td>
                    <td className="px-6 py-5">
                      <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-700">
                        {student.status || 'Verified'}
                      </span>
                    </td>
                    <td className="px-6 py-5 text-right">
                      <button
                        onClick={() => onDelete(student.id)}
                        className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      ) : (
        <div className="mt-6 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
            <Users size={34} />
          </div>
          <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No matching student records</h4>
          <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">
            Clear the search, change the course filter, or create the first student entry for this institution.
          </p>
          <button
            onClick={onCreate}
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-slate-950 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-cyan-600"
          >
            <Plus size={14} />
            Create Student
          </button>
        </div>
      )}
    </section>
  </div>
);

const EnrollmentWizard = ({
  currentStep,
  setCurrentStep,
  formData,
  setFormData,
  handleSave,
  draftSystemId,
  draftQrCodeData,
  handleDocumentAdd,
  handleDocumentRemove,
  handleDocumentBrowse,
}) => (
  <div className="grid items-start gap-8 xl:grid-cols-[0.78fr_1.22fr]">
    <aside className="space-y-6 xl:sticky xl:top-8">
      <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)]">
        <p className="text-[11px] font-black uppercase tracking-[0.3em] text-cyan-600">Enrollment Steps</p>
        <div className="mt-6 space-y-5">
          <TimelineStep step={1} current={currentStep} title="Registration" desc="Basic student record" />
          <TimelineStep step={2} current={currentStep} title="Profile" desc="History and guardian details" />
          <TimelineStep step={3} current={currentStep} title="Admission" desc="Class, category, enrollment" />
          <TimelineStep step={4} current={currentStep} title="Documents" desc="Student locker and uploads" />
          <TimelineStep step={5} current={currentStep} title="ID Generation" desc="Auto ID card and QR" />
        </div>
      </section>

      <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#082f49_0%,#0f172a_58%,#020617_100%)] p-6 text-white shadow-[0_30px_80px_-40px_rgba(8,47,73,0.8)]">
        <p className="text-[11px] font-black uppercase tracking-[0.28em] text-cyan-300">Live Preview</p>
        <div className="mt-6 rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
          <div className="flex items-start justify-between">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/10 text-lg font-black uppercase text-cyan-100">
              {(formData.firstName?.[0] || 'N') + (formData.lastName?.[0] || 'S')}
            </div>
            <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-200">
              Draft
            </span>
          </div>
          <h3 className="mt-8 font-serif text-3xl font-black italic tracking-tight">
            {formData.firstName || 'New'} {formData.lastName || 'Student'}
          </h3>
          <p className="mt-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-300">
            {formData.assignedClass || 'Class / section pending'}
          </p>
          <div className="mt-8 space-y-3 text-sm text-slate-300">
            <PreviewRow icon={Mail} value={formData.email || 'Email not added'} />
            <PreviewRow icon={Phone} value={formData.mobile || 'Mobile not added'} />
            <PreviewRow icon={IdCard} value={draftSystemId} />
            <PreviewRow icon={FileText} value={`${formData.documents.length} document(s) added`} />
            <PreviewRow icon={QrCode} value={draftQrCodeData} />
          </div>
        </div>
      </section>
    </aside>

    <section className="rounded-[2.25rem] border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      {currentStep === 1 && (
        <div>
          <FormHeader eyebrow="Step 01" title="Student registration" desc="Capture the basic information that creates the student record inside the ERP." />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="First Name" value={formData.firstName} onChange={(e) => setFormData({ ...formData, firstName: e.target.value })} placeholder="Legal first name" />
            <CreativeInput label="Last Name" value={formData.lastName} onChange={(e) => setFormData({ ...formData, lastName: e.target.value })} placeholder="Legal surname" />
            <CreativeInput label="Personal Email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} placeholder="student@email.com" />
            <CreativeInput label="Mobile Number" value={formData.mobile} onChange={(e) => setFormData({ ...formData, mobile: e.target.value })} placeholder="+91 98XXX XXXXX" />
            <CreativeInput label="Date of Birth" type="date" value={formData.dob} onChange={(e) => setFormData({ ...formData, dob: e.target.value })} />
            <CreativeInput label="Registration Date" type="date" value={formData.regDate} onChange={(e) => setFormData({ ...formData, regDate: e.target.value })} />
            <div className="space-y-3">
              <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">Gender</label>
              <div className="grid grid-cols-3 gap-3">
                {['Male', 'Female', 'Other'].map((gender) => (
                  <button
                    key={gender}
                    type="button"
                    onClick={() => setFormData({ ...formData, gender })}
                    className={`rounded-2xl border-2 px-4 py-3 text-xs font-black uppercase tracking-[0.16em] transition ${
                      formData.gender === gender
                        ? 'border-cyan-500 bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-100'
                        : 'border-slate-200 bg-slate-50 text-slate-500 hover:border-cyan-300 hover:bg-white'
                    }`}
                  >
                    {gender}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <WizardButtons label="Continue to Profile" onNext={() => setCurrentStep(2)} />
        </div>
      )}

      {currentStep === 2 && (
        <div>
          <FormHeader eyebrow="Step 02" title="Profile management" desc="Maintain personal history, category information, guardian details, and permanent address." />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="Guardian Name" value={formData.guardianName} onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })} placeholder="Parent or guardian" />
            <CreativeInput label="Guardian Phone" value={formData.guardianPhone} onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })} placeholder="+91 98XXX XXXXX" />
            <CreativeInput label="Blood Group (Optional)" value={formData.bloodGroup} onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })} placeholder="A+, O-, AB+" />
            <CreativeInput label="Category" value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} placeholder="Gen / OBC / SC / ST" />
            <CreativeInput label="Previous School History (Optional)" value={formData.prevSchool} onChange={(e) => setFormData({ ...formData, prevSchool: e.target.value })} placeholder="Last school or college" />
            <div className="md:col-span-2">
              <CreativeTextarea label="Permanent Address" value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} placeholder="House number, street, area, city" />
            </div>
          </div>
          <WizardButtons label="Continue to Admission" onNext={() => setCurrentStep(3)} onBack={() => setCurrentStep(1)} />
        </div>
      )}

      {currentStep === 3 && (
        <div>
          <FormHeader eyebrow="Step 03" title="Admission management" desc="Track the student transition from applicant to enrolled student with institutional assignment data." />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="Admission Date" type="date" value={formData.admissionDate} onChange={(e) => setFormData({ ...formData, admissionDate: e.target.value })} />
            <CreativeInput label="Enrollment Number" value={formData.enrollmentNo} onChange={(e) => setFormData({ ...formData, enrollmentNo: e.target.value })} placeholder="2026-BTECH-014" />
            <CreativeInput label="Assigned Class / Section" value={formData.assignedClass} onChange={(e) => setFormData({ ...formData, assignedClass: e.target.value })} placeholder="B.Tech CSE / A" />
            <CreativeInput label="Admission Category" value={formData.admissionCategory} onChange={(e) => setFormData({ ...formData, admissionCategory: e.target.value })} placeholder="Regular / Lateral Entry" />
            <CreativeSelect
              label="Transport Facility At Admission"
              value={formData.transportOptIn}
              onChange={(e) => setFormData({
                ...formData,
                transportOptIn: e.target.value,
                transportStatus: e.target.value === 'yes' ? formData.transportStatus : 'inactive',
              })}
              options={['Select', 'yes', 'no']}
            />
            <CreativeSelect
              label="Hostel Facility At Admission"
              value={formData.hostelOptIn}
              onChange={(e) => setFormData({
                ...formData,
                hostelOptIn: e.target.value,
                hostelStatus: e.target.value === 'yes' ? formData.hostelStatus : 'inactive',
              })}
              options={['Select', 'yes', 'no']}
            />
            {formData.transportOptIn === 'yes' && (
              <CreativeSelect
                label="Transport Status"
                value={formData.transportStatus}
                onChange={(e) => setFormData({ ...formData, transportStatus: e.target.value })}
                options={['active', 'inactive']}
              />
            )}
            {formData.hostelOptIn === 'yes' && (
              <CreativeSelect
                label="Hostel Status"
                value={formData.hostelStatus}
                onChange={(e) => setFormData({ ...formData, hostelStatus: e.target.value })}
                options={['active', 'inactive']}
              />
            )}
            <div className="md:col-span-2">
              <CreativeInput
                label="Student Portal Password"
                type="password"
                value={formData.studentPortalPassword}
                onChange={(e) => setFormData({ ...formData, studentPortalPassword: e.target.value })}
                placeholder="Optional. Defaults to last 6 digits of mobile or enrollment"
              />
            </div>
          </div>
          <WizardButtons label="Continue to Documents" onNext={() => setCurrentStep(4)} onBack={() => setCurrentStep(2)} />
        </div>
      )}

      {currentStep === 4 && (
        <div>
          <FormHeader eyebrow="Step 04" title="Student documents" desc="Add documents one by one, submit each into the student locker, and continue after the required files are listed below." />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeSelect
              label="Document Type"
              value={formData.documentType}
              onChange={(e) => setFormData({ ...formData, documentType: e.target.value })}
              options={['Select', 'Aadhar', 'TC', 'Marksheet', 'Other']}
            />
            {formData.documentType === 'Other' && (
              <CreativeInput
                label="Document Name"
                value={formData.otherDocumentName}
                onChange={(e) => setFormData({ ...formData, otherDocumentName: e.target.value })}
                placeholder="Enter document name"
              />
            )}
            <DocumentUploadField label="File Upload" value={formData.fileUploadPath} onBrowse={handleDocumentBrowse} />
          </div>

          <div className="mt-5 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={handleDocumentAdd}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.18em] text-white transition hover:bg-cyan-600"
            >
              <Plus size={14} />
              Submit Document
            </button>
          </div>

          <div className="mt-8 rounded-[1.75rem] border border-slate-200 bg-slate-50 p-5">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">Submitted Documents</p>
                <p className="mt-2 text-sm font-semibold text-slate-700">{formData.documents.length} document(s) added</p>
              </div>
              <span className="rounded-full border border-cyan-200 bg-cyan-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-cyan-700">
                Multi-document ready
              </span>
            </div>

            {formData.documents.length > 0 ? (
              <div className="mt-5 grid gap-4 md:grid-cols-2">
                {formData.documents.map((document) => (
                  <div key={document.id} className="rounded-[1.4rem] border border-slate-200 bg-white p-4 shadow-sm">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-black text-slate-950">{document.documentType}</p>
                        <p className="mt-1 break-all text-xs font-semibold text-slate-500">{document.fileUploadPath}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDocumentRemove(document.id)}
                        className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <div className="mt-4 rounded-xl bg-slate-50 px-3 py-2 text-[11px] font-semibold text-slate-500">
                      Ready for student record
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-5 rounded-[1.4rem] border border-dashed border-slate-300 bg-white px-5 py-8 text-center text-sm font-medium text-slate-500">
                No documents submitted yet. Add each required file, then continue to ID generation.
              </div>
            )}
          </div>

          <WizardButtons
            label="Continue to ID Generation"
            onNext={() => {
              if (formData.documents.length > 0) setCurrentStep(5);
            }}
            onBack={() => setCurrentStep(3)}
            isDisabled={formData.documents.length === 0}
          />
        </div>
      )}

      {currentStep === 5 && (
        <div>
          <FormHeader eyebrow="Step 05" title="Student ID generation" desc="Generate the system identity, configure the ID card details, and review the complete record." />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="System-generated ID" value={draftSystemId} readOnly />
            <CreativeInput label="Barcode / QR Code Data" value={formData.qrCodeData} onChange={(e) => setFormData({ ...formData, qrCodeData: e.target.value })} placeholder={draftQrCodeData} />
            <CreativeInput label="Card Expiry Date" type="date" value={formData.cardExpiryDate} onChange={(e) => setFormData({ ...formData, cardExpiryDate: e.target.value })} />
            <CreativeInput label="Photo URL" value={formData.photoUrl} onChange={(e) => setFormData({ ...formData, photoUrl: e.target.value })} placeholder="https://cdn.example.com/photo.jpg" />
          </div>

          <div className="mt-8 rounded-4xl border border-slate-200 bg-[linear-gradient(135deg,#ecfeff_0%,#f8fafc_100%)] p-6 shadow-sm">
            <p className="text-[11px] font-black uppercase tracking-[0.24em] text-cyan-700">Auto-generated ID Card</p>
            <div className="mt-5 grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
              <div className="rounded-[1.6rem] bg-slate-950 p-6 text-white">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.24em] text-cyan-300">Student ID Card</p>
                    <h3 className="mt-3 font-serif text-3xl font-black italic">
                      {formData.firstName || 'New'} {formData.lastName || 'Student'}
                    </h3>
                    <p className="mt-2 text-[11px] font-black uppercase tracking-[0.2em] text-slate-300">
                      {formData.assignedClass || 'Class / section pending'}
                    </p>
                  </div>
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-white/10 text-lg font-black uppercase text-cyan-100">
                    {(formData.firstName?.[0] || 'N') + (formData.lastName?.[0] || 'S')}
                  </div>
                </div>
                <div className="mt-8 grid gap-3 text-sm text-slate-300">
                  <PreviewRow icon={IdCard} value={draftSystemId} />
                  <PreviewRow icon={Mail} value={formData.email || 'Email not added'} />
                  <PreviewRow icon={Phone} value={formData.mobile || 'Mobile not added'} />
                  <PreviewRow icon={Calendar} value={formData.cardExpiryDate || 'Expiry date pending'} />
                </div>
              </div>

              <div className="rounded-[1.6rem] border border-slate-200 bg-white p-6 text-center">
                <div className="mx-auto flex h-28 w-28 items-center justify-center rounded-3xl bg-slate-950 text-cyan-300">
                  <QrCode size={58} />
                </div>
                <p className="mt-5 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500">QR Payload</p>
                <p className="mt-3 break-all text-sm font-semibold text-slate-800">{formData.qrCodeData || draftQrCodeData}</p>
              </div>
            </div>
          </div>

          <div className="mt-8 grid gap-4 lg:grid-cols-2">
            <ReviewCard title="Registration">
              <ReviewLine label="Name" value={`${formData.firstName || '-'} ${formData.lastName || ''}`.trim()} />
              <ReviewLine label="Gender" value={formData.gender || '-'} />
              <ReviewLine label="Email" value={formData.email || '-'} />
              <ReviewLine label="Mobile" value={formData.mobile || '-'} />
              <ReviewLine label="Registration Date" value={formData.regDate || '-'} />
            </ReviewCard>

            <ReviewCard title="Profile">
              <ReviewLine label="Guardian" value={formData.guardianName || '-'} />
              <ReviewLine label="Blood Group" value={formData.bloodGroup || '-'} />
              <ReviewLine label="Category" value={formData.category || '-'} />
              <ReviewLine label="Previous School" value={formData.prevSchool || '-'} />
            </ReviewCard>

            <ReviewCard title="Admission">
              <ReviewLine label="Class / Section" value={formData.assignedClass || '-'} />
              <ReviewLine label="Enrollment" value={formData.enrollmentNo || '-'} />
              <ReviewLine label="Admission Date" value={formData.admissionDate || '-'} />
              <ReviewLine label="Admission Category" value={formData.admissionCategory || '-'} />
              <ReviewLine label="Transport" value={formData.transportOptIn === 'yes' ? `Requested | ${formData.transportStatus}` : 'Not requested'} />
              <ReviewLine label="Hostel" value={formData.hostelOptIn === 'yes' ? `Requested | ${formData.hostelStatus}` : 'Not requested'} />
              <ReviewLine
                label="Portal Password"
                value={formData.studentPortalPassword || (formData.mobile ? formData.mobile.replace(/\s+/g, '').slice(-6) : (formData.enrollmentNo || draftSystemId).replace(/\s+/g, '').slice(-6))}
              />
            </ReviewCard>

            <ReviewCard title="Documents & ID">
              <ReviewLine label="Total Documents" value={String(formData.documents.length)} />
              <ReviewLine label="Latest Document" value={formData.documents[formData.documents.length - 1]?.documentType || '-'} />
              <ReviewLine label="Latest File" value={formData.documents[formData.documents.length - 1]?.fileUploadPath || '-'} />
              <ReviewLine label="System ID" value={draftSystemId} />
              <ReviewLine label="QR / Barcode" value={formData.qrCodeData || draftQrCodeData} />
            </ReviewCard>
          </div>

          <WizardButtons label="Save Student Record" onNext={handleSave} onBack={() => setCurrentStep(4)} isFinal />
        </div>
      )}
    </section>
  </div>
);

const StatCard = ({ label, value, tone, icon: Icon }) => {
  const toneClasses = {
    cyan: 'border-cyan-400/20 bg-cyan-400/10 text-cyan-100',
    emerald: 'border-emerald-400/20 bg-emerald-400/10 text-emerald-100',
    amber: 'border-amber-400/20 bg-amber-400/10 text-amber-100',
  };

  return (
    <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-300">{label}</p>
          <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
        </div>
        <div className={`flex h-12 w-12 items-center justify-center rounded-2xl border ${toneClasses[tone]}`}>
          <Icon size={20} />
        </div>
      </div>
    </div>
  );
};

const StudentCard = ({ student, onDelete, onFacilityToggle }) => (
  <article className="group overflow-hidden rounded-[1.9rem] border border-slate-200/80 bg-white p-6 shadow-[0_16px_40px_-28px_rgba(15,23,42,0.35)] transition hover:-translate-y-1 hover:shadow-[0_24px_50px_-28px_rgba(6,182,212,0.35)]">
    <div className="flex items-start justify-between">
      <div className="flex items-center gap-4">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#cffafe_0%,#dbeafe_100%)] text-lg font-black uppercase text-slate-900">
          {(student.firstName?.[0] || 'N') + (student.lastName?.[0] || 'S')}
        </div>
        <div>
          <h4 className="text-lg font-black tracking-tight text-slate-950">{student.firstName} {student.lastName}</h4>
          <p className="mt-1 text-[11px] font-black uppercase tracking-[0.18em] text-cyan-700">{student.assignedClass || 'Unassigned'}</p>
        </div>
      </div>

      <button
        onClick={() => onDelete(student.id)}
        className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
      >
        <Trash2 size={16} />
      </button>
    </div>

    <div className="mt-6 grid gap-3 text-sm text-slate-600">
      <PreviewRow icon={Mail} value={student.email || 'No email added'} light />
      <PreviewRow icon={Phone} value={student.mobile || 'No phone added'} light />
      <PreviewRow icon={MapPin} value={student.address || 'Address not available'} light />
    </div>

    <div className="mt-6 rounded-[1.4rem] border border-slate-200 bg-slate-50 p-4">
      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Facilities</p>
      <div className="mt-3">
        <FacilitySummary student={student} />
      </div>
      <div className="mt-4 space-y-3">
        <FacilityToggleRow
          label="Transport"
          requested={student.transportOptIn === 'yes' || student.transportOptIn === true}
          status={student.transportStatus || 'inactive'}
          onToggle={() => onFacilityToggle(student.id, {
            transportOptIn: 'yes',
            transportStatus: student.transportStatus === 'active' ? 'inactive' : 'active',
          })}
        />
        <FacilityToggleRow
          label="Hostel"
          requested={student.hostelOptIn === 'yes' || student.hostelOptIn === true}
          status={student.hostelStatus || 'inactive'}
          onToggle={() => onFacilityToggle(student.id, {
            hostelOptIn: 'yes',
            hostelStatus: student.hostelStatus === 'active' ? 'inactive' : 'active',
          })}
        />
      </div>
    </div>

    <div className="mt-6 flex items-center justify-between border-t border-slate-200 pt-4">
      <div>
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">System ID</p>
        <p className="mt-1 text-sm font-semibold text-slate-700">{student.systemId}</p>
      </div>
      <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-700">
        {student.status || 'Verified'}
      </span>
    </div>
  </article>
);

const TimelineStep = ({ step, current, title, desc }) => (
  <div className={`flex gap-4 transition ${current >= step ? 'opacity-100' : 'opacity-45'}`}>
    <div
      className={`mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border-2 text-sm font-black transition ${
        current === step
          ? 'border-cyan-500 bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-100'
          : current > step
            ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
            : 'border-slate-200 bg-slate-50 text-slate-400'
      }`}
    >
      {current > step ? <CheckCircle2 size={18} /> : step}
    </div>
    <div>
      <p className="text-sm font-black text-slate-950">{title}</p>
      <p className="mt-1 text-sm leading-6 text-slate-500">{desc}</p>
    </div>
  </div>
);

const FormHeader = ({ eyebrow, title, desc }) => (
  <div>
    <p className="text-[11px] font-black uppercase tracking-[0.3em] text-cyan-600">{eyebrow}</p>
    <h2 className="mt-3 font-serif text-4xl font-black italic leading-none tracking-tight text-slate-950">{title}</h2>
    <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-500">{desc}</p>
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:bg-white focus:ring-4 focus:ring-cyan-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-cyan-500 focus:bg-white focus:ring-4 focus:ring-cyan-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option} value={option === 'Select' ? '' : option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);

const DocumentUploadField = ({ label, value, onBrowse }) => (
  <div className="space-y-2.5 md:col-span-2">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <label className="flex w-full cursor-pointer items-center justify-between gap-4 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-sm font-semibold text-slate-700 transition hover:border-cyan-300 hover:bg-white">
      <div className="min-w-0">
        <p className={`truncate ${value ? 'text-slate-900' : 'text-slate-400'}`}>
          {value || 'Click anywhere in this field to browse and select a file'}
        </p>
      </div>
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-950 text-white">
        <Upload size={18} />
      </div>
      <input type="file" className="hidden" onChange={onBrowse} />
    </label>
  </div>
);

const CreativeTextarea = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <textarea
      className="min-h-32 w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:bg-white focus:ring-4 focus:ring-cyan-100"
      {...props}
    />
  </div>
);

const WizardButtons = ({ label, onNext, onBack, isFinal, isDisabled = false }) => (
  <div className="mt-10 flex flex-col gap-3 border-t border-slate-200 pt-6 sm:flex-row">
    {onBack && (
      <button
        type="button"
        onClick={onBack}
        className="inline-flex flex-1 items-center justify-center rounded-2xl border-2 border-slate-200 bg-white px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
      >
        Back
      </button>
    )}
    <button
      type="button"
      onClick={onNext}
      disabled={isDisabled}
      className={`inline-flex flex-[1.5] items-center justify-center gap-2 rounded-2xl px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] transition ${
        isDisabled
          ? 'cursor-not-allowed bg-slate-200 text-slate-400'
          : isFinal
            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100 hover:bg-emerald-700'
            : 'bg-slate-950 text-white shadow-lg shadow-slate-300 hover:bg-cyan-600'
      }`}
    >
      {label}
      <ArrowRight size={14} />
    </button>
  </div>
);

const PreviewRow = ({ icon: Icon, value, light = false }) => (
  <div className={`flex items-center gap-3 rounded-2xl px-3 py-2 ${light ? 'bg-slate-50 text-slate-600' : 'bg-white/5 text-slate-200'}`}>
    <Icon size={15} className={light ? 'text-cyan-700' : 'text-cyan-300'} />
    <span className="truncate text-sm font-medium">{value}</span>
  </div>
);

const ReviewCard = ({ title, children }) => (
  <div className="rounded-[1.75rem] border border-slate-200 bg-slate-50 p-5">
    <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">{title}</p>
    <div className="mt-4 space-y-3">{children}</div>
  </div>
);

const ReviewLine = ({ label, value }) => (
  <div className="flex items-start justify-between gap-4 border-b border-slate-200/80 pb-3 last:border-b-0 last:pb-0">
    <span className="text-xs font-black uppercase tracking-[0.16em] text-slate-500">{label}</span>
    <span className="text-sm font-semibold text-slate-800">{value}</span>
  </div>
);

const FacilitySummary = ({ student, compact = false }) => {
  const transportRequested = student.transportOptIn === 'yes' || student.transportOptIn === true;
  const hostelRequested = student.hostelOptIn === 'yes' || student.hostelOptIn === true;
  const classes = compact ? 'space-y-1 text-xs font-bold text-slate-600' : 'space-y-1 text-sm font-semibold text-slate-700';

  return (
    <div className={classes}>
      <div>Transport: {transportRequested ? (student.transportStatus || 'inactive') : 'not requested'}</div>
      <div>Hostel: {hostelRequested ? (student.hostelStatus || 'inactive') : 'not requested'}</div>
    </div>
  );
};

const FacilityToggleRow = ({ label, requested, status, onToggle }) => (
  <div className="flex items-center justify-between gap-3">
    <div>
      <p className="text-sm font-black text-slate-900">{label}</p>
      <p className="text-xs font-semibold text-slate-500">{requested ? `Requested | ${status}` : 'Not requested yet'}</p>
    </div>
    <button
      type="button"
      onClick={onToggle}
      className={`rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] transition ${status === 'active' ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}
    >
      {status === 'active' ? 'Deactivate' : 'Activate'}
    </button>
  </div>
);

export default StudentManagement;
