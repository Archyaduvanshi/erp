import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  BookCopy,
  BookOpen,
  Library,
  Plus,
  ScrollText,
  Search,
  Tag,
  Trash2,
} from 'lucide-react';
import { db } from '../../utils/db';

const initialBookForm = {
  className: '',
  subjectName: '',
  academicYear: '2026-27',
  notes: '',
};

const initialBookEntry = {
  publisher: '',
  language: 'English',
};

const CourseSubjectManagement = () => {
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  const [bookMappings, setBookMappings] = useState([]);
  const [bookForm, setBookForm] = useState(initialBookForm);
  const [bookEntry, setBookEntry] = useState(initialBookEntry);
  const [pendingBooks, setPendingBooks] = useState([]);
  const [searchValue, setSearchValue] = useState('');
  const [classFilter, setClassFilter] = useState('All Classes');

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setStudents(db.getAll('students'));
    setBookMappings(db.getAll('course_books'));
  };

  const availableClasses = useMemo(() => {
    const classes = [...new Set(students.map((student) => student.assignedClass?.trim()).filter(Boolean))];
    return classes.sort((a, b) => a.localeCompare(b));
  }, [students]);

  const availableSubjects = useMemo(() => {
    const subjects = [...new Set(bookMappings.map((record) => record.subjectName?.trim()).filter(Boolean))];
    return subjects.sort((a, b) => a.localeCompare(b));
  }, [bookMappings]);

  const filteredMappings = useMemo(() => {
    const query = searchValue.trim().toLowerCase();
    return bookMappings.filter((record) => {
      const matchesClass = classFilter === 'All Classes' || record.className === classFilter;
      if (!matchesClass) return false;
      if (!query) return true;

      return (
        record.className?.toLowerCase().includes(query) ||
        record.subjectName?.toLowerCase().includes(query) ||
        record.publisher?.toLowerCase().includes(query) ||
        record.language?.toLowerCase().includes(query) ||
        record.academicYear?.toLowerCase().includes(query)
      );
    });
  }, [bookMappings, classFilter, searchValue]);

  const groupedMappings = useMemo(() => {
    return filteredMappings.reduce((groups, record) => {
      const groupKey = record.className || 'Unassigned Class';
      if (!groups[groupKey]) groups[groupKey] = [];
      groups[groupKey].push(record);
      return groups;
    }, {});
  }, [filteredMappings]);

  const totalClasses = new Set(bookMappings.map((record) => record.className).filter(Boolean)).size;
  const totalSubjects = new Set(bookMappings.map((record) => `${record.className}-${record.subjectName}`).filter(Boolean)).size;
  const totalPendingBooks = pendingBooks.length;

  const handleAddBook = () => {
    const nextBook = {
      publisher: bookEntry.publisher.trim(),
      language: bookEntry.language.trim(),
    };

    if (!nextBook.publisher || !nextBook.language) return;

    setPendingBooks((current) => [...current, { ...nextBook, id: Date.now() + current.length }]);
    setBookEntry(initialBookEntry);
  };

  const handleRemovePendingBook = (bookId) => {
    setPendingBooks((current) => current.filter((book) => book.id !== bookId));
  };

  const handleSave = (e) => {
    e.preventDefault();

    const normalizedForm = {
      className: bookForm.className.trim(),
      subjectName: bookForm.subjectName.trim(),
      academicYear: bookForm.academicYear.trim(),
      notes: bookForm.notes.trim(),
    };

    if (!normalizedForm.className || !normalizedForm.subjectName || pendingBooks.length === 0) return;

    pendingBooks.forEach((book) => {
      db.save('course_books', {
        ...normalizedForm,
        publisher: book.publisher,
        language: book.language,
      });
    });

    setBookForm(initialBookForm);
    setBookEntry(initialBookEntry);
    setPendingBooks([]);
    refreshData();
  };

  const handleDelete = (recordId) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;
    if (!window.confirm('Delete this course and book mapping?')) return;

    const key = `${tenantId}_course_books`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.filter((record) => record.id !== recordId);
    localStorage.setItem(key, JSON.stringify(updated));
    refreshData();
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#fffdf7_0%,#fff7ed_45%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-amber-300 hover:text-amber-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-amber-600">Course And Subject</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Class Book Mapping Desk</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#78350f_0%,#451a03_55%,#0f172a_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(120,53,15,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-amber-200">Curriculum Register</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Decide which class studies which subject and which book goes to students.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-amber-50/80">
                Map books class by class with subject name, publisher, language, and academic year. This works for both school and college sessions under each institution.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Mapped Books" value={bookMappings.length} icon={Library} />
              <MetricCard label="Classes Covered" value={totalClasses} icon={BookOpen} />
              <MetricCard label="Subject Entries" value={totalSubjects} icon={ScrollText} />
              <MetricCard label="Student Classes" value={availableClasses.length} icon={Tag} />
            </div>
          </div>
        </section>

        <div className="mt-8 grid gap-8 xl:grid-cols-[0.92fr_1.08fr]">
          <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
            <FormTitle title="Add Class Book Mapping" description="Choose the class, define the subject, and attach multiple book entries with publisher and language details." />
            <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={handleSave}>
              <CreativeSelect
                label="Class / Section"
                value={bookForm.className}
                onChange={(e) => setBookForm({ ...bookForm, className: e.target.value })}
                options={['', ...availableClasses]}
                renderOptionLabel={(value) => value || 'Select class'}
              />
              <CreativeInput
                label="Subject Name"
                list="saved-subjects"
                value={bookForm.subjectName}
                onChange={(e) => setBookForm({ ...bookForm, subjectName: e.target.value })}
                placeholder="Mathematics"
              />
              <CreativeInput
                label="Academic Year"
                value={bookForm.academicYear}
                onChange={(e) => setBookForm({ ...bookForm, academicYear: e.target.value })}
                placeholder="2026-27"
              />
              <div className="md:col-span-2">
                <CreativeTextarea
                  label="Subject Notes"
                  value={bookForm.notes}
                  onChange={(e) => setBookForm({ ...bookForm, notes: e.target.value })}
                  placeholder="Optional notes like semester use, lab manual, elective use, or board-specific instruction"
                />
              </div>
              <div className="md:col-span-2 mt-2 rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-[0.24em] text-amber-700">Books Under This Subject</p>
                    <p className="mt-2 text-sm font-semibold text-slate-600">
                      Add multiple books one by one, then save the whole class and subject set together.
                    </p>
                  </div>
                  <span className="rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-amber-700">
                    {totalPendingBooks} pending
                  </span>
                </div>

                <div className="mt-5 grid gap-5 md:grid-cols-2">
                  <CreativeInput
                    label="Publisher"
                    value={bookEntry.publisher}
                    onChange={(e) => setBookEntry({ ...bookEntry, publisher: e.target.value })}
                    placeholder="NCERT / S. Chand"
                  />
                  <CreativeSelect
                    label="Language"
                    value={bookEntry.language}
                    onChange={(e) => setBookEntry({ ...bookEntry, language: e.target.value })}
                    options={['English', 'Hindi', 'Bilingual']}
                  />
                  <div className="md:col-span-2">
                    <button
                      type="button"
                      onClick={handleAddBook}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-amber-800 transition hover:bg-amber-100"
                    >
                      <Plus size={15} />
                      Add This Book To List
                    </button>
                  </div>
                </div>

                {pendingBooks.length > 0 ? (
                  <div className="mt-6 grid gap-4">
                    {pendingBooks.map((book) => (
                      <div key={book.id} className="rounded-[1.4rem] border border-slate-200 bg-white p-4 shadow-sm">
                        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                          <div className="space-y-2">
                            <div className="flex flex-wrap gap-2">
                              <InfoPill icon={Library} text={book.publisher || 'Publisher not added'} />
                              <InfoPill icon={BookOpen} text={book.language || 'Language not added'} />
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemovePendingBook(book.id)}
                            className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="mt-6 rounded-[1.4rem] border border-dashed border-slate-300 bg-white px-5 py-8 text-center text-sm font-medium text-slate-500">
                    No books added yet. Add multiple books here for the same class and subject.
                  </div>
                )}
              </div>
              <div className="md:col-span-2">
                <PrimaryButton type="submit" icon={BookCopy} label="Save All Books For Subject" />
              </div>
            </form>
            <datalist id="saved-subjects">
              {availableSubjects.map((subject) => (
                <option key={subject} value={subject} />
              ))}
            </datalist>
          </section>

          <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <FormTitle title="Saved Mappings" description="Review which class contains which subject entries, along with publisher and language details." />
              <div className="flex flex-col gap-3 md:flex-row md:items-center">
                <SearchInput value={searchValue} onChange={setSearchValue} placeholder="Search class, subject, publisher, language..." />
                <CreativeSelect
                  label="Class Filter"
                  value={classFilter}
                  onChange={(e) => setClassFilter(e.target.value)}
                  options={['All Classes', ...availableClasses]}
                />
              </div>
            </div>

            {filteredMappings.length > 0 ? (
              <div className="mt-8 space-y-6">
                {Object.entries(groupedMappings).map(([className, records]) => (
                  <div key={className}>
                    <div className="mb-4 flex items-center justify-between gap-4">
                      <div>
                        <h3 className="text-lg font-black tracking-tight text-slate-950">{className}</h3>
                        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-amber-700">{records.length} book entries</p>
                      </div>
                    </div>

                    <div className="grid gap-5">
                      {records.map((record) => (
                        <article key={record.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                            <div className="space-y-3">
                              <div className="flex items-center gap-3">
                                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-700">
                                  <BookOpen size={20} />
                                </div>
                                <div>
                                  <h4 className="text-lg font-black tracking-tight text-slate-950">{record.publisher || 'Publisher not added'}</h4>
                                  <p className="text-[11px] font-black uppercase tracking-[0.18em] text-amber-700">{record.subjectName || 'Subject pending'}</p>
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <InfoPill icon={Library} text={record.publisher || 'Publisher not added'} />
                                <InfoPill icon={BookOpen} text={`${record.language || 'Language'} • ${record.academicYear || 'Year pending'}`} />
                              </div>
                              {record.notes ? (
                                <p className="text-sm font-semibold leading-6 text-slate-600">{record.notes}</p>
                              ) : null}
                            </div>

                            <button
                              onClick={() => handleDelete(record.id)}
                              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </article>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Library}
                title="No course mappings yet"
                description="Add the first subject and book entry so classes can be linked with their required student materials."
              />
            )}
          </section>
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-amber-50/80">{label}</p>
        <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-amber-200/20 bg-amber-200/10 text-amber-50">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const FormTitle = ({ title, description }) => (
  <div>
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative min-w-65">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:bg-white focus:ring-4 focus:ring-amber-100"
    />
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:bg-white focus:ring-4 focus:ring-amber-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-amber-500 focus:bg-white focus:ring-4 focus:ring-amber-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option || 'empty-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
        </option>
      ))}
    </select>
  </div>
);

const CreativeTextarea = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <textarea
      className="min-h-32 w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-amber-500 focus:bg-white focus:ring-4 focus:ring-amber-100"
      {...props}
    />
  </div>
);

const PrimaryButton = ({ type, icon: Icon, label }) => (
  <button
    type={type}
    className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-amber-600"
  >
    <Icon size={15} />
    {label}
  </button>
);

const InfoPill = ({ icon: Icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    <Icon size={15} className="text-amber-700" />
    <span>{text}</span>
  </div>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <Icon size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

export default CourseSubjectManagement;
