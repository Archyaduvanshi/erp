import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CalendarClock,
  Clock3,
  Download,
  DoorOpen,
  FileText,
  GraduationCap,
  Search,
  ShieldCheck,
  Trash2,
  Upload,
  UserRound,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const initialExamSlotForm = {
  examTitle: '',
  className: '',
  subjectName: '',
  examDate: '',
  dayOfWeek: 'Monday',
  timeFrom: '',
  timeTo: '',
  roomId: '',
  invigilatorName: '',
  examDuration: '',
  studentSeatingRange: '',
};

const initialTemplateForm = {
  schoolName: '',
  lectureCount: '8',
  firstLectureStart: '08:00',
  lectureLength: '45',
  lunchLength: '30',
};

const TimetableManagement = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [activePage, setActivePage] = useState('home');
  const [students] = useState(() => db.getAll('students'));
  const [teachers] = useState(() => db.getAll('teachers'));
  const [classTimetables, setClassTimetables] = useState(() => db.getAll('timetable_class_slots'));
  const [examSlots, setExamSlots] = useState(() => db.getAll('timetable_exam_slots'));
  const [selectedClass, setSelectedClass] = useState('');
  const [examSlotForm, setExamSlotForm] = useState(initialExamSlotForm);
  const [classSearch, setClassSearch] = useState('');
  const [examSearch, setExamSearch] = useState('');
  const [previewRecord, setPreviewRecord] = useState(null);
  const [classTimetableAction, setClassTimetableAction] = useState('');
  const [savedTemplateDrafts, setSavedTemplateDrafts] = useState(() => db.getAll('timetable_template_drafts'));
  const [templateForm, setTemplateForm] = useState(() => ({
    ...initialTemplateForm,
    schoolName: session?.instituteName || '',
  }));
  const [generatedTemplateDraft, setGeneratedTemplateDraft] = useState(null);

  const refreshTimetables = () => {
    setClassTimetables(db.getAll('timetable_class_slots'));
    setExamSlots(db.getAll('timetable_exam_slots'));
    setSavedTemplateDrafts(db.getAll('timetable_template_drafts'));
  };

  const teacherSession = useMemo(() => {
    if (!session || session.role !== 'teacher') return null;
    return teachers.find((teacher) => String(teacher.id) === String(session.teacherId)) || null;
  }, [session, teachers]);

  const teacherName = teacherSession
    ? `${teacherSession.firstName || ''} ${teacherSession.lastName || ''}`.trim() || teacherSession.teacherSystemId || 'Teacher'
    : '';

  const teacherClassOptions = useMemo(() => {
    if (!teacherSession?.assignedClass) return [];
    return teacherSession.assignedClass
      .split(',')
      .map((className) => className.trim())
      .filter(Boolean);
  }, [teacherSession]);

  const classOptions = useMemo(() => {
    const classes = [...new Set(students.map((student) => student.assignedClass).filter(Boolean))].sort(compareClassNames);
    return teacherSession ? classes.filter((className) => teacherClassOptions.includes(className)) : classes;
  }, [students, teacherClassOptions, teacherSession]);

  const filteredClassOptions = useMemo(() => {
    const query = classSearch.trim().toLowerCase();
    return classOptions.filter((className) => {
      if (!query) return true;
      return className.toLowerCase().includes(query);
    });
  }, [classOptions, classSearch]);

  const teacherOptions = useMemo(() => {
    return teachers
      .map((teacher) => {
        const displayName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || 'Unnamed Teacher';
        const teacherCode = teacher.teacherSystemId || teacher.employeeId || String(teacher.id || '').trim();
        return {
          value: teacherCode ? `${displayName} (${teacherCode})` : displayName,
          label: teacherCode ? `${displayName} (${teacherCode})` : displayName,
          assignedClass: teacher.assignedClass || '',
        };
      })
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [teachers]);

  const selectedClassTeacherOptions = useMemo(() => {
    if (!selectedClass) return teacherOptions;
    const exactMatches = teacherOptions.filter((teacher) => teacher.assignedClass === selectedClass);
    return exactMatches.length ? exactMatches : teacherOptions;
  }, [selectedClass, teacherOptions]);

  const selectedClassRecord = useMemo(() => {
    return classTimetables.find((record) => record.className === selectedClass);
  }, [classTimetables, selectedClass]);

  const selectedTemplateDraftRecord = useMemo(() => {
    return savedTemplateDrafts.find((record) => record.className === selectedClass) || null;
  }, [savedTemplateDrafts, selectedClass]);

  const visibleClassTimetables = useMemo(() => {
    if (!teacherSession) return classTimetables;
    return classTimetables.filter((record) => teacherClassOptions.includes(record.className));
  }, [classTimetables, teacherClassOptions, teacherSession]);

  const filteredExamSlots = useMemo(() => {
    const query = examSearch.trim().toLowerCase();
    return examSlots
      .filter((slot) => {
        if (!teacherSession) return true;
        return teacherClassOptions.includes(slot.className) || slot.invigilatorName === teacherName;
      })
      .filter((slot) => {
        if (!query) return true;
        return (
          slot.examTitle?.toLowerCase().includes(query) ||
          slot.className?.toLowerCase().includes(query) ||
          slot.subjectName?.toLowerCase().includes(query) ||
          slot.invigilatorName?.toLowerCase().includes(query) ||
          slot.roomId?.toLowerCase().includes(query) ||
          slot.studentSeatingRange?.toLowerCase().includes(query)
        );
      })
      .sort((a, b) => new Date(a.examDate || 0) - new Date(b.examDate || 0) || sortByDayAndTime(a, b));
  }, [examSearch, examSlots, teacherClassOptions, teacherName, teacherSession]);

  const totalClassSlots = visibleClassTimetables.length;
  const teacherCoverage = classOptions.length;
  const roomCoverage = new Set(filteredExamSlots.map((slot) => slot.roomId).filter(Boolean)).size;
  const examCount = filteredExamSlots.length;

  const handleClassTimetableUpload = (e) => {
    const file = e.target.files?.[0];
    const input = e.target;
    if (!file || !selectedClass) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const now = new Date().toISOString();
      const payload = {
        id: Date.now(),
        className: selectedClass,
        fileName: file.name,
        fileData: String(reader.result || ''),
        fileType: file.type || 'application/octet-stream',
        uploadedAt: now,
        createdAt: now,
      };
      const remaining = db.getAll('timetable_class_slots').filter((record) => record.className !== selectedClass);
      replaceModuleRecords('timetable_class_slots', [...remaining, payload]);
      refreshTimetables();
      input.value = '';
    };
    reader.readAsDataURL(file);
  };

  const handleSaveExamSlot = (e) => {
    e.preventDefault();
    const payload = {
      ...examSlotForm,
      examTitle: examSlotForm.examTitle.trim(),
      className: examSlotForm.className.trim(),
      subjectName: examSlotForm.subjectName.trim(),
      roomId: examSlotForm.roomId.trim(),
      invigilatorName: examSlotForm.invigilatorName.trim(),
      examDuration: examSlotForm.examDuration.trim(),
      studentSeatingRange: examSlotForm.studentSeatingRange.trim(),
    };
    if (!payload.examTitle || !payload.className || !payload.subjectName || !payload.examDate || !payload.timeFrom || !payload.timeTo || !payload.roomId || !payload.invigilatorName) return;
    if (payload.timeTo <= payload.timeFrom) return;
    db.save('timetable_exam_slots', payload);
    setExamSlotForm(initialExamSlotForm);
    refreshTimetables();
  };

  const handleDelete = (module, id, message) => {
    if (!window.confirm(message)) return;
    replaceModuleRecords(module, db.getAll(module).filter((record) => record.id !== id));
    if (previewRecord?.id === id) setPreviewRecord(null);
    refreshTimetables();
  };

  const handleGenerateTemplate = () => {
    if (!selectedClass) return;

    const lectureCount = Math.max(1, Number(templateForm.lectureCount) || 0);
    const lectureLength = Math.max(1, Number(templateForm.lectureLength) || 0);
    const lunchLength = Math.max(0, Number(templateForm.lunchLength) || 0);
    const schoolName = templateForm.schoolName.trim() || session?.instituteName || 'School Timetable';
    const lecturePlan = buildLecturePlan(templateForm.firstLectureStart, lectureCount, lectureLength, lunchLength);
    setGeneratedTemplateDraft({
      className: selectedClass,
      schoolName,
      lecturePlan,
      lectureCount,
      firstLectureStart: templateForm.firstLectureStart,
      lectureLength,
      lunchLength,
      rows: classTemplateDays.map((day) => ({
        day,
        slots: lecturePlan.map(() => ({ subjectName: '', teacherName: '' })),
      })),
    });
    setActivePage('template-editor');
  };

  const handleDraftCellChange = (dayIndex, slotIndex, field, value) => {
    setGeneratedTemplateDraft((current) => {
      if (!current) return current;

      return {
        ...current,
        rows: current.rows.map((row, currentDayIndex) => (
          currentDayIndex !== dayIndex
            ? row
            : {
                ...row,
                slots: row.slots.map((slot, currentSlotIndex) => (
                  currentSlotIndex !== slotIndex ? slot : { ...slot, [field]: value }
                )),
              }
        )),
      };
    });
  };

  const handleSaveGeneratedTemplate = () => {
    if (!generatedTemplateDraft || !selectedClass) return;

    const now = new Date().toISOString();
    const payload = {
      id: Date.now(),
      className: selectedClass,
      fileName: buildTimetableTemplateFileName(selectedClass),
      fileData: buildTimetableTemplateDataUri(generatedTemplateDraft),
      fileType: 'text/html',
      uploadedAt: now,
      createdAt: now,
      templateData: generatedTemplateDraft,
      templateMeta: {
        schoolName: generatedTemplateDraft.schoolName,
        lectureCount: generatedTemplateDraft.lectureCount,
        firstLectureStart: generatedTemplateDraft.firstLectureStart,
        lectureLength: generatedTemplateDraft.lectureLength,
        lunchLength: generatedTemplateDraft.lunchLength,
      },
    };

    const remaining = db.getAll('timetable_class_slots').filter((record) => record.className !== selectedClass);
    replaceModuleRecords('timetable_class_slots', [...remaining, payload]);
    replaceModuleRecords('timetable_template_drafts', db.getAll('timetable_template_drafts').filter((record) => record.className !== selectedClass));
    refreshTimetables();
    setGeneratedTemplateDraft(null);
    setClassTimetableAction('');
    setActivePage('class');
  };

  const handleSaveTemplateDraft = () => {
    if (!generatedTemplateDraft || !selectedClass) return;

    const now = new Date().toISOString();
    const payload = {
      id: Date.now(),
      className: selectedClass,
      draftData: generatedTemplateDraft,
      updatedAt: now,
      createdAt: now,
    };

    const remaining = db.getAll('timetable_template_drafts').filter((record) => record.className !== selectedClass);
    replaceModuleRecords('timetable_template_drafts', [...remaining, payload]);
    refreshTimetables();
  };

  const handleOpenSavedDraft = () => {
    if (!selectedTemplateDraftRecord?.draftData) return;
    setGeneratedTemplateDraft(selectedTemplateDraftRecord.draftData);
    setActivePage('template-editor');
  };

  const handleCancelTemplateEditor = () => {
    setGeneratedTemplateDraft(null);
    setActivePage('class');
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f7fbff_0%,#effaf5_36%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(session?.role === 'teacher' ? '/teacher' : '/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Timetable Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Time And Resource Planner</h1>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#0f766e_0%,#047857_48%,#111827_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(6,78,59,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-200">Schedule Operations</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Visualize class periods, teacher allocation, rooms, and exam schedules.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-emerald-50/80">
                {teacherSession
                  ? `Only timetable records for ${teacherName || 'this teacher'} and assigned teaching classes are shown here.`
                  : 'Build weekly teaching slots with substitution coverage, then prepare exam timetables with invigilators, duration, and seating range.'}
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Uploaded Plans" value={totalClassSlots} icon={FileText} />
              <MetricCard label="Classes Listed" value={teacherCoverage} icon={UserRound} />
              <MetricCard label="Rooms Used" value={roomCoverage} icon={DoorOpen} />
              <MetricCard label="Exam Slots" value={examCount} icon={ShieldCheck} />
            </div>
          </div>
        </section>

        {activePage === 'home' ? (
          <section className="mt-8 grid gap-5 md:grid-cols-2">
            <ActionCard
              icon={CalendarClock}
              title="Class & Teacher Timetable"
              text={teacherSession
                ? 'Open the timetable files for the classes you teach.'
                : 'Open class-wise timetable files, upload new schedules, and manage existing uploads.'}
              onClick={() => setActivePage('class')}
            />
            <ActionCard
              icon={ShieldCheck}
              title="Exam Timetable"
              text={teacherSession
                ? 'Review exam timetable entries connected to your teaching classes or invigilation duty.'
                : 'Create assessment schedules with invigilator, duration, and seating range.'}
              onClick={() => setActivePage('exam')}
            />
          </section>
        ) : (
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-700">Timetable Page</p>
              <h2 className="mt-2 font-serif text-3xl font-black italic tracking-tight text-slate-950">
                {activePage === 'class' ? 'Class And Teacher Timetable' : activePage === 'template-editor' ? 'Edit Timetable Template' : 'Exam Timetable'}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setActivePage(activePage === 'template-editor' ? 'class' : 'home')}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.18em] text-slate-600 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={15} />
              {activePage === 'template-editor' ? 'Back To Timetable' : 'Back To Cards'}
            </button>
          </div>
        )}

        {activePage === 'class' ? (
          <TwoColumnPage
            left={
              <Panel
                title={teacherSession ? 'Teaching Classes' : 'School Classes'}
                description={teacherSession
                  ? 'Select one of your teaching classes to view its timetable.'
                  : 'Select any class to open its timetable upload page.'}
              >
                <div className="mt-6">
                  <SearchInput value={classSearch} onChange={setClassSearch} placeholder="Search class..." />
                </div>
                <div className="mt-6 grid gap-3">
                  {filteredClassOptions.map((className) => {
                    const record = classTimetables.find((entry) => entry.className === className);
                    return (
                      <button
                        key={className}
                        type="button"
                        onClick={() => {
                          setSelectedClass(className);
                          setClassTimetableAction('');
                          setGeneratedTemplateDraft(null);
                        }}
                        className={`flex items-center justify-between gap-4 rounded-[1.4rem] border p-4 text-left transition hover:border-emerald-300 hover:bg-emerald-50/60 ${
                          selectedClass === className ? 'border-emerald-400 bg-emerald-50 ring-4 ring-emerald-100' : 'border-slate-200 bg-slate-50'
                        }`}
                      >
                        <div className="min-w-0">
                          <h4 className="truncate text-base font-black text-slate-950">{className}</h4>
                          <p className="mt-1 text-[11px] font-black uppercase tracking-[0.16em] text-slate-500">
                            {record ? 'Timetable Uploaded' : 'No Timetable Uploaded'}
                          </p>
                        </div>
                        <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${record ? 'bg-emerald-100 text-emerald-700' : 'bg-white text-slate-300'}`}>
                          {record ? <FileText size={18} /> : <Upload size={18} />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </Panel>
            }
            right={
              <Panel
                title={selectedClass || 'Select A Class'}
                description={
                  teacherSession
                    ? 'View the uploaded timetable file for the selected teaching class.'
                    : 'Upload, replace, or delete the timetable file for the selected class.'
                }
              >
                {!selectedClass ? (
                  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
                    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                      <CalendarClock size={34} />
                    </div>
                    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">Choose a class</h4>
                    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">Click a class from the school class list to upload or manage its timetable.</p>
                  </div>
                ) : teacherSession ? (
                  selectedClassRecord ? (
                    <div className="mt-8 rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                        <button
                          type="button"
                          onClick={() => setPreviewRecord(selectedClassRecord)}
                          className="flex min-w-0 flex-1 items-center gap-4 rounded-[1.4rem] p-2 text-left transition hover:bg-white"
                        >
                          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700">
                            <FileText size={24} />
                          </div>
                          <div className="min-w-0">
                            <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{selectedClassRecord.fileName || 'Uploaded timetable'}</h4>
                            <p className="mt-1 text-[11px] font-black uppercase tracking-[0.16em] text-emerald-700">
                              Uploaded {formatUploadDate(selectedClassRecord.uploadedAt || selectedClassRecord.createdAt)}
                            </p>
                            <p className="mt-2 text-xs font-bold text-slate-500">Click to open uploaded timetable</p>
                          </div>
                        </button>
                        <div className="flex flex-wrap items-center gap-2">
                          <InfoPill icon={Clock3} text={formatUploadTime(selectedClassRecord.uploadedAt || selectedClassRecord.createdAt)} />
                          <InfoPill icon={FileText} text="Upload complete" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
                      <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                        <CalendarClock size={34} />
                      </div>
                      <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No timetable uploaded</h4>
                      <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">Your class timetable has not been uploaded by the admin yet.</p>
                    </div>
                  )
                ) : (
                  <div className="mt-8 space-y-6">
                    <div className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      {selectedClassRecord ? (
                        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                          <button
                            type="button"
                            onClick={() => setPreviewRecord(selectedClassRecord)}
                            className="flex min-w-0 flex-1 items-center gap-4 rounded-[1.4rem] p-2 text-left transition hover:bg-white"
                          >
                            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700">
                              <FileText size={24} />
                            </div>
                            <div className="min-w-0">
                              <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{selectedClassRecord.fileName || 'Uploaded timetable'}</h4>
                              <p className="mt-1 text-[11px] font-black uppercase tracking-[0.16em] text-emerald-700">
                                Uploaded {formatUploadDate(selectedClassRecord.uploadedAt || selectedClassRecord.createdAt)}
                              </p>
                              <p className="mt-2 text-xs font-bold text-slate-500">Click to open uploaded timetable</p>
                            </div>
                          </button>
                          <div className="flex flex-wrap items-center gap-2">
                            <InfoPill icon={Clock3} text={formatUploadTime(selectedClassRecord.uploadedAt || selectedClassRecord.createdAt)} />
                            <InfoPill icon={FileText} text="Upload complete" />
                            <button
                              type="button"
                              onClick={() => handleDelete('timetable_class_slots', selectedClassRecord.id, 'Delete this uploaded timetable?')}
                              className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="py-8 text-center">
                          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                            <Upload size={28} />
                          </div>
                          <h4 className="mt-5 font-serif text-2xl font-black italic tracking-tight text-slate-950">No timetable uploaded</h4>
                          <p className="mx-auto mt-2 max-w-md text-sm leading-7 text-slate-500">Add the timetable file for this class to make it available here.</p>
                        </div>
                      )}
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <button
                        type="button"
                        onClick={() => setClassTimetableAction('upload')}
                        className={`rounded-[1.8rem] border p-6 text-left transition ${
                          classTimetableAction === 'upload'
                            ? 'border-emerald-400 bg-emerald-50 ring-4 ring-emerald-100'
                            : 'border-slate-200 bg-white hover:border-emerald-300'
                        }`}
                      >
                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
                          <Upload size={22} />
                        </div>
                        <h4 className="mt-4 font-serif text-2xl font-black italic tracking-tight text-slate-950">Upload File Of Timetable</h4>
                        <p className="mt-2 text-sm leading-7 text-slate-500">
                          Upload PDF, image, spreadsheet, or document file for this selected class timetable.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setClassTimetableAction('generate')}
                        className={`rounded-[1.8rem] border p-6 text-left transition ${
                          classTimetableAction === 'generate'
                            ? 'border-emerald-400 bg-emerald-50 ring-4 ring-emerald-100'
                            : 'border-slate-200 bg-white hover:border-emerald-300'
                        }`}
                      >
                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
                          <FileText size={22} />
                        </div>
                        <h4 className="mt-4 font-serif text-2xl font-black italic tracking-tight text-slate-950">Generate Excel Timetable</h4>
                        <p className="mt-2 text-sm leading-7 text-slate-500">
                          Create a class timetable template from lecture count, start time, lecture length, and lunch break.
                        </p>
                      </button>
                    </div>

                    {classTimetableAction === 'upload' ? (
                      <label className="flex cursor-pointer flex-col items-center justify-center rounded-[1.8rem] border-2 border-dashed border-emerald-200 bg-emerald-50/60 px-6 py-10 text-center transition hover:border-emerald-400 hover:bg-emerald-50">
                        <Upload className="text-emerald-700" size={30} />
                        <span className="mt-4 text-sm font-black uppercase tracking-[0.18em] text-emerald-800">
                          {selectedClassRecord ? 'Add New / Replace Timetable' : 'Add New Timetable'}
                        </span>
                        <span className="mt-2 text-sm text-slate-500">Upload PDF, image, spreadsheet, or document file</span>
                        <input
                          type="file"
                          className="hidden"
                          accept=".pdf,.png,.jpg,.jpeg,.xlsx,.xls,.doc,.docx,.csv,image/*,application/pdf"
                          onChange={handleClassTimetableUpload}
                        />
                      </label>
                    ) : null}

                    {classTimetableAction === 'generate' ? (
                      <div className="rounded-[1.8rem] border border-slate-200 bg-white p-5 shadow-sm">
                        <div>
                          <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">Excel Template Generator</p>
                          <h4 className="mt-2 font-serif text-2xl font-black italic tracking-tight text-slate-950">Generate class timetable template</h4>
                          <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-500">
                            First row me school name hoga. Second row me har lecture number aur uska timing hoga. Rows Monday se Saturday rahengi, aur har lecture slot ke andar Subject aur Teacher ke liye jagah rahegi. First 4 lectures ke baad lunch automatically add hoga.
                          </p>
                        </div>

                        <div className="mt-6 grid gap-4 md:grid-cols-2">
                          <InputField
                            label="School Name"
                            value={templateForm.schoolName}
                            onChange={(e) => setTemplateForm({ ...templateForm, schoolName: e.target.value })}
                            placeholder="Enter school name"
                          />
                          <InputField
                            label="Total Lectures"
                            type="number"
                            min="1"
                            max="12"
                            value={templateForm.lectureCount}
                            onChange={(e) => setTemplateForm({ ...templateForm, lectureCount: e.target.value })}
                            placeholder="8"
                          />
                          <InputField
                            label="First Lecture Start"
                            type="time"
                            value={templateForm.firstLectureStart}
                            onChange={(e) => setTemplateForm({ ...templateForm, firstLectureStart: e.target.value })}
                          />
                          <InputField
                            label="Lecture Length (Minutes)"
                            type="number"
                            min="1"
                            value={templateForm.lectureLength}
                            onChange={(e) => setTemplateForm({ ...templateForm, lectureLength: e.target.value })}
                            placeholder="45"
                          />
                          <div className="md:col-span-2">
                            <InputField
                              label="Lunch Length After 4th Lecture (Minutes)"
                              type="number"
                              min="0"
                              value={templateForm.lunchLength}
                              onChange={(e) => setTemplateForm({ ...templateForm, lunchLength: e.target.value })}
                              placeholder="30"
                            />
                          </div>
                        </div>

                        <div className="mt-6 flex flex-col gap-3 lg:flex-row lg:items-center">
                          <button
                            type="button"
                            onClick={handleGenerateTemplate}
                            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-600"
                          >
                            <FileText size={15} />
                            Generate Excel Template
                          </button>
                          <p className="text-sm font-semibold text-slate-500">
                            Generate karne ke baad template website ke andar edit hoga. Final timetable ready hone par hi save karein.
                          </p>
                        </div>
                        {selectedTemplateDraftRecord ? (
                          <div className="mt-6 flex flex-col gap-3 rounded-[1.6rem] border border-emerald-200 bg-emerald-50 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
                            <div>
                              <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">Saved Draft Available</p>
                              <p className="mt-1 text-sm font-semibold text-slate-600">
                                Aapne is class ke liye draft save kiya hua hai. Usse dubara open karke continue kar sakte hain.
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={handleOpenSavedDraft}
                              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700 transition hover:bg-emerald-100"
                            >
                              <FileText size={15} />
                              Open Saved Draft
                            </button>
                          </div>
                        ) : null}
                      </div>
                    ) : null}
                  </div>
                )}
              </Panel>
            }
          />
        ) : null}

        {activePage === 'template-editor' ? (
          <section className="mt-8">
            <Panel
              title={generatedTemplateDraft ? `${generatedTemplateDraft.className} Template Editor` : 'Template Editor'}
              description="Edit subject and teacher name for every lecture cell. Final save will move the completed template into the timetable records, while save draft keeps your work separate until it is ready."
            >
              {generatedTemplateDraft ? (
                <>
                  <div className="mt-6 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">Separate Editor Page</p>
                      <h4 className="mt-2 font-serif text-3xl font-black italic tracking-tight text-slate-950">
                        {generatedTemplateDraft.schoolName}
                      </h4>
                      <p className="mt-2 text-sm font-semibold text-slate-500">
                        {generatedTemplateDraft.className} | Lecture count {generatedTemplateDraft.lectureCount} | Lunch after lecture 4
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      <button
                        type="button"
                        onClick={handleSaveGeneratedTemplate}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-700"
                      >
                        <FileText size={15} />
                        Final Save
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveTemplateDraft}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-slate-800"
                      >
                        <Download size={15} />
                        Save Draft
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelTemplateEditor}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-slate-600 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
                      >
                        <X size={15} />
                        Cancel
                      </button>
                    </div>
                  </div>

                  <div className="mt-6 overflow-x-auto rounded-[1.4rem] border border-slate-200 bg-white">
                    <table className="min-w-full border-collapse">
                      <thead>
                        <tr>
                          <th
                            colSpan={1 + buildTimetableDisplayColumns(generatedTemplateDraft.lecturePlan).length}
                            className="border border-slate-300 bg-emerald-700 px-3 py-3 text-center text-base font-black text-white"
                          >
                            {generatedTemplateDraft.schoolName}
                          </th>
                        </tr>
                        <tr>
                          <th className="border border-slate-300 bg-slate-950 px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-white">
                            Day
                          </th>
                          {buildTimetableDisplayColumns(generatedTemplateDraft.lecturePlan).map((column) => (
                            <th
                              key={`editor-column-${column.key}`}
                              className={`border border-slate-300 px-3 py-2 text-center text-xs font-black ${
                                column.type === 'lunch' ? 'bg-amber-100 text-amber-950' : 'bg-emerald-50 text-slate-950'
                              }`}
                            >
                              {column.type === 'lunch' ? (
                                <div>
                                  <div>Lunch</div>
                                  <div className="mt-1 text-[11px] font-semibold text-amber-800">{column.timeLabel}</div>
                                </div>
                              ) : (
                                <div>
                                  <div>Lecture {column.lecture.lectureNumber}</div>
                                  <div className="mt-1 text-[11px] font-semibold text-slate-600">
                                    {column.lecture.timeFrom} - {column.lecture.timeTo}
                                  </div>
                                </div>
                              )}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {generatedTemplateDraft.rows.map((row, dayIndex) => (
                          <tr key={`editor-${row.day}`}>
                            <td className="border border-slate-300 bg-slate-50 px-3 py-3 align-top text-xs font-black text-slate-950">
                              {row.day}
                            </td>
                            {buildTimetableDisplayColumns(generatedTemplateDraft.lecturePlan).map((column) => {
                              if (column.type === 'lunch') {
                                if (dayIndex !== 0) return null;
                                return (
                                  <td
                                    key={`${row.day}-lunch`}
                                    rowSpan={generatedTemplateDraft.rows.length}
                                    className="border border-slate-300 bg-amber-50 px-3 py-2 align-middle text-center"
                                  >
                                    <div className="flex min-h-full min-w-[72px] items-center justify-center rounded-xl border border-amber-200 bg-amber-100/70 px-2 py-6">
                                      <div
                                        className="text-sm font-black uppercase tracking-[0.18em] text-amber-900"
                                        style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
                                      >
                                        Lunch
                                      </div>
                                    </div>
                                  </td>
                                );
                              }

                              const slot = row.slots[column.lectureIndex] || { subjectName: '', teacherName: '' };
                              return (
                                <td key={`${row.day}-editor-${column.lectureIndex}`} className="border border-slate-300 px-2 py-2 align-top">
                                  <div className="min-w-[150px] space-y-2">
                                    <CompactTemplateField
                                      prefix="S"
                                      value={slot.subjectName}
                                      onChange={(e) => handleDraftCellChange(dayIndex, column.lectureIndex, 'subjectName', e.target.value)}
                                      placeholder="Subject"
                                    />
                                    <CompactTemplateSelect
                                      prefix="T"
                                      value={slot.teacherName}
                                      onChange={(e) => handleDraftCellChange(dayIndex, column.lectureIndex, 'teacherName', e.target.value)}
                                      options={selectedClassTeacherOptions}
                                    />
                                  </div>
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
                  <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                    <FileText size={34} />
                  </div>
                  <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No draft open</h4>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">
                    Pehle class page se template generate karein ya saved draft open karein.
                  </p>
                </div>
              )}
            </Panel>
          </section>
        ) : null}

        {activePage === 'exam' ? (
          <TwoColumnPage
            left={
              teacherSession ? (
                <Panel
                  title="Teacher Exam View"
                  description="Only exam timetable records connected to your classes or invigilation duty are listed on the right."
                >
                  <div className="mt-8 rounded-[1.8rem] border border-emerald-200 bg-emerald-50 p-6">
                    <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">Teacher Access</p>
                    <h4 className="mt-3 font-serif text-2xl font-black italic tracking-tight text-slate-950">Exam timetable is read-only here.</h4>
                    <p className="mt-3 text-sm leading-7 text-slate-600">
                      You can review only the exam schedule for your teaching classes and any invigilation duties assigned to you.
                    </p>
                  </div>
                </Panel>
              ) : (
                <Panel title="Create Exam Slot" description="Plan assessment periods with invigilator, duration, seating range, room, and time.">
                  <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={handleSaveExamSlot}>
                    <InputField label="Exam Title" value={examSlotForm.examTitle} onChange={(e) => setExamSlotForm({ ...examSlotForm, examTitle: e.target.value })} placeholder="Mid Term Examination" />
                    <SelectField label="Class" value={examSlotForm.className} onChange={(e) => setExamSlotForm({ ...examSlotForm, className: e.target.value })} options={['', ...classOptions]} />
                    <InputField label="Subject" value={examSlotForm.subjectName} onChange={(e) => setExamSlotForm({ ...examSlotForm, subjectName: e.target.value })} placeholder="Science" />
                    <InputField label="Exam Date" type="date" value={examSlotForm.examDate} onChange={(e) => setExamSlotForm({ ...examSlotForm, examDate: e.target.value })} />
                    <SelectField label="Day Of Week" value={examSlotForm.dayOfWeek} onChange={(e) => setExamSlotForm({ ...examSlotForm, dayOfWeek: e.target.value })} options={weekDays} />
                    <InputField label="Room ID" value={examSlotForm.roomId} onChange={(e) => setExamSlotForm({ ...examSlotForm, roomId: e.target.value })} placeholder="Exam Hall A" />
                    <InputField label="Time From" type="time" value={examSlotForm.timeFrom} onChange={(e) => setExamSlotForm({ ...examSlotForm, timeFrom: e.target.value })} />
                    <InputField label="Time To" type="time" value={examSlotForm.timeTo} onChange={(e) => setExamSlotForm({ ...examSlotForm, timeTo: e.target.value })} />
                    <InputField label="Invigilator Name" value={examSlotForm.invigilatorName} onChange={(e) => setExamSlotForm({ ...examSlotForm, invigilatorName: e.target.value })} placeholder="Neha Agarwal" />
                    <InputField label="Exam Duration" value={examSlotForm.examDuration} onChange={(e) => setExamSlotForm({ ...examSlotForm, examDuration: e.target.value })} placeholder="3 Hours" />
                    <div className="md:col-span-2">
                      <InputField label="Student Seating Range" value={examSlotForm.studentSeatingRange} onChange={(e) => setExamSlotForm({ ...examSlotForm, studentSeatingRange: e.target.value })} placeholder="Roll 001-045" />
                    </div>
                    <div className="md:col-span-2">
                      <PrimaryButton type="submit" icon={ShieldCheck} label="Save Exam Timetable Slot" />
                    </div>
                  </form>
                </Panel>
              )
            }
            right={
              <Panel
                title="Exam Timetable"
                description={teacherSession
                  ? 'Search your class-wise exam timetable and invigilation entries.'
                  : 'Search by exam, class, subject, invigilator, room, or seating range.'}
              >
                <div className="mt-6">
                  <SearchInput value={examSearch} onChange={setExamSearch} placeholder="Search exam timetable..." />
                </div>
                <div className="mt-6 grid gap-4">
                  {filteredExamSlots.map((slot) => (
                    <RecordCard key={slot.id} icon={ShieldCheck} title={`${slot.examTitle} | ${slot.examDate}`} subtitle={`${slot.className} | ${slot.subjectName} | ${slot.timeFrom} - ${slot.timeTo}`}>
                      <InfoPill icon={UserRound} text={slot.invigilatorName} />
                      <InfoPill icon={Clock3} text={slot.examDuration || `${slot.timeFrom}-${slot.timeTo}`} />
                      <InfoPill icon={GraduationCap} text={slot.studentSeatingRange || 'Seating pending'} />
                      <InfoPill icon={DoorOpen} text={slot.roomId} />
                      {!teacherSession ? (
                        <button onClick={() => handleDelete('timetable_exam_slots', slot.id, 'Delete this exam timetable slot?')} className="ml-auto text-slate-400 transition hover:text-rose-600">
                          <Trash2 size={18} />
                        </button>
                      ) : null}
                    </RecordCard>
                  ))}
                </div>
              </Panel>
            }
          />
        ) : null}
      </main>

      {previewRecord ? (
        <FilePreviewModal record={previewRecord} onClose={() => setPreviewRecord(null)} />
      ) : null}
    </div>
  );
};

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const dayOrder = weekDays.reduce((map, day, index) => ({ ...map, [day]: index }), {});
const classTemplateDays = weekDays.slice(0, 6);

const buildTimetableTemplateFileName = (className) => {
  const slug = String(className || 'class-timetable')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return `${slug || 'class-timetable'}-template.xls`;
};

const buildLecturePlan = (startTime, lectureCount, lectureLength, lunchLength) => {
  let currentMinutes = parseTimeToMinutes(startTime || '08:00');

  return Array.from({ length: lectureCount }, (_, index) => {
    const lectureNumber = index + 1;
    const timeFrom = formatMinutesToTime(currentMinutes);
    const timeTo = formatMinutesToTime(currentMinutes + lectureLength);
    currentMinutes += lectureLength;

    if (lectureNumber === 4 && lunchLength > 0 && lectureNumber < lectureCount) {
      currentMinutes += lunchLength;
    }

    return {
      lectureNumber,
      timeFrom,
      timeTo,
    };
  });
};

const buildTimetableDisplayColumns = (lecturePlan = []) => {
  const columns = [];

  lecturePlan.forEach((lecture, index) => {
    columns.push({
      key: `lecture-${lecture.lectureNumber}`,
      type: 'lecture',
      lecture,
      lectureIndex: index,
    });

    if (lecture.lectureNumber === 4 && index < lecturePlan.length - 1) {
      columns.push({
        key: 'lunch-after-4',
        type: 'lunch',
        timeLabel: `${lecture.timeTo} onwards`,
      });
    }
  });

  return columns;
};

const parseTimeToMinutes = (value) => {
  const [hour = '8', minute = '0'] = String(value || '08:00').split(':');
  return (Number(hour) * 60) + Number(minute);
};

const formatMinutesToTime = (totalMinutes) => {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
};

const buildTimetableTemplateDataUri = ({ schoolName, className, lecturePlan, rows = [] }) => {
  const displayColumns = buildTimetableDisplayColumns(lecturePlan);
  const lectureHeaderCells = displayColumns.map((column) => {
    if (column.type === 'lunch') {
      return `
      <th style="border:1px solid #0f172a;background:#fde68a;padding:8px 6px;font-size:11px;font-weight:700;text-align:center;">
        Lunch<br />
        <span style="font-size:10px;font-weight:600;">${column.timeLabel}</span>
      </th>`;
    }

    return `
      <th style="border:1px solid #0f172a;background:#d1fae5;padding:8px 6px;font-size:11px;font-weight:700;text-align:center;">
        Lecture ${column.lecture.lectureNumber}<br />
        <span style="font-size:10px;font-weight:600;">${column.lecture.timeFrom} - ${column.lecture.timeTo}</span>
      </th>`;
  }).join('');

  const tableRows = classTemplateDays.map((day, dayIndex) => `
      <tr>
        <td style="border:1px solid #0f172a;background:#f8fafc;padding:8px 6px;font-size:11px;font-weight:700;">${day}</td>
        ${displayColumns.map((column) => {
          if (column.type === 'lunch') {
            if (dayIndex !== 0) return '';
            return `
          <td rowspan="${classTemplateDays.length}" style="border:1px solid #0f172a;background:#fef3c7;padding:7px 6px;vertical-align:middle;min-width:72px;text-align:center;font-size:11px;font-weight:700;color:#78350f;">
            <div style="display:flex;align-items:center;justify-content:center;min-height:100%;padding:8px 0;">
              <span style="writing-mode:vertical-rl;transform:rotate(180deg);letter-spacing:0.18em;text-transform:uppercase;">Lunch</span>
            </div>
          </td>`;
          }

          const slot = rows[dayIndex]?.slots?.[column.lectureIndex] || { subjectName: '', teacherName: '' };
          return `
          <td style="border:1px solid #0f172a;padding:7px 6px;vertical-align:top;min-width:130px;height:52px;">
            <div style="margin:0 0 6px 0;font-size:11px;color:#0f172a;"><strong>S:</strong> ${escapeTemplateHtml(slot.subjectName)}</div>
            <div style="font-size:11px;color:#0f172a;"><strong>T:</strong> ${escapeTemplateHtml(slot.teacherName)}</div>
          </td>`;
        }).join('')}
      </tr>`).join('');

  const lunchNotice = lecturePlan.length > 4
    ? `<p style="margin:0 0 12px 0;font-size:11px;color:#475569;font-weight:700;">Lunch break automatically considered after Lecture 4.</p>`
    : '';

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head>
        <meta charset="UTF-8" />
        <meta name="ProgId" content="Excel.Sheet" />
      </head>
      <body>
        ${lunchNotice}
        <table border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-family:Arial,sans-serif;min-width:${110 + (displayColumns.length * 136)}px;">
          <tr>
            <th colspan="${1 + displayColumns.length}" style="border:1px solid #0f172a;background:#0f766e;color:#ffffff;padding:10px 8px;font-size:16px;font-weight:700;text-align:center;">
              ${escapeTemplateHtml(schoolName)}
            </th>
          </tr>
          <tr>
            <th style="border:1px solid #0f172a;background:#0f172a;color:#ffffff;padding:9px 6px;font-size:11px;font-weight:700;text-align:center;">Day</th>
            ${lectureHeaderCells}
          </tr>
          ${tableRows}
        </table>
        <p style="margin-top:10px;font-size:10px;color:#64748b;">Class: ${escapeTemplateHtml(className)}</p>
      </body>
    </html>`;

  return `data:text/html;charset=utf-8,${encodeURIComponent(html)}`;
};

const escapeTemplateHtml = (value) => String(value || '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#39;');

const replaceModuleRecords = (module, records) => {
  const tenantId = db.getTenantId();
  if (!tenantId) return;
  localStorage.setItem(`${tenantId}_${module}`, JSON.stringify(records));
};

const sortByDayAndTime = (a, b) => {
  return (dayOrder[a.dayOfWeek] ?? 99) - (dayOrder[b.dayOfWeek] ?? 99) || String(a.timeFrom || '').localeCompare(String(b.timeFrom || ''));
};

const compareClassNames = (a, b) => {
  const left = getClassSortValue(a);
  const right = getClassSortValue(b);
  return left.rank - right.rank || left.section.localeCompare(right.section) || a.localeCompare(b);
};

const getClassSortValue = (className) => {
  const normalized = className.toLowerCase();
  const section = className.split('/')[1]?.trim() || '';

  if (normalized.includes('nursery')) return { rank: 0, section };
  if (normalized.includes('lkg')) return { rank: 1, section };
  if (normalized.includes('ukg')) return { rank: 2, section };

  const classMatch = normalized.match(/class\s*(\d+)/);
  if (classMatch) {
    return { rank: 2 + Number(classMatch[1]), section };
  }

  return { rank: 1000, section };
};

const formatUploadDate = (value) => {
  if (!value) return 'date pending';
  return new Date(value).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const formatUploadTime = (value) => {
  if (!value) return 'Time pending';
  return new Date(value).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

const isImageFile = (record) => {
  return record.fileType?.startsWith('image/') || /\.(png|jpe?g|gif|webp|svg)$/i.test(record.fileName || '');
};

const isPdfFile = (record) => {
  return record.fileType === 'application/pdf' || /\.pdf$/i.test(record.fileName || '');
};

const isHtmlFile = (record) => {
  return record.fileType === 'text/html' || /\.(html?)$/i.test(record.fileName || '');
};

const isPreviewableFile = (record) => {
  return Boolean(record.fileData) && (isImageFile(record) || isPdfFile(record) || isHtmlFile(record));
};

const MetricCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-50/80">{label}</p>
        <p className="mt-3 text-3xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-200/20 bg-emerald-200/10 text-emerald-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const ActionCard = ({ icon, title, text, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="group flex min-h-56 flex-col justify-between rounded-4xl border border-slate-200/80 bg-white p-6 text-left shadow-[0_20px_60px_-38px_rgba(15,23,42,0.45)] transition hover:-translate-y-1 hover:border-emerald-300 lg:p-8"
  >
    <div>
      <div className="flex items-start justify-between gap-5">
        <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700 transition group-hover:bg-emerald-600 group-hover:text-white">
          {React.createElement(icon, { size: 24 })}
        </div>
        <ArrowRight className="text-slate-300 transition group-hover:text-emerald-700" size={20} />
      </div>
      <h3 className="mt-7 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
      <p className="mt-3 text-sm leading-7 text-slate-500">{text}</p>
    </div>
    <span className="mt-6 text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">Open Page</span>
  </button>
);

const TwoColumnPage = ({ left, right }) => (
  <div className="mt-8 grid gap-8 xl:grid-cols-[0.95fr_1.05fr]">
    {left}
    {right}
  </div>
);

const Panel = ({ title, description, children }) => (
  <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
    {children}
  </section>
);

const RecordCard = ({ icon, title, subtitle, children }) => (
  <article className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
          {React.createElement(icon, { size: 20 })}
        </div>
        <div className="min-w-0">
          <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{title}</h4>
          <p className="text-[11px] font-black uppercase tracking-[0.16em] text-emerald-700">{subtitle}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  </article>
);

const FilePreviewModal = ({ record, onClose }) => {
  const canPreview = isPreviewableFile(record);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/70 px-4 py-6 backdrop-blur-sm">
      <div className="flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-4xl bg-white shadow-[0_30px_90px_-35px_rgba(15,23,42,0.75)]">
        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between lg:px-7">
          <div className="min-w-0">
            <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">{record.className}</p>
            <h3 className="mt-1 truncate font-serif text-2xl font-black italic tracking-tight text-slate-950">{record.fileName || 'Uploaded timetable'}</h3>
            <p className="mt-1 text-xs font-bold text-slate-500">
              Uploaded {formatUploadDate(record.uploadedAt || record.createdAt)} at {formatUploadTime(record.uploadedAt || record.createdAt)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {record.fileData ? (
              <a
                href={record.fileData}
                download={record.fileName || 'class-timetable'}
                className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-white transition hover:bg-emerald-600"
                title="Download"
              >
                <Download size={18} />
              </a>
            ) : null}
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              title="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-auto bg-slate-100 p-4 lg:p-6">
          {canPreview ? (
            <div className="min-h-[65vh] overflow-hidden rounded-[1.6rem] border border-slate-200 bg-white">
              {isImageFile(record) ? (
                <img src={record.fileData} alt={record.fileName || 'Uploaded timetable'} className="mx-auto max-h-[72vh] w-auto max-w-full object-contain" />
              ) : (
                <iframe title={record.fileName || 'Uploaded timetable'} src={record.fileData} className="h-[72vh] w-full bg-white" />
              )}
            </div>
          ) : (
            <div className="flex min-h-[55vh] flex-col items-center justify-center rounded-[1.6rem] border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700">
                <FileText size={34} />
              </div>
              <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">Preview not available</h4>
              <p className="mt-3 max-w-md text-sm leading-7 text-slate-500">
                This file type may not render inside the browser. Use download to open the uploaded timetable file.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const InputField = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    />
  </div>
);

const SelectField = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option || 'empty-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
        </option>
      ))}
    </select>
  </div>
);

const CompactTemplateField = ({ prefix, ...props }) => (
  <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2">
    <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-md bg-emerald-100 px-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700">
      {prefix}
    </span>
    <input
      className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none placeholder:text-slate-400"
      {...props}
    />
  </label>
);

const CompactTemplateSelect = ({ prefix, options, ...props }) => (
  <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2">
    <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-md bg-emerald-100 px-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700">
      {prefix}
    </span>
    <select
      className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none"
      {...props}
    >
      <option value="">Select teacher</option>
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  </label>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
    />
  </div>
);

const PrimaryButton = ({ type, icon, label }) => (
  <button
    type={type}
    className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-600"
  >
    {React.createElement(icon, { size: 15 })}
    {label}
  </button>
);

const InfoPill = ({ icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    {React.createElement(icon, { size: 15, className: 'text-emerald-700' })}
    <span>{text}</span>
  </div>
);

export default TimetableManagement;
