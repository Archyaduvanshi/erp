import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft,
  CalendarClock,
  Clock3,
  Download,
  FileText,
  Search,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import { classSubjectApi, settingsApi, teacherApi, timetableApi } from '../../utils/api';
import { useAuth } from '../../context/AuthContext';

const initialTemplateForm = {
  schoolName: '',
  lectureCount: '',
  firstLectureStart: '',
  lectureLength: '',
  lunchLength: '',
};

const TimetableManagement = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { session } = useAuth();
  const [activePage, setActivePage] = useState('class');
  const [selectedClass, setSelectedClass] = useState('');
  const [classSearch, setClassSearch] = useState('');
  const [openTimetablePreviewId, setOpenTimetablePreviewId] = useState(null);
  const [classTimetableAction, setClassTimetableAction] = useState('');
  const [templateForm, setTemplateForm] = useState(initialTemplateForm);
  const [generatedTemplateDraft, setGeneratedTemplateDraft] = useState(null);
  const [loadError, setLoadError] = useState('');
  const timetableSummarySessionKey = 'current';

  const timetableSummaryQuery = useQuery({
    queryKey: ['timetable-summary', timetableSummarySessionKey],
    queryFn: () => timetableApi.getSummary(),
    staleTime: 2 * 60 * 1000,
  });

  const teacherOptionsQuery = useQuery({
    queryKey: ['teacher-options'],
    queryFn: () => teacherApi.getOptions(),
    staleTime: 10 * 60 * 1000,
  });

  const settingsQuery = useQuery({
    queryKey: ['college-settings'],
    queryFn: settingsApi.get,
    staleTime: 10 * 60 * 1000,
  });

  const timetableSummaries = timetableSummaryQuery.data || [];
  const teachers = useMemo(() => (teacherOptionsQuery.data || []).map(mapTeacherOptionToLegacyTeacher), [teacherOptionsQuery.data]);

  const teacherSession = useMemo(() => {
    if (!session || session.role !== 'teacher') return null;
    return teachers.find((teacher) => String(teacher.id) === String(session.teacherId)) || null;
  }, [session, teachers]);

  const teacherName = teacherSession
    ? teacherSession.name || `${teacherSession.firstName || ''} ${teacherSession.lastName || ''}`.trim() || teacherSession.employeeId || 'Teacher'
    : '';

  const teacherOptions = useMemo(() => {
    return teachers
      .map((teacher) => {
        const displayName = formatTimetableText(`${teacher.firstName || ''} ${teacher.lastName || ''}`) || 'Unnamed Teacher';
        const teacherCode = String(teacher.employeeId || '').trim();
        const teacherLabel = teacherCode ? `${displayName} (${teacherCode})` : displayName;
        return {
          value: String(teacher.id),
          label: teacherLabel,
          teacherName: displayName,
        };
      })
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [teachers]);

  const selectedClassTeacherOptions = useMemo(() => {
    return teacherOptions;
  }, [teacherOptions]);

  const selectedClassSummary = useMemo(() => (
    findClassSummary(timetableSummaries, selectedClass)
  ), [selectedClass, timetableSummaries]);
  const selectedAcademicSessionId = selectedClassSummary?.academicSessionId || null;
  const selectedClassId = selectedClassSummary?.classId || null;
  const selectedSectionId = selectedClassSummary?.sectionId || null;
  const selectedSubjectClassId = selectedClassSummary?.subjectClassId || selectedClassId;

  const classSubjectsQuery = useQuery({
    queryKey: ['class-subjects', selectedAcademicSessionId, selectedSubjectClassId],
    queryFn: () => classSubjectApi.getByClass(selectedSubjectClassId, selectedAcademicSessionId),
    enabled: Boolean(selectedSubjectClassId && selectedAcademicSessionId),
    staleTime: 10 * 60 * 1000,
  });

  const classTimetableQuery = useQuery({
    queryKey: ['class-timetable', selectedAcademicSessionId, selectedClassId, selectedSectionId ?? null],
    queryFn: () => timetableApi.getClassTimetable(selectedClassId, {
      academicSessionId: selectedAcademicSessionId,
      sectionId: selectedSectionId,
    }).catch(() => null),
    enabled: Boolean(selectedClassId && selectedAcademicSessionId),
    staleTime: 2 * 60 * 1000,
  });

  const classDraftQuery = useQuery({
    queryKey: ['class-timetable-draft', selectedAcademicSessionId, selectedClassId, selectedSectionId ?? null],
    queryFn: () => timetableApi.getTemplateDraft(selectedClassId, {
      academicSessionId: selectedAcademicSessionId,
      sectionId: selectedSectionId,
    }).catch(() => null),
    enabled: Boolean(selectedClassId && selectedAcademicSessionId),
    staleTime: 2 * 60 * 1000,
  });

  const teacherOccupancyQuery = useQuery({
    queryKey: ['teacher-occupancy', selectedAcademicSessionId],
    queryFn: () => timetableApi.getTeacherOccupancy(selectedAcademicSessionId),
    enabled: Boolean(selectedAcademicSessionId && activePage === 'template-editor' && generatedTemplateDraft),
    staleTime: 60 * 1000,
  });

  const selectedClassSubjects = classSubjectsQuery.data || [];
  const classTimetables = classTimetableQuery.data ? [classTimetableQuery.data] : [];
  const savedTemplateDrafts = classDraftQuery.data ? [classDraftQuery.data] : [];
  const selectedTimetableQueryKey = ['class-timetable', selectedAcademicSessionId, selectedClassId, selectedSectionId ?? null];
  const selectedDraftQueryKey = ['class-timetable-draft', selectedAcademicSessionId, selectedClassId, selectedSectionId ?? null];
  const teacherOccupancyQueryKey = ['teacher-occupancy', selectedAcademicSessionId];

  useEffect(() => {
    setTemplateForm((current) => ({
      ...current,
      schoolName: current.schoolName || settingsQuery.data?.instituteName || session?.instituteName || '',
    }));
  }, [settingsQuery.data?.instituteName, session?.instituteName]);

  const publishTimetableMutation = useMutation({
    mutationFn: ({ classId, payload }) => timetableApi.publishClassTimetable(classId, payload),
  });

  const saveClassTimetableMutation = useMutation({
    mutationFn: timetableApi.saveClassTimetable,
  });

  const saveDraftMutation = useMutation({
    mutationFn: ({ classId, payload, params }) => timetableApi.saveTemplateDraftForClass(classId, payload, params),
  });

  const saveLegacyDraftMutation = useMutation({
    mutationFn: timetableApi.saveTemplateDraft,
  });

  const deleteTimetableMutation = useMutation({
    mutationFn: timetableApi.deleteClassTimetable,
  });

  const deleteDraftMutation = useMutation({
    mutationFn: timetableApi.deleteTemplateDraft,
  });

  const visibleLoadError = loadError
    || timetableSummaryQuery.error?.message
    || teacherOptionsQuery.error?.message
    || settingsQuery.error?.message
    || classSubjectsQuery.error?.message
    || classTimetableQuery.error?.message
    || classDraftQuery.error?.message
    || teacherOccupancyQuery.error?.message
    || '';

  const teacherClassOptions = useMemo(() => {
    return deriveTeacherClassesFromTimetables(classTimetables, teacherSession);
  }, [classTimetables, teacherSession]);

  const studentClassOptions = useMemo(() => {
    return [
      ...new Set(
        timetableSummaries.map((record) => record.displayName || record.className),
      ),
    ].map((value) => String(value || '').trim()).filter(Boolean).sort(compareClassNames);
  }, [timetableSummaries]);

  const classOptions = useMemo(() => {
    return teacherSession ? teacherClassOptions : studentClassOptions;
  }, [studentClassOptions, teacherClassOptions, teacherSession]);

  const filteredClassOptions = useMemo(() => {
    const query = classSearch.trim().toLowerCase();
    return classOptions.filter((className) => {
      if (!query) return true;
      return className.toLowerCase().includes(query);
    });
  }, [classOptions, classSearch]);

  const selectedClassSubjectOptions = useMemo(() => {
    const baseClassName = normalizeTimetableClassLabel(selectedClass);
    if (!baseClassName) return [];

    return selectedClassSubjects
      .map((record) => {
        const subjectName = formatTimetableText(record.subjectName || record.name || record.subject?.name);
        const classSubjectId = record.classSubjectId || record.id;
        return subjectName && classSubjectId ? {
          value: String(classSubjectId),
          label: subjectName,
          subjectName,
        } : null;
      })
      .filter(Boolean)
      .sort((left, right) => left.label.localeCompare(right.label));
  }, [selectedClass, selectedClassSubjects]);

  const updateSelectedSummary = (patch) => {
    queryClient.setQueryData(['timetable-summary', timetableSummarySessionKey], (current = []) => current.map((record) => (
      String(record.classId) === String(selectedClassSummary?.classId)
        && String(record.sectionId || '') === String(selectedClassSummary?.sectionId || '')
        ? { ...record, ...patch }
        : record
    )));
  };

  const selectedClassRecord = useMemo(() => {
    return classTimetables.find((record) => record.className === selectedClass);
  }, [classTimetables, selectedClass]);

  const selectedTemplateDraftRecord = useMemo(() => {
    return savedTemplateDrafts.find((record) => record.className === selectedClass) || null;
  }, [savedTemplateDrafts, selectedClass]);

  const visibleClassTimetables = useMemo(() => {
    if (!teacherSession) return classTimetables;
    return classTimetables.filter((record) => {
      if (!teacherClassOptions.includes(record.className)) return false;
      return Boolean(readTeacherTimetableTemplate(record));
    });
  }, [classTimetables, teacherClassOptions, teacherSession]);

  const selectedTeacherClassRecord = useMemo(() => {
    if (!teacherSession) return null;
    return visibleClassTimetables.find((record) => record.className === selectedClass) || null;
  }, [selectedClass, teacherSession, visibleClassTimetables]);

  const selectedClassEditableTemplate = useMemo(() => {
    return readTeacherTimetableTemplate(selectedClassRecord);
  }, [selectedClassRecord]);

  const isSelectedClassEditableTimetable = Boolean(selectedClassEditableTemplate);

  const handleDelete = async (module, id) => {
    try {
      if (module === 'timetable_class_slots') {
        await deleteTimetableMutation.mutateAsync(id);
        queryClient.setQueryData(selectedTimetableQueryKey, null);
        updateSelectedSummary({
          timetableId: null,
          hasTimetable: false,
          updatedAt: new Date().toISOString(),
        });
        await queryClient.invalidateQueries({ queryKey: teacherOccupancyQueryKey });
      } else if (module === 'timetable_template_drafts') {
        await deleteDraftMutation.mutateAsync(id);
        queryClient.setQueryData(selectedDraftQueryKey, null);
        updateSelectedSummary({
          draftId: null,
          hasDraft: false,
          updatedAt: new Date().toISOString(),
        });
      }
      setLoadError('');
    } catch (error) {
      setLoadError(error.message || 'Unable to delete the timetable record.');
    }
  };

  const handleGenerateTemplate = () => {
    if (!selectedClass) return;
    if (selectedClassRecord) {
      setLoadError('Is class ka timetable already saved hai. Naya timetable banane se pehle purana delete karein.');
      return;
    }

    if (!templateForm.schoolName.trim() || !templateForm.lectureCount || !templateForm.firstLectureStart || !templateForm.lectureLength || templateForm.lunchLength === '') {
      setLoadError('Please fill school name, total lectures, first lecture start, lecture length, and lunch length.');
      return;
    }
    const lectureCount = Number(templateForm.lectureCount);
    const lectureLength = Number(templateForm.lectureLength);
    const lunchLength = Number(templateForm.lunchLength);
    if (lectureCount < 1 || lectureLength < 1 || lunchLength < 0) {
      setLoadError('Please enter valid numbers for lectures, lecture length, and lunch length.');
      return;
    }

    const schoolName = templateForm.schoolName.trim();
    const lecturePlan = buildLecturePlan(templateForm.firstLectureStart, lectureCount, lectureLength, lunchLength);
    setGeneratedTemplateDraft({
      className: selectedClass,
      schoolName,
      lecturePlan,
      lectureCount,
      firstLectureStart: templateForm.firstLectureStart,
      lectureLength,
      lunchLength,
      attendanceTeacherId: '',
      attendanceTeacher: '',
      rows: classTemplateDays.map((day) => ({
        day,
        slots: lecturePlan.map(() => ({ classSubjectId: '', subjectName: '', teacherId: '', teacherName: '' })),
      })),
    });
    setActivePage('template-editor');
  };

  const handleEditSavedTimetable = () => {
    if (!selectedClass || !selectedClassEditableTemplate) return;

    setGeneratedTemplateDraft({
      ...selectedClassEditableTemplate,
      className: selectedClass,
      schoolName: selectedClassEditableTemplate.schoolName || '',
      lectureCount: selectedClassEditableTemplate.lectureCount || String(selectedClassEditableTemplate.lecturePlan?.length || ''),
      firstLectureStart: selectedClassEditableTemplate.firstLectureStart || selectedClassEditableTemplate.lecturePlan?.[0]?.timeFrom || '',
      lectureLength: selectedClassEditableTemplate.lectureLength || calculateLectureLength(selectedClassEditableTemplate.lecturePlan),
      lunchLength: selectedClassEditableTemplate.lunchLength ?? '',
      attendanceTeacherId: selectedClassEditableTemplate.attendanceTeacherId || '',
      attendanceTeacher: resolveTimetableAttendanceTeacher(selectedClassRecord),
    });
    setClassTimetableAction('');
    setActivePage('template-editor');
    setLoadError('');
  };

  const handleDraftCellChange = (dayIndex, slotIndex, field, value) => {
    setGeneratedTemplateDraft((current) => {
      if (!current) return current;

      return {
        ...current,
        rows: current.rows.map((row, currentDayIndex) => (
          currentDayIndex !== dayIndex
            ? row
            : {
                ...row,
                slots: row.slots.map((slot, currentSlotIndex) => (
                  currentSlotIndex !== slotIndex ? slot : { ...slot, [field]: value }
                )),
              }
        )),
      };
    });
  };

  const handleDraftSubjectChange = (dayIndex, slotIndex, value) => {
    const option = selectedClassSubjectOptions.find((entry) => String(entry.value) === String(value));
    setGeneratedTemplateDraft((current) => updateDraftSlot(current, dayIndex, slotIndex, {
      classSubjectId: option?.value || '',
      subjectName: option?.subjectName || '',
    }));
  };

  const handleDraftTeacherChange = (dayIndex, slotIndex, value) => {
    const option = selectedClassTeacherOptions.find((entry) => String(entry.value) === String(value));
    setGeneratedTemplateDraft((current) => updateDraftSlot(current, dayIndex, slotIndex, {
      teacherId: option?.value || '',
      teacherName: option?.label || '',
    }));
  };

  const handleSaveGeneratedTemplate = async () => {
      if (!generatedTemplateDraft || !selectedClass) return;

      const normalizedTemplateDraft = normalizeGeneratedTemplateDraft(generatedTemplateDraft);
      if (!normalizedTemplateDraft.attendanceTeacher) {
        setLoadError('Please select the attendance teacher for this class.');
        return;
      }
      const missingSubjects = findUnusedTimetableSubjects(normalizedTemplateDraft, selectedClassSubjectOptions);
      if (missingSubjects.length) {
        setLoadError(`Please schedule these subjects before final save: ${missingSubjects.join(', ')}.`);
        return;
      }
      const now = new Date().toISOString();
      const payload = {
        className: selectedClass,
        academicSessionId: selectedClassSummary?.academicSessionId || null,
        classId: selectedClassSummary?.classId || null,
        sectionId: selectedClassSummary?.sectionId || null,
        attendanceTeacherId: normalizedTemplateDraft.attendanceTeacherId || null,
        fileName: buildTimetableTemplateFileName(selectedClass),
        fileData: '',
        fileType: 'text/html',
        uploadedAt: now,
        templateData: normalizedTemplateDraft,
        templateMeta: {
          schoolName: normalizedTemplateDraft.schoolName,
          lectureCount: normalizedTemplateDraft.lectureCount,
          firstLectureStart: normalizedTemplateDraft.firstLectureStart,
          lectureLength: normalizedTemplateDraft.lectureLength,
          lunchLength: normalizedTemplateDraft.lunchLength,
          attendanceTeacherId: normalizedTemplateDraft.attendanceTeacherId,
          attendanceTeacher: normalizedTemplateDraft.attendanceTeacher,
        },
    };
    try {
      if (selectedClassSummary?.classId) {
        const savedTimetable = await publishTimetableMutation.mutateAsync({ classId: selectedClassSummary.classId, payload });
        queryClient.setQueryData(selectedTimetableQueryKey, savedTimetable || null);
        queryClient.setQueryData(selectedDraftQueryKey, null);
        updateSelectedSummary({
          timetableId: savedTimetable?.id || selectedClassSummary.timetableId,
          hasTimetable: Boolean(savedTimetable),
          draftId: null,
          hasDraft: false,
          updatedAt: savedTimetable?.updatedAt || new Date().toISOString(),
        });
        await queryClient.invalidateQueries({ queryKey: teacherOccupancyQueryKey });
      } else {
        const savedTimetable = await saveClassTimetableMutation.mutateAsync(payload);
        queryClient.setQueryData(selectedTimetableQueryKey, savedTimetable || null);
        if (selectedTemplateDraftRecord?.id) {
          await deleteDraftMutation.mutateAsync(selectedTemplateDraftRecord.id);
          queryClient.setQueryData(selectedDraftQueryKey, null);
        }
      }
      setGeneratedTemplateDraft(null);
      setClassTimetableAction('');
      setActivePage('class');
      setLoadError('');
    } catch (error) {
      setLoadError(error.message || 'Unable to save the timetable template.');
    }
  };

  const handleSaveTemplateDraft = async () => {
    if (!generatedTemplateDraft || !selectedClass) return;
    const payload = {
        className: selectedClass,
        academicSessionId: selectedClassSummary?.academicSessionId || null,
        classId: selectedClassSummary?.classId || null,
        sectionId: selectedClassSummary?.sectionId || null,
        draftData: normalizeGeneratedTemplateDraft(generatedTemplateDraft),
    };
    try {
      if (selectedClassSummary?.classId) {
        const savedDraft = await saveDraftMutation.mutateAsync({
          classId: selectedClassSummary.classId,
          payload,
          params: {
            academicSessionId: selectedClassSummary.academicSessionId,
            sectionId: selectedClassSummary.sectionId,
          },
        });
        queryClient.setQueryData(selectedDraftQueryKey, savedDraft || null);
        updateSelectedSummary({
          draftId: savedDraft?.id || selectedClassSummary.draftId,
          hasDraft: Boolean(savedDraft),
          updatedAt: savedDraft?.updatedAt || new Date().toISOString(),
        });
      } else {
        const savedDraft = await saveLegacyDraftMutation.mutateAsync(payload);
        queryClient.setQueryData(selectedDraftQueryKey, savedDraft || null);
      }
      setLoadError('');
    } catch (error) {
      setLoadError(error.message || 'Unable to save the timetable draft.');
    }
  };

  const handleOpenSavedDraft = () => {
    if (!selectedTemplateDraftRecord?.draftData) return;
    setGeneratedTemplateDraft(selectedTemplateDraftRecord.draftData);
    setActivePage('template-editor');
  };

  const handleCancelTemplateEditor = () => {
    setGeneratedTemplateDraft(null);
    setActivePage('class');
  };

  const handleBack = () => {
    if (activePage === 'template-editor') {
      setActivePage('class');
      return;
    }

    navigate(session?.role === 'teacher' ? '/teacher' : '/college');
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f7fbff_0%,#effaf5_36%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={handleBack}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Timetable Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Time And Resource Planner</h1>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        {visibleLoadError ? (
          <div className="mb-6 rounded-3xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm font-semibold text-rose-700">
            {visibleLoadError}
          </div>
        ) : null}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-700">Timetable Page</p>
            <h2 className="mt-2 font-serif text-3xl font-black italic tracking-tight text-slate-950">
              {activePage === 'template-editor' ? 'Edit Timetable Template' : 'Class And Teacher Timetable'}
            </h2>
          </div>
        </div>

        {activePage === 'class' ? (
          <TwoColumnPage
            left={
              <Panel
                title={teacherSession ? 'Teaching Classes' : 'School Classes'}
                description={teacherSession
                  ? 'Select one of your teaching classes to view its timetable.'
                  : 'Select any class and section to generate or manage its timetable.'}
              >
                <div className="mt-6">
                  <SearchInput value={classSearch} onChange={setClassSearch} placeholder="Search class..." />
                </div>
                <div className="mt-6 grid gap-3">
                  {filteredClassOptions.map((className) => {
                    const record = findClassSummary(timetableSummaries, className);
                    const hasSavedTimetable = Boolean(record?.hasTimetable);
                    return (
                      <button
                        key={className}
                        type="button"
                        onClick={() => {
                          setSelectedClass(className);
                          setOpenTimetablePreviewId(null);
                          setClassTimetableAction('');
                          setGeneratedTemplateDraft(null);
                        }}
                        className={`flex items-center justify-between gap-4 rounded-[1.4rem] border p-4 text-left transition hover:border-emerald-300 hover:bg-emerald-50/60 ${
                          selectedClass === className ? 'border-emerald-400 bg-emerald-50 ring-4 ring-emerald-100' : 'border-slate-200 bg-slate-50'
                        }`}
                      >
                        <div className="min-w-0">
                          <h4 className="truncate text-base font-black text-slate-950">{className}</h4>
                          <p className="mt-1 text-[11px] font-black uppercase tracking-[0.16em] text-slate-500">
                            {hasSavedTimetable ? 'Timetable Saved' : 'No Timetable Saved'}
                          </p>
                        </div>
                        <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${hasSavedTimetable ? 'bg-emerald-100 text-emerald-700' : 'bg-white text-slate-300'}`}>
                          {hasSavedTimetable ? <FileText size={18} /> : <CalendarClock size={18} />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </Panel>
            }
            right={
              <Panel
                title={selectedClass || 'Select A Class'}
                description={
                  teacherSession
                    ? 'Only generated or structured timetable records are visible for your teaching class.'
                    : 'Ek class ke liye ek hi timetable save hoga. Naya timetable banane se pehle purana delete karna hoga.'
                }
              >
                {!selectedClass ? (
                  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
                    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                      <CalendarClock size={34} />
                    </div>
                    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">Choose a class</h4>
                    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">Click a class from the school class list to generate or manage its timetable.</p>
                  </div>
                ) : teacherSession ? (
                  selectedTeacherClassRecord ? (
                    <div className="mt-8 rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                        <button
                          type="button"
                          onClick={() => setOpenTimetablePreviewId(selectedTeacherClassRecord.id)}
                          className="flex min-w-0 flex-1 items-center gap-4 rounded-[1.4rem] p-2 text-left transition hover:bg-white"
                        >
                          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700">
                            <FileText size={24} />
                          </div>
                          <div className="min-w-0">
                            <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{selectedTeacherClassRecord.fileName || 'Saved timetable'}</h4>
                            <p className="mt-1 text-[11px] font-black uppercase tracking-[0.16em] text-emerald-700">
                              Saved {formatSavedDate(selectedTeacherClassRecord.uploadedAt || selectedTeacherClassRecord.createdAt)}
                            </p>
                            <p className="mt-2 text-xs font-bold text-slate-500">Click to show your timetable here</p>
                          </div>
                        </button>
                        <div className="flex flex-wrap items-center gap-2">
                          <InfoPill icon={Clock3} text={formatSavedTime(selectedTeacherClassRecord.uploadedAt || selectedTeacherClassRecord.createdAt)} />
                          <InfoPill icon={UserCheck} text={`Attendance: ${resolveTimetableAttendanceTeacher(selectedTeacherClassRecord) || 'Not assigned'}`} />
                          <InfoPill icon={FileText} text="Structured timetable" />
                        </div>
                      </div>
                      {openTimetablePreviewId === selectedTeacherClassRecord.id ? (
                        <SavedTimetablePreview record={selectedTeacherClassRecord} />
                      ) : null}
                    </div>
                  ) : (
                    <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
                      <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                        <CalendarClock size={34} />
                      </div>
                      <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No teacher timetable available</h4>
                      <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">Teacher side par tabhi timetable dikhega jab lecture, subject, aur teacher-wise structured data available ho.</p>
                    </div>
                  )
                ) : (
                  <div className="mt-8 space-y-6">
                    <div className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      {selectedClassRecord ? (
                        <>
                          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                          <button
                            type="button"
                            onClick={() => setOpenTimetablePreviewId(selectedClassRecord.id)}
                            className="flex min-w-0 flex-1 items-center gap-4 rounded-[1.4rem] p-2 text-left transition hover:bg-white"
                          >
                            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700">
                              <FileText size={24} />
                            </div>
                            <div className="min-w-0">
                              <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{selectedClassRecord.fileName || 'Saved timetable'}</h4>
                              <p className="mt-1 text-[11px] font-black uppercase tracking-[0.16em] text-emerald-700">
                                Saved {formatSavedDate(selectedClassRecord.uploadedAt || selectedClassRecord.createdAt)}
                              </p>
                              <p className="mt-2 text-xs font-bold text-slate-500">Click to show saved timetable here</p>
                            </div>
                          </button>
                        <div className="flex flex-wrap items-center gap-2">
                          <InfoPill icon={Clock3} text={formatSavedTime(selectedClassRecord.uploadedAt || selectedClassRecord.createdAt)} />
                          <InfoPill icon={UserCheck} text={`Attendance: ${resolveTimetableAttendanceTeacher(selectedClassRecord) || 'Not assigned'}`} />
                          <InfoPill icon={FileText} text="Saved timetable" />
                          {isSelectedClassEditableTimetable ? (
                            <button
                              type="button"
                              onClick={handleEditSavedTimetable}
                              className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-4 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-white transition hover:bg-emerald-700"
                            >
                              <FileText size={15} />
                              Edit
                            </button>
                          ) : null}
                          <button
                            type="button"
                            onClick={() => handleDelete('timetable_class_slots', selectedClassRecord.id)}
                            className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                          </div>
                          {openTimetablePreviewId === selectedClassRecord.id ? (
                            <SavedTimetablePreview record={selectedClassRecord} />
                          ) : null}
                        </>
                      ) : (
                        <div className="py-8 text-center">
                          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                            <CalendarClock size={28} />
                          </div>
                          <h4 className="mt-5 font-serif text-2xl font-black italic tracking-tight text-slate-950">No timetable saved</h4>
                          <p className="mx-auto mt-2 max-w-md text-sm leading-7 text-slate-500">Generate a timetable for this class to make it available here.</p>
                        </div>
                        )}
                      </div>
                    {selectedClassRecord ? (
                      <div className="rounded-[1.8rem] border border-amber-200 bg-amber-50 px-5 py-4">
                        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-amber-700">Single Timetable Rule</p>
                        <p className="mt-2 text-sm leading-7 text-slate-700">
                          Is class ke liye ek timetable already saved hai. Agar naya timetable banana hai to pehle existing timetable delete karna hoga.
                        </p>
                      </div>
                    ) : null}

                    <div className="grid gap-4">
                          <button
                            type="button"
                            onClick={() => setClassTimetableAction('generate')}
                            className={`rounded-[1.8rem] border p-6 text-left transition ${
                              classTimetableAction === 'generate'
                                ? 'border-emerald-400 bg-emerald-50 ring-4 ring-emerald-100'
                                : 'border-slate-200 bg-white hover:border-emerald-300'
                            }`}
                          >
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
                              <FileText size={22} />
                            </div>
                            <h4 className="mt-4 font-serif text-2xl font-black italic tracking-tight text-slate-950">Generate Excel Timetable</h4>
                            <p className="mt-2 text-sm leading-7 text-slate-500">
                              Create a class timetable template from lecture count, start time, lecture length, and lunch break.
                            </p>
                          </button>
                    </div>

                    {classTimetableAction === 'generate' ? (
                      <div className="rounded-[1.8rem] border border-slate-200 bg-white p-5 shadow-sm">
                        <div>
                          <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">Excel Template Generator</p>
                          <h4 className="mt-2 font-serif text-2xl font-black italic tracking-tight text-slate-950">Generate class timetable template</h4>
                          <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-500">
                            First row me school name hoga. Second row me har lecture number aur uska timing hoga. Rows Monday se Saturday rahengi, aur har lecture slot ke andar Subject aur Teacher ke liye jagah rahegi. First 4 lectures ke baad lunch automatically add hoga.
                          </p>
                        </div>

                        <div className="mt-6 grid gap-4 md:grid-cols-2">
                          <InputField
                            label="School Name"
                            value={templateForm.schoolName}
                            onChange={(e) => setTemplateForm({ ...templateForm, schoolName: e.target.value })}
                            placeholder="Write school name"
                          />
                          <InputField
                            label="Total Lectures"
                            type="number"
                            min="1"
                            max="12"
                            value={templateForm.lectureCount}
                            onChange={(e) => setTemplateForm({ ...templateForm, lectureCount: e.target.value })}
                            placeholder="Write total lectures"
                          />
                          <InputField
                            label="First Lecture Start"
                            type="time"
                            value={templateForm.firstLectureStart}
                            onChange={(e) => setTemplateForm({ ...templateForm, firstLectureStart: e.target.value })}
                          />
                          <InputField
                            label="Lecture Length (Minutes)"
                            type="number"
                            min="1"
                            value={templateForm.lectureLength}
                            onChange={(e) => setTemplateForm({ ...templateForm, lectureLength: e.target.value })}
                            placeholder="Write minutes per lecture"
                          />
                          <div className="md:col-span-2">
                            <InputField
                              label="Lunch Length After 4th Lecture (Minutes)"
                              type="number"
                              min="0"
                              value={templateForm.lunchLength}
                              onChange={(e) => setTemplateForm({ ...templateForm, lunchLength: e.target.value })}
                              placeholder="Write lunch minutes"
                            />
                          </div>
                        </div>

                        <div className="mt-6 flex flex-col gap-3 lg:flex-row lg:items-center">
                          <button
                            type="button"
                            onClick={handleGenerateTemplate}
                            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-600"
                          >
                            <FileText size={15} />
                            Generate Excel Template
                          </button>
                          <p className="text-sm font-semibold text-slate-500">
                            Generate karne ke baad template website ke andar edit hoga. Final timetable ready hone par hi save karein.
                          </p>
                        </div>
                        {selectedTemplateDraftRecord ? (
                          <div className="mt-6 flex flex-col gap-3 rounded-[1.6rem] border border-emerald-200 bg-emerald-50 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
                            <div>
                              <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">Saved Draft Available</p>
                              <p className="mt-1 text-sm font-semibold text-slate-600">
                                Aapne is class ke liye draft save kiya hua hai. Usse dubara open karke continue kar sakte hain.
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={handleOpenSavedDraft}
                              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700 transition hover:bg-emerald-100"
                            >
                              <FileText size={15} />
                              Open Saved Draft
                            </button>
                          </div>
                        ) : null}
                      </div>
                    ) : null}
                  </div>
                )}
              </Panel>
            }
          />
        ) : null}

        {activePage === 'template-editor' ? (
          <section className="mt-8">
            <Panel
              title={generatedTemplateDraft ? `${generatedTemplateDraft.className} Template Editor` : 'Template Editor'}
              description="Edit subject and teacher name for every lecture cell. Final save will move the completed template into the timetable records, while save draft keeps your work separate until it is ready."
            >
              {generatedTemplateDraft ? (
                <>
                  <div className="mt-6 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <p className="text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">Separate Editor Page</p>
                      <h4 className="mt-2 font-serif text-3xl font-black italic tracking-tight text-slate-950">
                        {generatedTemplateDraft.schoolName}
                      </h4>
                      <p className="mt-2 text-sm font-semibold text-slate-500">
                        {generatedTemplateDraft.className} | Lecture count {generatedTemplateDraft.lectureCount} | Lunch after lecture 4
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      <button
                        type="button"
                        onClick={handleSaveGeneratedTemplate}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-700"
                      >
                        <FileText size={15} />
                        Final Save
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveTemplateDraft}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-slate-800"
                      >
                        <Download size={15} />
                        Save Draft
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelTemplateEditor}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-slate-600 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
                      >
                        <X size={15} />
                        Cancel
                      </button>
                    </div>
                  </div>

                  <div className="mt-6 max-w-xl">
                    <SelectField
                      label="Attendance Teacher"
                      value={generatedTemplateDraft.attendanceTeacherId || ''}
                      onChange={(e) => {
                        const option = teacherOptions.find((entry) => String(entry.value) === String(e.target.value));
                        setGeneratedTemplateDraft({
                          ...generatedTemplateDraft,
                          attendanceTeacherId: option?.value || '',
                          attendanceTeacher: option?.label || '',
                        });
                      }}
                      options={['', ...teacherOptions.map((option) => option.value)]}
                      renderOptionLabel={(value) => teacherOptions.find((option) => String(option.value) === String(value))?.label || 'Select teacher for class attendance'}
                    />
                  </div>

                  <div className="mt-6 overflow-x-auto rounded-[1.4rem] border border-slate-200 bg-white">
                    <table className="min-w-full border-collapse">
                      <thead>
                        <tr>
                          <th
                            colSpan={1 + buildTimetableDisplayColumns(generatedTemplateDraft.lecturePlan).length}
                            className="border border-slate-300 bg-emerald-700 px-3 py-3 text-center text-base font-black text-white"
                          >
                            {generatedTemplateDraft.schoolName}
                          </th>
                        </tr>
                        <tr>
                          <th className="border border-slate-300 bg-slate-950 px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-white">
                            Day
                          </th>
                          {buildTimetableDisplayColumns(generatedTemplateDraft.lecturePlan).map((column) => (
                            <th
                              key={`editor-column-${column.key}`}
                              className={`border border-slate-300 px-3 py-2 text-center text-xs font-black ${
                                column.type === 'lunch' ? 'bg-amber-100 text-amber-950' : 'bg-emerald-50 text-slate-950'
                              }`}
                            >
                              {column.type === 'lunch' ? (
                                <div>
                                  <div>Lunch</div>
                                  <div className="mt-1 text-[11px] font-semibold text-amber-800">{column.timeLabel}</div>
                                </div>
                              ) : (
                                <div>
                                  <div>Lecture {column.lecture.lectureNumber}</div>
                                  <div className="mt-1 text-[11px] font-semibold text-slate-600">
                                    {column.lecture.timeFrom} - {column.lecture.timeTo}
                                  </div>
                                </div>
                              )}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {generatedTemplateDraft.rows.map((row, dayIndex) => (
                          <tr key={`editor-${row.day}`}>
                            <td className="border border-slate-300 bg-slate-50 px-3 py-3 align-top text-xs font-black text-slate-950">
                              {row.day}
                            </td>
                            {buildTimetableDisplayColumns(generatedTemplateDraft.lecturePlan).map((column) => {
                              if (column.type === 'lunch') {
                                if (dayIndex !== 0) return null;
                                return (
                                  <td
                                    key={`${row.day}-lunch`}
                                    rowSpan={generatedTemplateDraft.rows.length}
                                    className="border border-slate-300 bg-amber-50 px-3 py-2 align-middle text-center"
                                  >
                                    <div className="flex min-h-full min-w-18 items-center justify-center rounded-xl border border-amber-200 bg-amber-100/70 px-2 py-6">
                                      <div
                                        className="text-sm font-black uppercase tracking-[0.18em] text-amber-900"
                                        style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
                                      >
                                        Lunch
                                      </div>
                                    </div>
                                  </td>
                                );
                              }

                              const slot = row.slots[column.lectureIndex] || { classSubjectId: '', subjectName: '', teacherId: '', teacherName: '' };
                              return (
                                <td key={`${row.day}-editor-${column.lectureIndex}`} className="border border-slate-300 px-2 py-2 align-top">
                                  <div className="min-w-37.5 space-y-2">
                                    <CompactTemplateField
                                      prefix="S"
                                      value={slot.classSubjectId || ''}
                                      onChange={(e) => handleDraftSubjectChange(dayIndex, column.lectureIndex, e.target.value)}
                                      placeholder="Write subject name"
                                      suggestions={selectedClassSubjectOptions}
                                      datalistId={`subject-options-${slugifyTimetableValue(selectedClass || generatedTemplateDraft.className)}`}
                                    />
                                    <CompactTemplateSelect
                                      prefix="T"
                                      value={slot.teacherId || ''}
                                      onChange={(e) => handleDraftTeacherChange(dayIndex, column.lectureIndex, e.target.value)}
                                      options={selectedClassTeacherOptions}
                                    />
                                  </div>
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
                  <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
                    <FileText size={34} />
                  </div>
                  <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No draft open</h4>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">
                    Pehle class page se template generate karein ya saved draft open karein.
                  </p>
                </div>
              )}
            </Panel>
          </section>
        ) : null}

      </main>

    </div>
  );
};

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const dayOrder = weekDays.reduce((map, day, index) => ({ ...map, [day]: index }), {});
const classTemplateDays = weekDays.slice(0, 6);

const buildTimetableTemplateFileName = (className) => {
  const slug = slugifyTimetableValue(className || 'class-timetable');
  return `${slug || 'class-timetable'}-template.xls`;
};

const normalizeTimetableClassLabel = (value) => {
  const normalized = String(value || '').trim();
  if (!normalized) return '';
  return getCurriculumClassSubjectKey(normalized);
};

const getCurriculumClassSubjectKey = (value) => {
  const normalized = String(value || '').trim();
  if (!normalized) return '';
  const classNumber = extractLeadingClassNumber(normalized);
  if (classNumber && classNumber >= 1 && classNumber <= 8) {
    return normalized.split('/')[0].trim().toLowerCase();
  }
  return normalized.toLowerCase().replace(/\s*\/\s*/g, '/').replace(/\s+/g, ' ');
};

const extractLeadingClassNumber = (value) => {
  const match = String(value || '').trim().match(/^(?:class\s*)?(\d{1,2})(?:\b|\s|\/)/i);
  return match ? Number(match[1]) : null;
};

const buildStudentTimetableClassCandidates = (student) => {
  if (!student || typeof student !== 'object') return [];

  const className = String(student.className || '').trim();
  const section = String(student.section || '').trim();
  const assignedClass = String(student.assignedClass || '').trim();
  const combinedClass = [className, section].filter(Boolean).join(' / ');

  if (assignedClass || combinedClass) {
    return [assignedClass, combinedClass].filter(Boolean);
  }

  return [className].filter(Boolean);
};

const slugifyTimetableValue = (value) => String(value || '')
  .toLowerCase()
  .replace(/[^a-z0-9]+/g, '-')
  .replace(/^-+|-+$/g, '');

const buildLecturePlan = (startTime, lectureCount, lectureLength, lunchLength) => {
  let currentMinutes = parseTimeToMinutes(startTime);

  return Array.from({ length: lectureCount }, (_, index) => {
    const lectureNumber = index + 1;
    const timeFrom = formatMinutesToTime(currentMinutes);
    const timeTo = formatMinutesToTime(currentMinutes + lectureLength);
    currentMinutes += lectureLength;

    if (lectureNumber === 4 && lunchLength > 0 && lectureNumber < lectureCount) {
      currentMinutes += lunchLength;
    }

    return {
      lectureNumber,
      timeFrom,
      timeTo,
    };
  });
};

const buildTimetableDisplayColumns = (lecturePlan = []) => {
  const columns = [];

  lecturePlan.forEach((lecture, index) => {
    columns.push({
      key: `lecture-${lecture.lectureNumber}`,
      type: 'lecture',
      lecture,
      lectureIndex: index,
    });

    if (lecture.lectureNumber === 4 && index < lecturePlan.length - 1) {
      columns.push({
        key: 'lunch-after-4',
        type: 'lunch',
        timeLabel: `${lecture.timeTo} onwards`,
      });
    }
  });

  return columns;
};

const parseTimeToMinutes = (value) => {
  const [hour = '0', minute = '0'] = String(value || '').split(':');
  return (Number(hour) * 60) + Number(minute);
};

const formatMinutesToTime = (totalMinutes) => {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
};

const calculateLectureLength = (lecturePlan = []) => {
  const firstLecture = lecturePlan[0];
  if (!firstLecture?.timeFrom || !firstLecture?.timeTo) {
    return '';
  }

  return Math.max(1, parseTimeToMinutes(firstLecture.timeTo) - parseTimeToMinutes(firstLecture.timeFrom));
};

const updateDraftSlot = (current, dayIndex, slotIndex, patch) => {
  if (!current) return current;

  return {
    ...current,
    rows: current.rows.map((row, currentDayIndex) => (
      currentDayIndex !== dayIndex
        ? row
        : {
            ...row,
            slots: row.slots.map((slot, currentSlotIndex) => (
              currentSlotIndex !== slotIndex ? slot : { ...slot, ...patch }
            )),
          }
    )),
  };
};

const normalizeGeneratedTemplateDraft = (draft) => {
  if (!draft) return draft;

  return {
    ...draft,
    schoolName: formatTimetableText(draft.schoolName),
    className: formatTimetableText(draft.className),
    attendanceTeacherId: draft.attendanceTeacherId ? Number(draft.attendanceTeacherId) : null,
    attendanceTeacher: formatTeacherStoredValue(draft.attendanceTeacher),
    rows: (draft.rows || []).map((row) => ({
      ...row,
      slots: (row.slots || []).map((slot) => ({
        ...slot,
        classSubjectId: slot.classSubjectId ? Number(slot.classSubjectId) : null,
        subjectName: formatTimetableText(slot.subjectName),
        teacherId: slot.teacherId ? Number(slot.teacherId) : null,
        teacherName: formatTeacherStoredValue(slot.teacherName),
      })),
    })),
  };
};

const findUnusedTimetableSubjects = (draft, availableSubjects = []) => {
  const normalizedAvailableSubjects = [...new Set(
    availableSubjects
      .map((subject) => formatTimetableText(subject.subjectName || subject.label || subject))
      .filter(Boolean),
  )];

  if (!normalizedAvailableSubjects.length) return [];

  const usedSubjects = new Set(
    (draft?.rows || [])
      .flatMap((row) => row.slots || [])
      .map((slot) => formatTimetableText(slot.subjectName))
      .filter(Boolean),
  );

  return normalizedAvailableSubjects.filter((subjectName) => !usedSubjects.has(subjectName));
};

const formatTeacherStoredValue = (value) => {
  const normalized = String(value || '').trim().replace(/\s+/g, ' ');
  if (!normalized) return '';

  const idMatch = normalized.match(/\(([^)]*)\)\s*$/);
  const teacherId = idMatch?.[1]?.trim() || '';
  const teacherName = normalized.replace(/\s*\([^)]*\)\s*$/, '');
  const formattedName = formatTimetableText(teacherName);

  return teacherId ? `${formattedName} (${teacherId})` : formattedName;
};

const formatTimetableText = (value) => {
  const normalized = String(value || '').trim().replace(/\s+/g, ' ');
  if (!normalized) return '';

  return normalized
    .toLowerCase()
    .split(' ')
    .map((word) => word ? `${word[0].toUpperCase()}${word.slice(1)}` : '')
    .join(' ');
};

const buildTimetableTemplateDataUri = ({ schoolName, className, lecturePlan, rows = [] }) => {
  const displayColumns = buildTimetableDisplayColumns(lecturePlan);
  const lectureHeaderCells = displayColumns.map((column) => {
    if (column.type === 'lunch') {
      return `
      <th style="border:1px solid #0f172a;background:#fde68a;padding:8px 6px;font-size:11px;font-weight:700;text-align:center;">
        Lunch<br />
        <span style="font-size:10px;font-weight:600;">${column.timeLabel}</span>
      </th>`;
    }

    return `
      <th style="border:1px solid #0f172a;background:#d1fae5;padding:8px 6px;font-size:11px;font-weight:700;text-align:center;">
        Lecture ${column.lecture.lectureNumber}<br />
        <span style="font-size:10px;font-weight:600;">${column.lecture.timeFrom} - ${column.lecture.timeTo}</span>
      </th>`;
  }).join('');

  const tableRows = classTemplateDays.map((day, dayIndex) => `
      <tr>
        <td style="border:1px solid #0f172a;background:#f8fafc;padding:8px 6px;font-size:11px;font-weight:700;">${day}</td>
        ${displayColumns.map((column) => {
          if (column.type === 'lunch') {
            if (dayIndex !== 0) return '';
            return `
          <td rowspan="${classTemplateDays.length}" style="border:1px solid #0f172a;background:#fef3c7;padding:7px 6px;vertical-align:middle;min-width:72px;text-align:center;font-size:11px;font-weight:700;color:#78350f;">
            <div style="display:flex;align-items:center;justify-content:center;min-height:100%;padding:8px 0;">
              <span style="writing-mode:vertical-rl;transform:rotate(180deg);letter-spacing:0.18em;text-transform:uppercase;">Lunch</span>
            </div>
          </td>`;
          }

          const slot = rows[dayIndex]?.slots?.[column.lectureIndex] || { subjectName: '', teacherName: '' };
          return `
          <td style="border:1px solid #0f172a;padding:7px 6px;vertical-align:top;min-width:130px;height:52px;">
            <div style="margin:0 0 6px 0;font-size:11px;color:#0f172a;"><strong>S:</strong> ${escapeTemplateHtml(slot.subjectName)}</div>
            <div style="font-size:11px;color:#0f172a;"><strong>T:</strong> ${escapeTemplateHtml(slot.teacherName)}</div>
          </td>`;
        }).join('')}
      </tr>`).join('');

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head>
        <meta charset="UTF-8" />
        <meta name="ProgId" content="Excel.Sheet" />
      </head>
      <body>
        <table border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-family:Arial,sans-serif;min-width:${110 + (displayColumns.length * 136)}px;">
          <tr>
            <th colspan="${1 + displayColumns.length}" style="border:1px solid #0f172a;background:#0f766e;color:#ffffff;padding:10px 8px;font-size:16px;font-weight:700;text-align:center;">
              ${escapeTemplateHtml(schoolName)}
            </th>
          </tr>
          <tr>
            <th style="border:1px solid #0f172a;background:#0f172a;color:#ffffff;padding:9px 6px;font-size:11px;font-weight:700;text-align:center;">Day</th>
            ${lectureHeaderCells}
          </tr>
          ${tableRows}
        </table>
        <p style="margin-top:10px;font-size:10px;color:#64748b;">Class ${escapeTemplateHtml(className)}</p>
      </body>
    </html>`;

  return `data:text/html;charset=utf-8,${encodeURIComponent(html)}`;
};

const escapeTemplateHtml = (value) => String(value || '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#39;');

const mapTeacherOptionToLegacyTeacher = (teacher) => {
  const displayName = String(teacher.name || '').trim();
  const [firstName = '', ...lastNameParts] = displayName.split(/\s+/).filter(Boolean);
  return {
    ...teacher,
    firstName,
    lastName: lastNameParts.join(' '),
    name: displayName,
    status: 'Active',
  };
};

const findClassSummary = (summaries, className) => (
  (summaries || []).find((record) => getTimetableClassKey(record.displayName || record.className) === getTimetableClassKey(className)) || null
);

const getTimetableClassKey = (value) => (
  String(value || '').trim().toLowerCase().replace(/\s*\/\s*/g, '/').replace(/\s+/g, ' ')
);

const sortByDayAndTime = (a, b) => {
  return (dayOrder[a.dayOfWeek] ?? 99) - (dayOrder[b.dayOfWeek] ?? 99) || String(a.timeFrom || '').localeCompare(String(b.timeFrom || ''));
};

const deriveTeacherClassesFromTimetables = (classTimetables, teacher) => {
  if (!teacher) return [];

  const teacherKeys = buildTeacherIdentityKeys(teacher);
  const classSet = new Set();

  classTimetables.forEach((record) => {
    if (attendanceTeacherMatches(record, teacherKeys)) {
      if (record.className) classSet.add(record.className);
      return;
    }

    const template = readTeacherTimetableTemplate(record);
    const hasTeacherSlot = template?.rows?.some((row) =>
      (row.slots || []).some((slot) => slotMatchesTeacher(slot, teacherKeys)),
    );

    if (hasTeacherSlot && record.className) {
      classSet.add(record.className);
    }
  });

  return [...classSet].sort(compareClassNames);
};

const resolveTimetableAttendanceTeacher = (record) => {
  return formatTeacherStoredValue(
    record?.templateData?.attendanceTeacher
      || record?.templateMeta?.attendanceTeacher
      || '',
  );
};

const attendanceTeacherMatches = (record, teacherKeys) => {
  const attendanceTeacher = resolveTimetableAttendanceTeacher(record).toLowerCase();
  return Boolean(attendanceTeacher) && teacherKeys.some((key) => key === attendanceTeacher);
};

const readTeacherTimetableTemplate = (record) => {
  if (record?.templateData?.rows?.length && record?.templateData?.lecturePlan?.length) {
    return record.templateData;
  }

  if (record?.fileType === 'text/html' && typeof window !== 'undefined') {
    return parseTemplateFromHtmlDataUri(record.fileData, record.className);
  }

  return null;
};

const parseTemplateFromHtmlDataUri = (dataUri, className) => {
  const html = decodeTimetableHtml(dataUri);
  if (!html) return null;

  const parser = new DOMParser();
  const documentNode = parser.parseFromString(html, 'text/html');
  const table = documentNode.querySelector('table');
  if (!table) return null;

  const rows = Array.from(table.querySelectorAll('tr'));
  if (rows.length < 3) return null;

  const headerCells = Array.from(rows[1].querySelectorAll('th'));
  const lecturePlan = headerCells.slice(1)
    .map((cell) => {
      const text = cell.textContent?.replace(/\s+/g, ' ').trim() || '';
      const lectureMatch = text.match(/Lecture\s+(\d+)/i);
      if (!lectureMatch) return null;
      const timeMatch = text.match(/(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})/);
      return {
        lectureNumber: Number(lectureMatch[1]),
        timeFrom: timeMatch?.[1] || '',
        timeTo: timeMatch?.[2] || '',
      };
    })
    .filter(Boolean);

  const routineRows = rows.slice(2)
    .map((rowNode) => {
      const cells = Array.from(rowNode.querySelectorAll('td'));
      if (!cells.length) return null;

      const day = cells[0]?.textContent?.trim();
      if (!day) return null;

      const slotCells = cells.filter((cell, index) => {
        if (index === 0) return false;
        return !/Lunch/i.test(cell.textContent || '');
      });

      return {
        day,
        slots: lecturePlan.map((_, slotIndex) => {
          const slotCell = slotCells[slotIndex];
          const slotText = slotCell?.textContent?.replace(/\s+/g, ' ').trim() || '';
          return {
            subjectName: extractSlotValue(slotText, 'S'),
            teacherName: extractSlotValue(slotText, 'T'),
          };
        }),
      };
    })
    .filter(Boolean);

  if (!lecturePlan.length || !routineRows.length) return null;

  return {
    className,
    lecturePlan,
    rows: routineRows,
  };
};

const decodeTimetableHtml = (dataUri) => {
  if (!dataUri || typeof dataUri !== 'string') return '';
  const prefix = 'data:text/html;charset=utf-8,';
  if (!dataUri.startsWith(prefix)) return '';

  try {
    return decodeURIComponent(dataUri.slice(prefix.length));
  } catch {
    return '';
  }
};

const extractSlotValue = (slotText, key) => {
  const expression = new RegExp(`${key}:\\s*(.*?)(?=\\s+[A-Z]:|$)`, 'i');
  return slotText.match(expression)?.[1]?.trim() || '';
};

const buildTeacherIdentityKeys = (teacher) => {
  const fullName = teacher?.name || `${teacher?.firstName || ''} ${teacher?.lastName || ''}`.trim();
  return [
    fullName,
    teacher?.employeeId,
    teacher?.employeeId,
    fullName && teacher?.employeeId ? `${fullName} (${teacher.employeeId})` : '',
    fullName && teacher?.employeeId ? `${fullName} (${teacher.employeeId})` : '',
  ]
    .map((value) => String(value || '').trim().toLowerCase())
    .filter(Boolean);
};

const slotMatchesTeacher = (slot, teacherKeys) => {
  const teacherValue = String(slot?.teacherName || '').trim().toLowerCase();
  return Boolean(teacherValue) && teacherKeys.some((key) => key === teacherValue);
};

const compareClassNames = (a, b) => {
  const left = getClassSortValue(a);
  const right = getClassSortValue(b);
  return left.rank - right.rank || left.section.localeCompare(right.section) || a.localeCompare(b);
};

const getClassSortValue = (className) => {
  const normalized = className.toLowerCase();
  const section = className.split('/')[1]?.trim() || '';

  if (normalized.includes('nursery')) return { rank: 0, section };
  if (normalized.includes('lkg')) return { rank: 1, section };
  if (normalized.includes('ukg')) return { rank: 2, section };

  const classMatch = normalized.match(/class\s*(\d+)/);
  if (classMatch) {
    return { rank: 2 + Number(classMatch[1]), section };
  }

  return { rank: 1000, section };
};

const formatSavedDate = (value) => {
  if (!value) return 'date pending';
  return new Date(value).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const formatSavedTime = (value) => {
  if (!value) return 'Time pending';
  return new Date(value).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

const isImageFile = (record) => {
  return record.fileType?.startsWith('image/') || /\.(png|jpe?g|gif|webp|svg)$/i.test(record.fileName || '');
};

const isPreviewableFile = (record) => {
  return Boolean(record?.fileData);
};

const TwoColumnPage = ({ left, right }) => (
  <div className="mt-8 grid gap-8 xl:grid-cols-[0.95fr_1.05fr]">
    {left}
    {right}
  </div>
);

const Panel = ({ title, description, children }) => (
  <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
    {children}
  </section>
);

const RecordCard = ({ icon, title, subtitle, children }) => (
  <article className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
          {React.createElement(icon, { size: 20 })}
        </div>
        <div className="min-w-0">
          <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{title}</h4>
          <p className="text-[11px] font-black uppercase tracking-[0.16em] text-emerald-700">{subtitle}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  </article>
);

const SavedTimetablePreview = ({ record }) => {
  const attendanceTeacher = resolveTimetableAttendanceTeacher(record);

  if (!isPreviewableFile(record)) {
    return (
      <div className="mt-5 rounded-[1.4rem] border border-dashed border-slate-300 bg-white px-5 py-8 text-center">
        <p className="text-sm font-semibold text-slate-500">Saved timetable preview is not available.</p>
      </div>
    );
  }

  return (
    <div className="mt-5 overflow-hidden rounded-[1.4rem] border border-slate-200 bg-white">
      <div className="flex flex-col gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">Saved Timetable</p>
          <p className="mt-1 truncate text-sm font-black text-slate-950">{record.fileName || record.className || 'Class timetable'}</p>
          <p className="mt-1 text-xs font-bold text-slate-500">
            Attendance Teacher: {attendanceTeacher || 'Not assigned'}
          </p>
        </div>
        <a
          href={record.fileData}
          download={record.fileName || 'class-timetable'}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.16em] text-white transition hover:bg-emerald-600"
        >
          <Download size={15} />
          Download
        </a>
      </div>
      <div className="bg-white p-3">
        {isImageFile(record) ? (
          <img src={record.fileData} alt={record.fileName || 'Saved timetable'} className="mx-auto max-h-[70vh] w-auto max-w-full object-contain" />
        ) : (
          <iframe title={record.fileName || 'Saved timetable'} src={record.fileData} className="h-[70vh] w-full rounded-xl bg-white" />
        )}
      </div>
    </div>
  );
};

const InputField = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    />
  </div>
);

const SelectField = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option || 'empty-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
        </option>
      ))}
    </select>
  </div>
);

const CompactTemplateField = ({ prefix, suggestions = [], datalistId, ...props }) => (
  <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2">
    <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-md bg-emerald-100 px-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700">
      {prefix}
    </span>
    {suggestions.length ? (
      <select
        className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none"
        {...props}
      >
        <option value="">Select</option>
        {suggestions.map((option) => (
          <option key={option.value || option} value={option.value || option}>
            {option.label || option}
          </option>
        ))}
      </select>
    ) : (
      <input
        className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none placeholder:text-slate-400"
        {...props}
      />
    )}
  </label>
);

const CompactTemplateSelect = ({ prefix, options, ...props }) => (
  <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2">
    <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-md bg-emerald-100 px-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-emerald-700">
      {prefix}
    </span>
    <select
      className="w-full bg-transparent text-xs font-semibold text-slate-900 outline-none"
      {...props}
    >
      <option value="">Select teacher</option>
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  </label>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
    />
  </div>
);

const InfoPill = ({ icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    {React.createElement(icon, { size: 15, className: 'text-emerald-700' })}
    <span>{text}</span>
  </div>
);

export default TimetableManagement;
