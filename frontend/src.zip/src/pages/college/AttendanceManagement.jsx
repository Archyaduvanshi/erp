import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ClipboardCheck,
  Search,
  ChevronDown,
  Trash2,
  UserCheck,
  UserX,
  Users,
} from 'lucide-react';
import { db } from '../../utils/db';

const createSessionForm = () => ({
  date: new Date().toISOString().split('T')[0],
  lectureNumber: '',
  subject: '',
  markedBy: '',
});

const AttendanceManagement = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [students, setStudents] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [sessionForm, setSessionForm] = useState(createSessionForm);
  const [attendanceMap, setAttendanceMap] = useState({});
  const [classSearch, setClassSearch] = useState('');
  const [recordSearch, setRecordSearch] = useState('');

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setStudents(db.getAll('students'));
    setTeachers(db.getAll('teachers'));
    setAttendanceRecords(db.getAll('attendance_records'));
  };

  const teacherSession = useMemo(() => {
    if (!session || session.role !== 'teacher') return null;
    return teachers.find((teacher) => String(teacher.id) === String(session.teacherId)) || null;
  }, [session, teachers]);

  const teacherName = teacherSession
    ? `${teacherSession.firstName || ''} ${teacherSession.lastName || ''}`.trim() || teacherSession.teacherSystemId || 'Teacher'
    : '';

  const teacherClassOptions = useMemo(() => {
    if (!teacherSession?.assignedClass) return [];
    return teacherSession.assignedClass
      .split(',')
      .map((className) => className.trim())
      .filter(Boolean);
  }, [teacherSession]);

  const classList = useMemo(() => {
    const classes = [...new Set(students.map((student) => student.assignedClass?.trim()).filter(Boolean))];
    const visibleClasses = teacherSession
      ? classes.filter((className) => teacherClassOptions.includes(className))
      : classes;
    return visibleClasses.sort(compareClassNames);
  }, [students, teacherClassOptions, teacherSession]);

  const filteredClasses = useMemo(() => {
    const query = classSearch.trim().toLowerCase();
    return classList.filter((className) => !query || className.toLowerCase().includes(query));
  }, [classList, classSearch]);

  const selectedClassStudents = useMemo(() => {
    return students
      .filter((student) => student.assignedClass === selectedClass)
      .sort((a, b) => {
        const nameA = `${a.firstName || ''} ${a.lastName || ''}`.trim().toLowerCase();
        const nameB = `${b.firstName || ''} ${b.lastName || ''}`.trim().toLowerCase();
        return nameA.localeCompare(nameB);
      });
  }, [selectedClass, students]);

  const teacherOptions = useMemo(() => {
    const visibleTeachers = selectedClass
      ? teachers.filter((teacher) => {
        const assignedClasses = String(teacher.assignedClass || '')
          .split(',')
          .map((className) => className.trim())
          .filter(Boolean);
        return assignedClasses.includes(selectedClass);
      })
      : teachers;

    return visibleTeachers
      .map((teacher) => ({
        id: teacher.id,
        name: `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim(),
        subject: teacher.specialization || '',
      }))
      .filter((teacher) => teacher.name);
  }, [selectedClass, teachers]);

  const subjectOptions = useMemo(() => {
    const teacherSubjects = teacherOptions.map((teacher) => teacher.subject).filter(Boolean);
    return [...new Set(teacherSubjects)].sort((a, b) => a.localeCompare(b));
  }, [teacherOptions]);

  const lectureOptions = ['1', '2', '3', '4', '5', '6', '7', '8'];

  const filteredRecords = useMemo(() => {
    const query = recordSearch.trim().toLowerCase();
    return attendanceRecords
      .filter((record) => selectedClass ? record.className === selectedClass : true)
      .filter((record) => {
        if (!query) return true;
        return (
          record.date?.toLowerCase().includes(query) ||
          record.className?.toLowerCase().includes(query) ||
          record.studentName?.toLowerCase().includes(query) ||
          record.rollNo?.toLowerCase().includes(query) ||
          record.status?.toLowerCase().includes(query) ||
          record.subject?.toLowerCase().includes(query) ||
          String(record.lectureNumber || '').toLowerCase().includes(query) ||
          record.markedBy?.toLowerCase().includes(query)
        );
      })
      .sort((a, b) => new Date(b.createdAt || b.date).getTime() - new Date(a.createdAt || a.date).getTime());
  }, [attendanceRecords, recordSearch, selectedClass]);

  const today = new Date().toISOString().split('T')[0];
  const todayRecords = attendanceRecords.filter((record) => record.date === today);
  const presentCount = todayRecords.filter((record) => record.status === 'Present').length;
  const absentCount = todayRecords.filter((record) => record.status === 'Absent').length;

  const openClassSheet = (className) => {
    setSelectedClass(className);
    setSessionForm({
      ...createSessionForm(),
      subject: teacherSession?.specialization || '',
      markedBy: teacherName,
    });
    setAttendanceMap({});
  };

  const handleStatusChange = (studentId, status) => {
    setAttendanceMap((current) => ({
      ...current,
      [studentId]: status,
    }));
  };

  const handleSaveAttendance = (e) => {
    e.preventDefault();

    const unmarkedStudents = selectedClassStudents.filter((student) => !attendanceMap[String(student.id)]);
    if (!selectedClass || !sessionForm.lectureNumber.trim() || !sessionForm.subject.trim() || !sessionForm.markedBy.trim() || unmarkedStudents.length > 0) {
      return;
    }

    const tenantId = db.getTenantId();
    if (!tenantId) return;

    const key = `${tenantId}_attendance_records`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];

    const remaining = existing.filter((record) => !(
      record.className === selectedClass &&
      record.date === sessionForm.date &&
      String(record.lectureNumber) === String(sessionForm.lectureNumber)
    ));

    const nextRecords = selectedClassStudents.map((student) => ({
      id: Date.now() + Math.floor(Math.random() * 100000) + Number(student.id || 0),
      createdAt: new Date().toISOString(),
      date: sessionForm.date,
      lectureNumber: sessionForm.lectureNumber.trim(),
      subject: sessionForm.subject.trim(),
      markedBy: sessionForm.markedBy.trim(),
      className: selectedClass,
      studentId: student.systemId || String(student.id),
      rollNo: student.enrollmentNo || student.systemId || String(student.id),
      studentName: `${student.firstName || ''} ${student.lastName || ''}`.trim(),
      status: attendanceMap[String(student.id)] || 'Present',
    }));

    localStorage.setItem(key, JSON.stringify([...remaining, ...nextRecords]));
    refreshData();
  };

  const handleDelete = (recordId) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;
    if (!window.confirm('Delete this attendance record?')) return;

    const key = `${tenantId}_attendance_records`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.filter((record) => record.id !== recordId);
    localStorage.setItem(key, JSON.stringify(updated));
    refreshData();
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#ecfdf5_48%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                if (selectedClass) {
                  setSelectedClass('');
                  return;
                }
                navigate(session?.role === 'teacher' ? '/teacher' : '/college');
              }}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              {selectedClass ? 'Back to Classes' : 'Back'}
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Attendance Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">
                {selectedClass ? `${selectedClass} Attendance Sheet` : 'Class Attendance Register'}
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#052e16_0%,#14532d_55%,#022c22_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(20,83,45,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-200">Attendance Register</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Select a class, open its sheet, and mark each student present or absent.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-emerald-50/80">
                {teacherSession
                  ? `Only the classes assigned to ${teacherName || 'this teacher'} are shown here. Students are listed alphabetically with roll number beside their names.`
                  : 'The teacher first chooses a class, then marks attendance with lecture number and subject at the top. Students are shown alphabetically with roll number beside their names.'}
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Classes" value={classList.length} icon={BookOpen} />
              <MetricCard label="Students" value={students.length} icon={Users} />
              <MetricCard label="Today Present" value={presentCount} icon={CheckCircle2} />
              <MetricCard label="Today Absent" value={absentCount} icon={UserX} />
            </div>
          </div>
        </section>

        {!selectedClass ? (
          <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <FormTitle
                title={teacherSession ? 'Teaching Classes' : 'Select Class'}
                description={teacherSession
                  ? 'Open one of your assigned classes to mark or review attendance.'
                  : 'Open any class to start attendance for that group of students.'}
              />
              <SearchInput value={classSearch} onChange={setClassSearch} placeholder="Search class or section..." />
            </div>

            {filteredClasses.length > 0 ? (
              <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {filteredClasses.map((className) => {
                  const classStudents = students.filter((student) => student.assignedClass === className);
                  return (
                    <button
                      key={className}
                      onClick={() => openClassSheet(className)}
                      className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-6 text-left transition hover:-translate-y-1 hover:border-emerald-200 hover:bg-white hover:shadow-[0_18px_40px_-28px_rgba(16,185,129,0.35)]"
                    >
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
                        <BookOpen size={20} />
                      </div>
                      <h3 className="mt-5 text-xl font-black tracking-tight text-slate-950">{className}</h3>
                      <p className="mt-2 text-sm leading-6 text-slate-500">
                        {classStudents.length} students ready for attendance.
                      </p>
                      <span className="mt-5 inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-700">
                        Open class sheet
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <EmptyState
                icon={BookOpen}
                title="No classes available"
                description="Add students with assigned class or section first, then attendance classes will appear here."
              />
            )}
          </section>
        ) : (
          <div className="mt-8 grid gap-8">
            <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
              <FormTitle title={`${selectedClass} Session Details`} description="Set the lecture number, subject, date, and teacher before saving attendance for this class." />
              <form className="mt-8 space-y-8" onSubmit={handleSaveAttendance}>
                <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
                  <CreativeInput
                    label="Date"
                    type="date"
                    value={sessionForm.date}
                    onChange={(e) => setSessionForm({ ...sessionForm, date: e.target.value })}
                  />
                  <CreativeSelect
                    label="Lecture Number"
                    value={sessionForm.lectureNumber}
                    onChange={(e) => setSessionForm({ ...sessionForm, lectureNumber: e.target.value })}
                    options={['', ...lectureOptions]}
                    renderOptionLabel={(value) => value || 'Select lecture'}
                  />
                  <CreativeSelect
                    label="Subject"
                    value={sessionForm.subject}
                    onChange={(e) => setSessionForm({ ...sessionForm, subject: e.target.value })}
                    options={['', ...subjectOptions]}
                    renderOptionLabel={(value) => value || 'Select subject'}
                    disabled={!!teacherSession?.specialization}
                  />
                  <CreativeSelect
                    label="Teacher"
                    value={sessionForm.markedBy}
                    onChange={(e) => setSessionForm({ ...sessionForm, markedBy: e.target.value })}
                    options={['', ...teacherOptions.map((teacher) => teacher.name)]}
                    renderOptionLabel={(value) => value || 'Select teacher'}
                    disabled={!!teacherSession}
                  />
                </div>

                {selectedClassStudents.length > 0 ? (
                  <div className="overflow-hidden rounded-[1.8rem] border border-slate-200">
                    <table className="w-full text-left">
                      <thead className="bg-slate-950 text-white">
                        <tr className="text-[11px] font-black uppercase tracking-[0.24em]">
                          <th className="px-6 py-4">Student Name</th>
                          <th className="px-6 py-4">Father Name</th>
                          <th className="px-6 py-4">Roll No</th>
                          <th className="px-6 py-4 text-center">Present</th>
                          <th className="px-6 py-4 text-center">Absent</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 bg-white">
                        {selectedClassStudents.map((student) => {
                          const studentKey = String(student.id);
                          const fullName = `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Unnamed student';
                          const fatherName = student.guardianName || 'Father name not added';
                          const rollNo = student.enrollmentNo || student.systemId || String(student.id);

                          return (
                            <tr key={student.id} className="transition hover:bg-emerald-50/50">
                              <td className="px-6 py-5">
                                <p className="text-sm font-black text-slate-950">{fullName}</p>
                              </td>
                              <td className="px-6 py-5 text-sm font-semibold text-slate-600">{fatherName}</td>
                              <td className="px-6 py-5 text-sm font-semibold text-slate-600">{rollNo}</td>
                              <td className="px-6 py-5 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(studentKey, 'Present')}
                                  className={`min-w-28 rounded-2xl px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] transition ${
                                    attendanceMap[studentKey] === 'Present'
                                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100'
                                      : 'border border-slate-200 bg-slate-50 text-slate-500 hover:border-emerald-300 hover:text-emerald-700'
                                  }`}
                                >
                                  Present
                                </button>
                              </td>
                              <td className="px-6 py-5 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(studentKey, 'Absent')}
                                  className={`min-w-28 rounded-2xl px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] transition ${
                                    attendanceMap[studentKey] === 'Absent'
                                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-100'
                                      : 'border border-slate-200 bg-slate-50 text-slate-500 hover:border-rose-300 hover:text-rose-700'
                                  }`}
                                >
                                  Absent
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <EmptyState
                    icon={Users}
                    title="No students in this class"
                    description="This class is selected, but there are no students saved under it yet."
                  />
                )}

                <div className="rounded-[1.6rem] border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">
                  Select lecture, subject, teacher, and one status for every student before saving attendance.
                </div>

                <PrimaryButton
                  type="submit"
                  icon={ClipboardCheck}
                  label="Save Class Attendance"
                  disabled={
                    !sessionForm.lectureNumber ||
                    !sessionForm.subject ||
                    !sessionForm.markedBy ||
                    selectedClassStudents.some((student) => !attendanceMap[String(student.id)])
                  }
                />
              </form>
            </section>

            <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <FormTitle title="Saved Attendance Records" description="Review saved attendance entries for this class by date, lecture, subject, student, or status." />
                <SearchInput value={recordSearch} onChange={setRecordSearch} placeholder="Search student, roll no, subject, lecture..." />
              </div>

              {filteredRecords.length > 0 ? (
                <div className="mt-8 grid gap-5">
                  {filteredRecords.map((record) => (
                    <article key={record.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${record.status === 'Present' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                              {record.status === 'Present' ? <UserCheck size={20} /> : <UserX size={20} />}
                            </div>
                            <div>
                              <h3 className="text-lg font-black tracking-tight text-slate-950">{record.studentName || 'Unnamed student'}</h3>
                              <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">{record.className || 'Class pending'}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <InfoPill icon={CalendarDays} text={record.date || 'Date missing'} />
                            <InfoPill icon={Users} text={`Roll No ${record.rollNo || '-'}`} />
                            <InfoPill icon={BookOpen} text={`${record.subject || 'Subject missing'} • Lecture ${record.lectureNumber || '-'}`} />
                            <InfoPill icon={record.status === 'Present' ? UserCheck : UserX} text={record.status || 'Status missing'} />
                            <InfoPill icon={ClipboardCheck} text={record.markedBy || 'Marker not added'} />
                          </div>
                        </div>

                        <button
                          onClick={() => handleDelete(record.id)}
                          className="inline-flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={ClipboardCheck}
                  title="No saved records for this class"
                  description="Save attendance for this class, then the recorded students will appear here."
                />
              )}
            </section>
          </div>
        )}
      </div>
    </div>
  );
};

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-50/80">{label}</p>
        <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-200/20 bg-emerald-200/10 text-emerald-50">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const FormTitle = ({ title, description }) => (
  <div>
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative min-w-65">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
    />
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <div className="relative">
      <select
        className="w-full appearance-none rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 pr-11 text-sm font-semibold text-slate-900 outline-none transition disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
        {...props}
      >
        {options.map((option) => (
          <option key={option || 'empty-option'} value={option}>
            {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
          </option>
        ))}
      </select>
      <ChevronDown className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    </div>
  </div>
);

const PrimaryButton = ({ type, icon: Icon, label, disabled = false }) => (
  <button
    type={type}
    disabled={disabled}
    className={`inline-flex w-full items-center justify-center gap-2 rounded-2xl px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] transition ${
      disabled
        ? 'cursor-not-allowed bg-slate-200 text-slate-400'
        : 'bg-slate-950 text-white hover:bg-emerald-600'
    }`}
  >
    <Icon size={15} />
    {label}
  </button>
);

const InfoPill = ({ icon: Icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    <Icon size={15} className="text-emerald-700" />
    <span>{text}</span>
  </div>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <Icon size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const compareClassNames = (a, b) => {
  const left = getClassSortValue(a);
  const right = getClassSortValue(b);
  return left.rank - right.rank || left.section.localeCompare(right.section) || a.localeCompare(b);
};

const getClassSortValue = (className) => {
  const normalized = String(className || '').toLowerCase();
  const section = String(className || '').split('/')[1]?.trim() || '';

  if (normalized.includes('nursery')) return { rank: 0, section };
  if (normalized.includes('lkg')) return { rank: 1, section };
  if (normalized.includes('ukg')) return { rank: 2, section };

  const classMatch = normalized.match(/class\s*(\d+)/);
  if (classMatch) {
    return { rank: 2 + Number(classMatch[1]), section };
  }

  return { rank: 1000, section };
};

export default AttendanceManagement;
