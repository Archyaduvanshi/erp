import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  BookOpen,
  BookPlus,
  BookmarkCheck,
  CalendarClock,
  IndianRupee,
  Library,
  MapPin,
  Search,
  Trash2,
  UserRound,
} from 'lucide-react';
import { db } from '../../utils/db';

const today = new Date().toISOString().split('T')[0];

const initialBookForm = {
  isbn: '',
  title: '',
  author: '',
  format: 'Physical',
  shelfLocation: '',
  availableQuantity: '1',
};

const initialIssueForm = {
  bookId: '',
  borrowerId: '',
  issueDate: today,
  dueDate: '',
  returnDate: '',
  finePerDay: '10',
  damageCharges: '0',
};

const LibraryManagement = () => {
  const navigate = useNavigate();
  const [books, setBooks] = useState([]);
  const [issues, setIssues] = useState([]);
  const [students, setStudents] = useState([]);
  const [bookForm, setBookForm] = useState(initialBookForm);
  const [issueForm, setIssueForm] = useState(initialIssueForm);
  const [bookSearch, setBookSearch] = useState('');
  const [issueSearch, setIssueSearch] = useState('');
  const [formatFilter, setFormatFilter] = useState('All Formats');
  const [issueStatusFilter, setIssueStatusFilter] = useState('All Records');
  const [activeDesk, setActiveDesk] = useState(null);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setBooks(db.getAll('library_books'));
    setIssues(db.getAll('library_issues'));
    setStudents(db.getAll('students'));
  };

  const studentOptions = useMemo(() => {
    return students
      .map((student) => ({
        id: student.id,
        label: `${student.firstName || ''} ${student.lastName || ''}`.trim() || student.enrollmentNo || 'Unnamed student',
        subtitle: student.enrollmentNo || student.assignedClass || 'Student record',
      }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [students]);

  const enhancedBooks = useMemo(() => {
    return books.map((book) => {
      const activeIssues = issues.filter((issue) => issue.bookId === book.id && !issue.returnDate).length;
      const stock = Number(book.availableQuantity) || 0;
      return {
        ...book,
        activeIssues,
        inStock: Math.max(stock, 0),
      };
    });
  }, [books, issues]);

  const bookChoices = useMemo(() => {
    return enhancedBooks
      .map((book) => ({
        id: book.id,
        label: `${book.title || 'Untitled Book'}${book.author ? ` by ${book.author}` : ''}`,
        stock: book.inStock,
      }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [enhancedBooks]);

  const filteredBooks = useMemo(() => {
    const query = bookSearch.trim().toLowerCase();
    return enhancedBooks.filter((book) => {
      const matchesFormat = formatFilter === 'All Formats' || book.format === formatFilter;
      if (!matchesFormat) return false;
      if (!query) return true;

      return (
        book.isbn?.toLowerCase().includes(query) ||
        book.title?.toLowerCase().includes(query) ||
        book.author?.toLowerCase().includes(query) ||
        book.shelfLocation?.toLowerCase().includes(query)
      );
    });
  }, [bookSearch, enhancedBooks, formatFilter]);

  const enhancedIssues = useMemo(() => {
    return issues
      .map((issue) => {
        const book = books.find((entry) => entry.id === issue.bookId);
        const borrower = students.find((student) => student.id === issue.borrowerId);
        const status = getIssueStatus(issue);
        const computedFine = calculateFine(issue);
        return {
          ...issue,
          bookTitle: book?.title || 'Unknown book',
          borrowerName: borrower ? `${borrower.firstName || ''} ${borrower.lastName || ''}`.trim() || borrower.enrollmentNo : issue.borrowerName || 'Unknown borrower',
          borrowerMeta: borrower?.enrollmentNo || borrower?.assignedClass || '',
          status,
          computedFine,
        };
      })
      .sort((a, b) => new Date(b.issueDate || 0) - new Date(a.issueDate || 0));
  }, [books, issues, students]);

  const filteredIssues = useMemo(() => {
    const query = issueSearch.trim().toLowerCase();
    return enhancedIssues.filter((issue) => {
      const matchesStatus = issueStatusFilter === 'All Records' || issue.status === issueStatusFilter;
      if (!matchesStatus) return false;
      if (!query) return true;

      return (
        issue.bookTitle.toLowerCase().includes(query) ||
        issue.borrowerName?.toLowerCase().includes(query) ||
        issue.borrowerMeta?.toLowerCase().includes(query) ||
        issue.issueDate?.toLowerCase().includes(query) ||
        issue.dueDate?.toLowerCase().includes(query)
      );
    });
  }, [enhancedIssues, issueSearch, issueStatusFilter]);

  const totalTitles = books.length;
  const totalStock = books.reduce((sum, book) => sum + (Number(book.availableQuantity) || 0), 0);
  const activeLoans = issues.filter((issue) => !issue.returnDate).length;
  const pendingFines = enhancedIssues.reduce((sum, issue) => sum + (issue.status !== 'Returned' ? issue.computedFine : 0), 0);

  const handleSaveBook = (e) => {
    e.preventDefault();

    const payload = {
      isbn: bookForm.isbn.trim(),
      title: bookForm.title.trim(),
      author: bookForm.author.trim(),
      format: bookForm.format,
      shelfLocation: bookForm.shelfLocation.trim(),
      availableQuantity: Math.max(Number(bookForm.availableQuantity) || 0, 0),
    };

    if (!payload.isbn || !payload.title || !payload.author || !payload.shelfLocation) return;

    db.save('library_books', payload);
    setBookForm(initialBookForm);
    refreshData();
  };

  const handleSaveIssue = (e) => {
    e.preventDefault();

    const selectedBook = books.find((book) => book.id === Number(issueForm.bookId));
    const selectedStudent = students.find((student) => student.id === Number(issueForm.borrowerId));
    if (!selectedBook || !selectedStudent || !issueForm.issueDate || !issueForm.dueDate) return;
    if (issueForm.dueDate < issueForm.issueDate) return;
    if (issueForm.returnDate && issueForm.returnDate < issueForm.issueDate) return;
    if ((Number(selectedBook.availableQuantity) || 0) < 1) return;

    const payload = {
      bookId: selectedBook.id,
      borrowerId: selectedStudent.id,
      borrowerName: `${selectedStudent.firstName || ''} ${selectedStudent.lastName || ''}`.trim(),
      issueDate: issueForm.issueDate,
      dueDate: issueForm.dueDate,
      returnDate: issueForm.returnDate,
      finePerDay: Number(issueForm.finePerDay) || 0,
      damageCharges: Number(issueForm.damageCharges) || 0,
    };

    db.save('library_issues', payload);
    if (!payload.returnDate) {
      updateBookQuantity(selectedBook.id, -1);
    }
    setIssueForm(initialIssueForm);
    refreshData();
  };

  const handleDeleteBook = (bookId) => {
    if (issues.some((issue) => issue.bookId === bookId && !issue.returnDate)) {
      window.alert('Return all active issues before deleting this book.');
      return;
    }

    if (!window.confirm('Delete this book from the library catalog?')) return;
    replaceModuleRecords('library_books', books.filter((book) => book.id !== bookId));
    refreshData();
  };

  const handleDeleteIssue = (issueId) => {
    const issue = issues.find((entry) => entry.id === issueId);
    if (!issue) return;
    if (!window.confirm('Delete this circulation record?')) return;

    if (!issue.returnDate) {
      updateBookQuantity(issue.bookId, 1, false);
    }

    replaceModuleRecords('library_issues', issues.filter((entry) => entry.id !== issueId));
    refreshData();
  };

  const handleMarkReturned = (issueId) => {
    const issue = issues.find((entry) => entry.id === issueId);
    if (!issue || issue.returnDate) return;

    const updatedIssues = issues.map((entry) =>
      entry.id === issueId
        ? {
            ...entry,
            returnDate: today,
          }
        : entry
    );

    replaceModuleRecords('library_issues', updatedIssues);
    updateBookQuantity(issue.bookId, 1, false);
    refreshData();
  };

  const updateBookQuantity = (bookId, delta, shouldRefresh = true) => {
    const updatedBooks = books.map((book) =>
      book.id === bookId
        ? {
            ...book,
            availableQuantity: Math.max((Number(book.availableQuantity) || 0) + delta, 0),
          }
        : book
    );

    replaceModuleRecords('library_books', updatedBooks);
    if (shouldRefresh) refreshData();
  };

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f5fbf7_0%,#eefaf0_32%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Library Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Stacks And Circulation Desk</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#064e3b_0%,#065f46_45%,#0f172a_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(6,78,59,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-200">Library Operations</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Manage inventory, lend books with control, and keep late returns visible.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-emerald-50/80">
                Maintain the master catalog with ISBN and shelf placement, then track who borrowed each title, when it is due, and what fine is building up.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Catalog Titles" value={totalTitles} icon={Library} />
              <MetricCard label="Available Copies" value={totalStock} icon={BookOpen} />
              <MetricCard label="Active Loans" value={activeLoans} icon={BookmarkCheck} />
              <MetricCard label="Running Fines" value={`Rs ${pendingFines}`} icon={IndianRupee} />
            </div>
          </div>
        </section>

        {!activeDesk ? (
          <section className="mt-8 grid gap-5 md:grid-cols-2">
            <LibraryActionCard
              icon={BookPlus}
              title="Add Book"
              description="Add new titles, ISBN, author, shelf location, and available quantity to the library catalog."
              onClick={() => setActiveDesk('books')}
            />
            <LibraryActionCard
              icon={BookmarkCheck}
              title="Issue, Return And Fine"
              description="Issue books to students, mark returns, and review due dates with calculated fine amounts."
              onClick={() => setActiveDesk('circulation')}
            />
          </section>
        ) : (
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-700">
                {activeDesk === 'books' ? 'Add Book Page' : 'Issue Return Fine Page'}
              </p>
              <h2 className="mt-2 font-serif text-3xl font-black italic tracking-tight text-slate-950">
                {activeDesk === 'books' ? 'Book Catalog Entry' : 'Circulation And Fine Desk'}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setActiveDesk(null)}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.18em] text-slate-600 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={15} />
              Back To Cards
            </button>
          </div>
        )}

        {activeDesk ? (
        <div className="mt-8 grid gap-8 xl:grid-cols-[0.92fr_1.08fr]">
          <section className="space-y-8">
            <div className={`${activeDesk === 'books' ? '' : 'hidden'} rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8`}>
              <FormTitle
                title="Book Management"
                description="Catalog physical and digital library assets with the basic details staff needs during shelving, search, and issue."
              />
              <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={handleSaveBook}>
                <CreativeInput
                  label="ISBN"
                  value={bookForm.isbn}
                  onChange={(e) => setBookForm({ ...bookForm, isbn: e.target.value })}
                  placeholder="978-93-XXXXXX"
                />
                <CreativeInput
                  label="Book Title"
                  value={bookForm.title}
                  onChange={(e) => setBookForm({ ...bookForm, title: e.target.value })}
                  placeholder="Database System Concepts"
                />
                <CreativeInput
                  label="Author"
                  value={bookForm.author}
                  onChange={(e) => setBookForm({ ...bookForm, author: e.target.value })}
                  placeholder="Abraham Silberschatz"
                />
                <CreativeSelect
                  label="Asset Format"
                  value={bookForm.format}
                  onChange={(e) => setBookForm({ ...bookForm, format: e.target.value })}
                  options={['Physical', 'Digital']}
                />
                <CreativeInput
                  label="Shelf Location"
                  value={bookForm.shelfLocation}
                  onChange={(e) => setBookForm({ ...bookForm, shelfLocation: e.target.value })}
                  placeholder="Rack B2 / Shelf 4"
                />
                <CreativeInput
                  label="Available Quantity"
                  type="number"
                  min="0"
                  value={bookForm.availableQuantity}
                  onChange={(e) => setBookForm({ ...bookForm, availableQuantity: e.target.value })}
                  placeholder="4"
                />
                <div className="md:col-span-2">
                  <PrimaryButton type="submit" icon={BookPlus} label="Save Book To Catalog" />
                </div>
              </form>
            </div>

            <div className={`${activeDesk === 'circulation' ? '' : 'hidden'} rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8`}>
              <FormTitle
                title="Issue, Return And Fines"
                description="Create lending records with due dates and per-day fines, then close the transaction by marking the book returned."
              />
              <form className="mt-8 grid gap-5 md:grid-cols-2" onSubmit={handleSaveIssue}>
                <CreativeSelect
                  label="Book"
                  value={issueForm.bookId}
                  onChange={(e) => setIssueForm({ ...issueForm, bookId: e.target.value })}
                  options={['', ...bookChoices.map((book) => String(book.id))]}
                  renderOptionLabel={(value) => {
                    if (!value) return 'Select book';
                    const match = bookChoices.find((book) => String(book.id) === value);
                    return match ? `${match.label} | Stock ${match.stock}` : 'Select book';
                  }}
                />
                <CreativeSelect
                  label="Borrower"
                  value={issueForm.borrowerId}
                  onChange={(e) => setIssueForm({ ...issueForm, borrowerId: e.target.value })}
                  options={['', ...studentOptions.map((student) => String(student.id))]}
                  renderOptionLabel={(value) => {
                    if (!value) return 'Select borrower';
                    const match = studentOptions.find((student) => String(student.id) === value);
                    return match ? `${match.label} | ${match.subtitle}` : 'Select borrower';
                  }}
                />
                <CreativeInput
                  label="Issue Date"
                  type="date"
                  value={issueForm.issueDate}
                  onChange={(e) => setIssueForm({ ...issueForm, issueDate: e.target.value })}
                />
                <CreativeInput
                  label="Due Date"
                  type="date"
                  value={issueForm.dueDate}
                  onChange={(e) => setIssueForm({ ...issueForm, dueDate: e.target.value })}
                />
                <CreativeInput
                  label="Return Date"
                  type="date"
                  value={issueForm.returnDate}
                  onChange={(e) => setIssueForm({ ...issueForm, returnDate: e.target.value })}
                />
                <CreativeInput
                  label="Fine Per Day"
                  type="number"
                  min="0"
                  value={issueForm.finePerDay}
                  onChange={(e) => setIssueForm({ ...issueForm, finePerDay: e.target.value })}
                  placeholder="10"
                />
                <div className="md:col-span-2">
                  <CreativeInput
                    label="Damage Charges"
                    type="number"
                    min="0"
                    value={issueForm.damageCharges}
                    onChange={(e) => setIssueForm({ ...issueForm, damageCharges: e.target.value })}
                    placeholder="0"
                  />
                </div>
                <div className="md:col-span-2">
                  <PrimaryButton type="submit" icon={BookmarkCheck} label="Create Circulation Record" />
                </div>
              </form>
            </div>
          </section>

          <section className="space-y-8">
            <div className={`${activeDesk === 'books' ? '' : 'hidden'} rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8`}>
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <FormTitle
                  title="Catalog Register"
                  description="Search by title, ISBN, author, or shelf location to find what the library currently holds."
                />
                <div className="flex flex-col gap-3 md:flex-row md:items-center">
                  <SearchInput value={bookSearch} onChange={setBookSearch} placeholder="Search title, ISBN, author, shelf..." />
                  <CreativeSelect
                    label="Format"
                    value={formatFilter}
                    onChange={(e) => setFormatFilter(e.target.value)}
                    options={['All Formats', 'Physical', 'Digital']}
                  />
                </div>
              </div>

              {filteredBooks.length > 0 ? (
                <div className="mt-8 grid gap-5">
                  {filteredBooks.map((book) => (
                    <article key={book.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
                              <Library size={20} />
                            </div>
                            <div>
                              <h4 className="text-lg font-black tracking-tight text-slate-950">{book.title}</h4>
                              <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">{book.author}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <InfoPill icon={BookOpen} text={`ISBN ${book.isbn}`} />
                            <InfoPill icon={MapPin} text={book.shelfLocation} />
                            <InfoPill icon={Library} text={`${book.format} | ${book.inStock} available`} />
                            <InfoPill icon={BookmarkCheck} text={`${book.activeIssues} active loans`} />
                          </div>
                        </div>

                        <button
                          onClick={() => handleDeleteBook(book.id)}
                          className="inline-flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={Library}
                  title="No books in the catalog"
                  description="Add the first library title with ISBN, location, and stock so issuing can begin."
                />
              )}
            </div>

            <div className={`${activeDesk === 'circulation' ? '' : 'hidden'} rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8`}>
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <FormTitle
                  title="Circulation Ledger"
                  description="See open loans, overdue returns, and the calculated fine amount for each borrowing record."
                />
                <div className="flex flex-col gap-3 md:flex-row md:items-center">
                  <SearchInput value={issueSearch} onChange={setIssueSearch} placeholder="Search borrower, book, date..." />
                  <CreativeSelect
                    label="Status"
                    value={issueStatusFilter}
                    onChange={(e) => setIssueStatusFilter(e.target.value)}
                    options={['All Records', 'Issued', 'Overdue', 'Returned']}
                  />
                </div>
              </div>

              {filteredIssues.length > 0 ? (
                <div className="mt-8 grid gap-5">
                  {filteredIssues.map((issue) => (
                    <article key={issue.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${getStatusBadgeClass(issue.status, true)}`}>
                              {issue.status === 'Overdue' ? <AlertCircle size={20} /> : <CalendarClock size={20} />}
                            </div>
                            <div>
                              <h4 className="text-lg font-black tracking-tight text-slate-950">{issue.bookTitle}</h4>
                              <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">{issue.borrowerName || 'Borrower pending'}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <InfoPill icon={UserRound} text={issue.borrowerMeta || 'Student record'} />
                            <InfoPill icon={CalendarClock} text={`Issue ${issue.issueDate || '-'}`} />
                            <InfoPill icon={CalendarClock} text={`Due ${issue.dueDate || '-'}`} />
                            <InfoPill icon={CalendarClock} text={`Return ${issue.returnDate || 'Pending'}`} />
                            <InfoPill icon={IndianRupee} text={`Fine Rs ${issue.computedFine}`} />
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className={`rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] ${getStatusBadgeClass(issue.status)}`}>
                            {issue.status}
                          </span>
                          {!issue.returnDate ? (
                            <button
                              onClick={() => handleMarkReturned(issue.id)}
                              className="inline-flex rounded-2xl bg-slate-950 px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-white transition hover:bg-emerald-600"
                            >
                              Mark Returned
                            </button>
                          ) : null}
                          <button
                            onClick={() => handleDeleteIssue(issue.id)}
                            className="inline-flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={BookmarkCheck}
                  title="No circulation records yet"
                  description="Create the first issue entry to track due dates, returns, and automatic fine amounts."
                />
              )}
            </div>
          </section>
        </div>
        ) : null}
      </div>
    </div>
  );
};

const replaceModuleRecords = (module, records) => {
  const tenantId = db.getTenantId();
  if (!tenantId) return;
  localStorage.setItem(`${tenantId}_${module}`, JSON.stringify(records));
};

const getIssueStatus = (issue) => {
  if (issue.returnDate) return 'Returned';
  if (!issue.dueDate) return 'Issued';
  const due = new Date(issue.dueDate);
  const current = new Date(today);
  return due < current ? 'Overdue' : 'Issued';
};

const calculateFine = (issue) => {
  if (!issue.dueDate) return Number(issue.damageCharges) || 0;

  const endDate = issue.returnDate || today;
  const dueDate = new Date(issue.dueDate);
  const targetDate = new Date(endDate);
  const diffDays = Math.max(Math.ceil((targetDate - dueDate) / (1000 * 60 * 60 * 24)), 0);
  return diffDays * (Number(issue.finePerDay) || 0) + (Number(issue.damageCharges) || 0);
};

const getStatusBadgeClass = (status, filled = false) => {
  if (status === 'Overdue') {
    return filled
      ? 'bg-rose-100 text-rose-700'
      : 'border border-rose-200 bg-rose-50 text-rose-700';
  }
  if (status === 'Returned') {
    return filled
      ? 'bg-emerald-100 text-emerald-700'
      : 'border border-emerald-200 bg-emerald-50 text-emerald-700';
  }
  return filled
    ? 'bg-amber-100 text-amber-700'
    : 'border border-amber-200 bg-amber-50 text-amber-700';
};

const LibraryActionCard = ({ icon: Icon, title, description, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="group flex min-h-52 flex-col justify-between rounded-4xl border border-slate-200/80 bg-white p-6 text-left shadow-[0_20px_60px_-38px_rgba(15,23,42,0.45)] transition hover:-translate-y-1 hover:border-emerald-300 hover:shadow-[0_26px_70px_-42px_rgba(6,95,70,0.65)] lg:p-8"
  >
    <div>
      <div className="flex items-start justify-between gap-5">
        <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-emerald-100 text-emerald-700 transition group-hover:bg-emerald-600 group-hover:text-white">
          <Icon size={24} />
        </div>
        <div className="flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 text-slate-400 transition group-hover:border-emerald-200 group-hover:text-emerald-700">
          <ArrowRight size={18} />
        </div>
      </div>
      <h3 className="mt-7 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
      <p className="mt-3 text-sm leading-7 text-slate-500">{description}</p>
    </div>
    <span className="mt-6 text-[11px] font-black uppercase tracking-[0.22em] text-emerald-700">
      Open Page
    </span>
  </button>
);

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-50/80">{label}</p>
        <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-200/20 bg-emerald-200/10 text-emerald-50">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const FormTitle = ({ title, description }) => (
  <div>
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative min-w-65">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
    />
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, renderOptionLabel, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option || 'empty-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option || 'Select'}
        </option>
      ))}
    </select>
  </div>
);

const PrimaryButton = ({ type, icon: Icon, label }) => (
  <button
    type={type}
    className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-600"
  >
    <Icon size={15} />
    {label}
  </button>
);

const InfoPill = ({ icon: Icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    <Icon size={15} className="text-emerald-700" />
    <span>{text}</span>
  </div>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <Icon size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

export default LibraryManagement;
