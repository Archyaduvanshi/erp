import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  Banknote,
  Briefcase,
  CalendarCheck2,
  CheckCircle2,
  FileText,
  IdCard,
  LayoutGrid,
  List,
  Mail,
  Phone,
  Plus,
  QrCode,
  Search,
  ShieldCheck,
  Trash2,
  Upload,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';
import { formatSalary } from '../../utils/salaryUtils';

const initialFormData = {
  firstName: '',
  lastName: '',
  personalEmail: '',
  mobileNumber: '',
  employeeId: '',
  assignedClass: '',
  specialization: '',
  experienceYears: '',
  contractType: 'Full Time',
  leaveBalance: '',
  salary: '',
  joiningDate: '',
  teacherPortalPassword: '',
  documentType: '',
  otherDocumentName: '',
  fileUploadPath: '',
  documents: [],
  qrCodeData: '',
  cardExpiryDate: '',
  photoUrl: '',
};

const TeacherManagement = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('list');
  const [currentStep, setCurrentStep] = useState(1);
  const [teachers, setTeachers] = useState(() => db.getAll('teachers'));
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [contractFilter, setContractFilter] = useState('All Contracts');
  const [formData, setFormData] = useState(initialFormData);

  const refreshTeachers = () => {
    setTeachers(db.getAll('teachers'));
  };

  const draftTeacherId = formData.employeeId ? `TCH-${formData.employeeId}` : 'TCH-AUTO-ID';
  const draftQrCodeData = formData.qrCodeData || `${draftTeacherId}-${formData.mobileNumber || 'QR-PENDING'}`;

  const handleDocumentAdd = () => {
    const resolvedDocumentType = formData.documentType === 'Other' ? formData.otherDocumentName.trim() : formData.documentType;
    if (!resolvedDocumentType || !formData.fileUploadPath.trim()) return;

    const nextDocument = {
      id: Date.now(),
      documentType: resolvedDocumentType,
      fileUploadPath: formData.fileUploadPath,
    };

    setFormData({
      ...formData,
      documents: [...formData.documents, nextDocument],
      documentType: '',
      otherDocumentName: '',
      fileUploadPath: '',
    });
  };

  const handleDocumentRemove = (documentId) => {
    setFormData({
      ...formData,
      documents: formData.documents.filter((document) => document.id !== documentId),
    });
  };

  const handleDocumentBrowse = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFormData({
      ...formData,
      fileUploadPath: file.name,
    });
  };

  const handleSave = (e) => {
    e.preventDefault();

    const resolvedTeacherId = formData.employeeId ? `TCH-${formData.employeeId}` : `TCH-${Math.floor(1000 + Math.random() * 9000)}`;
    const resolvedQrCodeData = formData.qrCodeData || `${resolvedTeacherId}-${formData.mobileNumber || 'FACULTY'}`;
    const resolvedPortalPassword = formData.teacherPortalPassword.trim() || (formData.mobileNumber ? formData.mobileNumber.replace(/\s+/g, '').slice(-6) : resolvedTeacherId.slice(-6));

    const newTeacher = {
      ...formData,
      salary: formData.salary ? Number(formData.salary) : '',
      joiningDate: formData.joiningDate || new Date().toISOString().slice(0, 10),
      paymentHistory: [],
      teacherPortalPassword: resolvedPortalPassword,
      teacherSystemId: resolvedTeacherId,
      qrCodeData: resolvedQrCodeData,
      status: 'Active',
      attendanceStatus: 'Present',
      createdAt: new Date().toISOString(),
    };

    db.save('teachers', newTeacher);
    refreshTeachers();
    setFormData(initialFormData);
    setActiveTab('list');
    setCurrentStep(1);
  };

  const handleDelete = (teacherId) => {
    const tenantId = db.getTenantId();
    if (!tenantId) return;

    const shouldDelete = window.confirm('Delete this teacher record?');
    if (!shouldDelete) return;

    const key = `${tenantId}_teachers`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    const updated = existing.filter((teacher) => teacher.id !== teacherId);
    localStorage.setItem(key, JSON.stringify(updated));
    setTeachers(updated);
  };

  const availableContracts = ['All Contracts', ...new Set(teachers.map((teacher) => teacher.contractType).filter(Boolean))];
  const filteredTeachers = teachers.filter((teacher) => {
    const fullName = `${teacher.firstName} ${teacher.lastName}`.toLowerCase();
    const searchValue = searchTerm.toLowerCase();
    const matchesSearch =
      !searchValue ||
      fullName.includes(searchValue) ||
      teacher.personalEmail?.toLowerCase().includes(searchValue) ||
      teacher.employeeId?.toLowerCase().includes(searchValue) ||
      teacher.assignedClass?.toLowerCase().includes(searchValue) ||
      teacher.specialization?.toLowerCase().includes(searchValue) ||
      teacher.teacherSystemId?.toLowerCase().includes(searchValue);
    const matchesContract = contractFilter === 'All Contracts' || teacher.contractType === contractFilter;
    return matchesSearch && matchesContract;
  });

  const activeTeachers = teachers.filter((teacher) => teacher.status === 'Active').length;
  const fullTimeTeachers = teachers.filter((teacher) => teacher.contractType === 'Full Time').length;
  const uploadedDocs = teachers.reduce((count, teacher) => count + (teacher.documents || []).length, 0);

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f6f8fc_0%,#eef8f5_55%,#fbfcfe_100%)] text-slate-900 selection:bg-emerald-400 selection:text-slate-950">
      <div className="border-b border-slate-200/70 bg-white/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/college')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Teacher Management</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Faculty Operations Hub</h1>
            </div>
          </div>

          <button
            onClick={() => {
              setActiveTab(activeTab === 'list' ? 'add' : 'list');
              setCurrentStep(1);
            }}
            className={`inline-flex items-center gap-2 rounded-full px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] transition ${
              activeTab === 'list'
                ? 'bg-slate-950 text-white shadow-lg shadow-slate-300 hover:bg-emerald-600'
                : 'border border-slate-200 bg-white text-slate-600 hover:border-rose-200 hover:text-rose-600'
            }`}
          >
            {activeTab === 'list' ? <Plus size={14} /> : <X size={14} />}
            {activeTab === 'list' ? 'Add Teacher' : 'Close Form'}
          </button>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        {activeTab === 'list' ? (
          <DirectoryView
            teachers={teachers}
            filteredTeachers={filteredTeachers}
            activeTeachers={activeTeachers}
            fullTimeTeachers={fullTimeTeachers}
            uploadedDocs={uploadedDocs}
            viewMode={viewMode}
            setViewMode={setViewMode}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            contractFilter={contractFilter}
            setContractFilter={setContractFilter}
            availableContracts={availableContracts}
            onCreate={() => setActiveTab('add')}
            onOpenSalaryDesk={() => navigate('/college/salary')}
            onDelete={handleDelete}
          />
        ) : (
          <TeacherWizard
            currentStep={currentStep}
            setCurrentStep={setCurrentStep}
            formData={formData}
            setFormData={setFormData}
            handleSave={handleSave}
            draftTeacherId={draftTeacherId}
            draftQrCodeData={draftQrCodeData}
            handleDocumentAdd={handleDocumentAdd}
            handleDocumentRemove={handleDocumentRemove}
            handleDocumentBrowse={handleDocumentBrowse}
          />
        )}
      </div>
    </div>
  );
};

const DirectoryView = ({
  teachers,
  filteredTeachers,
  activeTeachers,
  fullTimeTeachers,
  uploadedDocs,
  viewMode,
  setViewMode,
  searchTerm,
  setSearchTerm,
  contractFilter,
  setContractFilter,
  availableContracts,
  onCreate,
  onOpenSalaryDesk,
  onDelete,
}) => (
  <div className="space-y-8">
    <section className="overflow-hidden rounded-4xl border border-slate-200/80 bg-slate-950 text-white shadow-[0_30px_80px_-40px_rgba(15,23,42,0.9)]">
      <div className="grid gap-8 px-7 py-8 lg:grid-cols-[1.5fr_0.9fr] lg:px-10 lg:py-10">
        <div className="relative">
          <div className="absolute -left-16 -top-16 h-40 w-40 rounded-full bg-emerald-400/15 blur-3xl" />
          <div className="absolute bottom-0 right-10 h-32 w-32 rounded-full bg-teal-500/10 blur-3xl" />
          <div className="relative">
            <p className="mb-3 text-[11px] font-black uppercase tracking-[0.32em] text-emerald-300">HR Control Center</p>
            <h2 className="max-w-2xl font-serif text-4xl font-black italic leading-none tracking-tight">
              Faculty records, document readiness, and ID generation from one focused workspace.
            </h2>
            <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-300">
              Keep teacher profiles current, monitor attendance posture, verify documents, and issue auto-ready ID cards with QR data.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={onCreate}
                className="inline-flex items-center gap-2 rounded-full bg-emerald-400 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-950 transition hover:bg-emerald-300"
              >
                <UserPlus size={14} />
                Add Faculty Record
              </button>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-300">
                <ShieldCheck size={14} />
                {uploadedDocs} documents uploaded
              </div>
              <button
                onClick={onOpenSalaryDesk}
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-300 transition hover:border-emerald-300 hover:text-emerald-200"
              >
                <Banknote size={14} />
                Open Salary Desk
              </button>
            </div>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
          <StatCard label="Total Faculty" value={teachers.length} tone="emerald" icon={Users} />
          <StatCard label="Active Teachers" value={activeTeachers} tone="cyan" icon={CalendarCheck2} />
          <StatCard label="Full Time" value={fullTimeTeachers} tone="amber" icon={Briefcase} />
        </div>
      </div>
    </section>

    <section className="rounded-4xl border border-slate-200/80 bg-white p-5 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Faculty Directory</h3>
          <p className="mt-1 text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">
            {filteredTeachers.length} of {teachers.length} records visible
          </p>
        </div>

        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative min-w-65">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search name, email, employee ID..."
              className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
            />
          </div>

          <select
            value={contractFilter}
            onChange={(e) => setContractFilter(e.target.value)}
            className="rounded-2xl border-2 border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-700 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
          >
            {availableContracts.map((contract) => (
              <option key={contract} value={contract}>
                {contract}
              </option>
            ))}
          </select>

          <div className="inline-flex rounded-2xl border border-slate-200 bg-slate-50 p-1.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`rounded-xl p-2.5 transition ${viewMode === 'grid' ? 'bg-slate-950 text-white' : 'text-slate-400 hover:bg-white'}`}
            >
              <LayoutGrid size={18} />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`rounded-xl p-2.5 transition ${viewMode === 'table' ? 'bg-slate-950 text-white' : 'text-slate-400 hover:bg-white'}`}
            >
              <List size={18} />
            </button>
          </div>
        </div>
      </div>

      {filteredTeachers.length > 0 ? (
        viewMode === 'grid' ? (
          <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {filteredTeachers.map((teacher) => (
              <TeacherCard key={teacher.id} teacher={teacher} onDelete={onDelete} />
            ))}
          </div>
        ) : (
          <div className="mt-6 overflow-hidden rounded-[1.75rem] border border-slate-200">
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-white">
                <tr className="text-[11px] font-black uppercase tracking-[0.24em]">
                  <th className="px-6 py-4">Teacher</th>
                  <th className="px-6 py-4">Employee ID</th>
                  <th className="px-6 py-4">Specialization</th>
                  <th className="px-6 py-4">Salary</th>
                  <th className="px-6 py-4">Contract</th>
                  <th className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                {filteredTeachers.map((teacher) => (
                  <tr key={teacher.id} className="transition hover:bg-emerald-50/60">
                    <td className="px-6 py-5">
                      <p className="text-sm font-black text-slate-950">{teacher.firstName} {teacher.lastName}</p>
                      <p className="mt-1 text-xs font-semibold text-slate-500">{teacher.personalEmail || teacher.mobileNumber || 'Not provided'}</p>
                    </td>
                    <td className="px-6 py-5 text-sm font-semibold text-slate-700">{teacher.employeeId || 'Pending'}</td>
                    <td className="px-6 py-5 text-sm font-semibold text-slate-700">{teacher.specialization || teacher.assignedClass || 'Not assigned'}</td>
                    <td className="px-6 py-5 text-sm font-semibold text-slate-700">{formatSalary(teacher.salary)}</td>
                    <td className="px-6 py-5">
                      <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-700">
                        {teacher.contractType || 'Full Time'}
                      </span>
                    </td>
                    <td className="px-6 py-5 text-right">
                      <button
                        onClick={() => onDelete(teacher.id)}
                        className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      ) : (
        <div className="mt-6 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
            <Users size={34} />
          </div>
          <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No faculty records yet</h4>
          <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">
            Create the first teacher profile to start attendance, document verification, and automatic ID card generation.
          </p>
          <button
            onClick={onCreate}
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-slate-950 px-5 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-white transition hover:bg-emerald-600"
          >
            <Plus size={14} />
            Create Teacher
          </button>
        </div>
      )}
    </section>
  </div>
);

const TeacherWizard = ({
  currentStep,
  setCurrentStep,
  formData,
  setFormData,
  handleSave,
  draftTeacherId,
  draftQrCodeData,
  handleDocumentAdd,
  handleDocumentRemove,
  handleDocumentBrowse,
}) => (
  <div className="grid items-start gap-8 xl:grid-cols-[0.78fr_1.22fr]">
    <aside className="space-y-6 xl:sticky xl:top-8">
      <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)]">
        <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-600">Teacher Module</p>
        <div className="mt-6 space-y-5">
          <TimelineStep step={1} current={currentStep} title="Profiles" desc="Professional identity and records" />
          <TimelineStep step={2} current={currentStep} title="Attendance" desc="Contract and leave posture" />
          <TimelineStep step={3} current={currentStep} title="Documents" desc="Verification and file locker" />
          <TimelineStep step={4} current={currentStep} title="ID Generation" desc="Auto ID card and QR" />
        </div>
      </section>

      <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#064e3b_0%,#0f172a_58%,#020617_100%)] p-6 text-white shadow-[0_30px_80px_-40px_rgba(6,78,59,0.8)]">
        <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-300">Faculty Snapshot</p>
        <div className="mt-6 rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
          <div className="flex items-start justify-between">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/10 text-lg font-black uppercase text-emerald-100">
              {(formData.firstName?.[0] || 'T') + (formData.lastName?.[0] || 'R')}
            </div>
            <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-200">
              {formData.contractType || 'Full Time'}
            </span>
          </div>
          <h3 className="mt-8 font-serif text-3xl font-black italic tracking-tight">
            {formData.firstName || 'New'} {formData.lastName || 'Teacher'}
          </h3>
          <p className="mt-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-300">
            {formData.specialization || 'Specialization pending'}
          </p>
          <div className="mt-8 space-y-3 text-sm text-slate-300">
            <PreviewRow icon={Briefcase} value={formData.employeeId || 'Employee ID pending'} />
            <PreviewRow icon={CalendarCheck2} value={`Leave Balance: ${formData.leaveBalance || '0'} days`} />
            <PreviewRow icon={Banknote} value={`Salary: ${formatSalary(formData.salary)}`} />
            <PreviewRow icon={FileText} value={`${formData.documents.length} document(s) added`} />
            <PreviewRow icon={QrCode} value={draftQrCodeData} />
          </div>
        </div>
      </section>
    </aside>

    <section className="rounded-[2.25rem] border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
      {currentStep === 1 && (
        <div>
          <FormHeader
            eyebrow="Step 01"
            title="Teacher profiles"
            desc="Create a faculty record with identity and professional information used by the HR module."
          />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="First Name" value={formData.firstName} onChange={(e) => setFormData({ ...formData, firstName: e.target.value })} placeholder="Teacher first name" />
            <CreativeInput label="Last Name" value={formData.lastName} onChange={(e) => setFormData({ ...formData, lastName: e.target.value })} placeholder="Teacher last name" />
            <CreativeInput label="Personal Email" type="email" value={formData.personalEmail} onChange={(e) => setFormData({ ...formData, personalEmail: e.target.value })} placeholder="teacher@email.com" />
            <CreativeInput label="Mobile Number" value={formData.mobileNumber} onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })} placeholder="+91 98XXX XXXXX" />
            <CreativeInput label="Employee ID" value={formData.employeeId} onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })} placeholder="EMP-1024" />
            <CreativeInput label="Assigned Class" value={formData.assignedClass} onChange={(e) => setFormData({ ...formData, assignedClass: e.target.value })} placeholder="Class 8 / A or BCA Semester 1" />
            <CreativeInput label="Specialization" value={formData.specialization} onChange={(e) => setFormData({ ...formData, specialization: e.target.value })} placeholder="Mathematics / Physics / English" />
          </div>
          <WizardButtons label="Continue to Attendance" onNext={() => setCurrentStep(2)} />
        </div>
      )}

      {currentStep === 2 && (
        <div>
          <FormHeader
            eyebrow="Step 02"
            title="Teacher work and salary posture"
            desc="Store the working profile that helps the institution manage contracts, tenure, leave, and monthly salary from the date the teacher starts teaching."
          />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="Experience Years" type="number" value={formData.experienceYears} onChange={(e) => setFormData({ ...formData, experienceYears: e.target.value })} placeholder="6" />
            <CreativeSelect
              label="Contract Type"
              value={formData.contractType}
              onChange={(e) => setFormData({ ...formData, contractType: e.target.value })}
              options={['Full Time', 'Part Time', 'Visiting', 'Contractual']}
            />
            <CreativeInput label="Leave Balance" type="number" value={formData.leaveBalance} onChange={(e) => setFormData({ ...formData, leaveBalance: e.target.value })} placeholder="12" />
            <CreativeInput label="Monthly Salary" type="number" min="0" value={formData.salary} onChange={(e) => setFormData({ ...formData, salary: e.target.value })} placeholder="35000" />
            <CreativeInput label="Teaching Start Date" type="date" value={formData.joiningDate} onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })} />
            <CreativeInput label="Teacher Portal Password" type="password" value={formData.teacherPortalPassword} onChange={(e) => setFormData({ ...formData, teacherPortalPassword: e.target.value })} placeholder="Set login password for teacher" />
          </div>
          <WizardButtons label="Continue to Documents" onNext={() => setCurrentStep(3)} onBack={() => setCurrentStep(1)} />
        </div>
      )}

      {currentStep === 3 && (
        <div>
          <FormHeader
            eyebrow="Step 03"
            title="Teacher documents"
            desc="Add documents one by one, submit each into the faculty locker, and continue after the required files are listed below."
          />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeSelect
              label="Document Type"
              value={formData.documentType}
              onChange={(e) => setFormData({ ...formData, documentType: e.target.value })}
              options={['Select', 'Aadhar', 'Resume', 'Experience Certificate', 'Qualification Certificate', 'Other']}
            />
            {formData.documentType === 'Other' && (
              <CreativeInput
                label="Document Name"
                value={formData.otherDocumentName}
                onChange={(e) => setFormData({ ...formData, otherDocumentName: e.target.value })}
                placeholder="Enter document name"
              />
            )}
            <DocumentUploadField
              label="File Upload"
              value={formData.fileUploadPath}
              onBrowse={handleDocumentBrowse}
            />
          </div>

          <div className="mt-5 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={handleDocumentAdd}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.18em] text-white transition hover:bg-emerald-600"
            >
              <Plus size={14} />
              Submit Document
            </button>
          </div>

          <div className="mt-8 rounded-[1.75rem] border border-slate-200 bg-slate-50 p-5">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">Submitted Documents</p>
                <p className="mt-2 text-sm font-semibold text-slate-700">{formData.documents.length} document(s) added</p>
              </div>
              <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-700">
                Multi-document ready
              </span>
            </div>

            {formData.documents.length > 0 ? (
              <div className="mt-5 grid gap-4 md:grid-cols-2">
                {formData.documents.map((document) => (
                  <div key={document.id} className="rounded-[1.4rem] border border-slate-200 bg-white p-4 shadow-sm">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-black text-slate-950">{document.documentType}</p>
                        <p className="mt-1 break-all text-xs font-semibold text-slate-500">{document.fileUploadPath}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDocumentRemove(document.id)}
                        className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <div className="mt-4 rounded-xl bg-slate-50 px-3 py-2 text-[11px] font-semibold text-slate-500">
                      Ready for teacher record
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-5 rounded-[1.4rem] border border-dashed border-slate-300 bg-white px-5 py-8 text-center text-sm font-medium text-slate-500">
                No documents submitted yet. Add each required file, then continue to ID generation.
              </div>
            )}
          </div>

          <WizardButtons
            label="Continue to ID Generation"
            onNext={() => {
              if (formData.documents.length > 0) setCurrentStep(4);
            }}
            onBack={() => setCurrentStep(2)}
            isDisabled={formData.documents.length === 0}
          />
        </div>
      )}

      {currentStep === 4 && (
        <div>
          <FormHeader
            eyebrow="Step 04"
            title="Automatic ID generation"
            desc="Generate the faculty ID card automatically with QR data and finalize the teacher record."
          />
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <CreativeInput label="System-generated Teacher ID" value={draftTeacherId} readOnly />
            <CreativeInput label="QR Code Data" value={formData.qrCodeData} onChange={(e) => setFormData({ ...formData, qrCodeData: e.target.value })} placeholder={draftQrCodeData} />
            <CreativeInput label="Card Expiry Date" type="date" value={formData.cardExpiryDate} onChange={(e) => setFormData({ ...formData, cardExpiryDate: e.target.value })} />
            <CreativeInput label="Photo URL" value={formData.photoUrl} onChange={(e) => setFormData({ ...formData, photoUrl: e.target.value })} placeholder="https://cdn.example.com/faculty-photo.jpg" />
          </div>

          <div className="mt-8 rounded-4xl border border-slate-200 bg-[linear-gradient(135deg,#ecfdf5_0%,#f8fafc_100%)] p-6 shadow-sm">
            <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-700">Auto-generated ID Card</p>
            <div className="mt-5 grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
              <div className="rounded-[1.6rem] bg-slate-950 p-6 text-white">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.24em] text-emerald-300">Faculty ID Card</p>
                    <h3 className="mt-3 font-serif text-3xl font-black italic">
                      {formData.firstName || 'New'} {formData.lastName || 'Teacher'}
                    </h3>
                    <p className="mt-2 text-[11px] font-black uppercase tracking-[0.2em] text-slate-300">
                      {formData.specialization || 'Specialization pending'}
                    </p>
                  </div>
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-white/10 text-lg font-black uppercase text-emerald-100">
                    {(formData.firstName?.[0] || 'T') + (formData.lastName?.[0] || 'R')}
                  </div>
                </div>
                <div className="mt-8 grid gap-3 text-sm text-slate-300">
                  <PreviewRow icon={IdCard} value={draftTeacherId} />
                  <PreviewRow icon={Mail} value={formData.personalEmail || 'Email not added'} />
                  <PreviewRow icon={Phone} value={formData.mobileNumber || 'Mobile not added'} />
                  <PreviewRow icon={CalendarCheck2} value={formData.cardExpiryDate || 'Expiry date pending'} />
                </div>
              </div>

              <div className="rounded-[1.6rem] border border-slate-200 bg-white p-6 text-center">
                <div className="mx-auto flex h-28 w-28 items-center justify-center rounded-3xl bg-slate-950 text-emerald-300">
                  <QrCode size={58} />
                </div>
                <p className="mt-5 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500">QR Payload</p>
                <p className="mt-3 break-all text-sm font-semibold text-slate-800">{formData.qrCodeData || draftQrCodeData}</p>
              </div>
            </div>
          </div>

          <div className="mt-8 grid gap-4 lg:grid-cols-2">
            <ReviewCard title="Teacher Profile">
              <ReviewLine label="Name" value={`${formData.firstName || '-'} ${formData.lastName || ''}`.trim()} />
              <ReviewLine label="Employee ID" value={formData.employeeId || '-'} />
              <ReviewLine label="Assigned Class" value={formData.assignedClass || '-'} />
              <ReviewLine label="Specialization" value={formData.specialization || '-'} />
              <ReviewLine label="Experience" value={formData.experienceYears ? `${formData.experienceYears} years` : '-'} />
            </ReviewCard>

            <ReviewCard title="Attendance & Identity">
              <ReviewLine label="Contract" value={formData.contractType || '-'} />
              <ReviewLine label="Leave Balance" value={formData.leaveBalance ? `${formData.leaveBalance} days` : '-'} />
              <ReviewLine label="Monthly Salary" value={formatSalary(formData.salary)} />
              <ReviewLine label="Teaching Start" value={formData.joiningDate || '-'} />
              <ReviewLine label="Teacher ID" value={draftTeacherId} />
              <ReviewLine label="Portal Password" value={formData.teacherPortalPassword || '-'} />
              <ReviewLine label="QR Data" value={formData.qrCodeData || draftQrCodeData} />
            </ReviewCard>

            <ReviewCard title="Documents">
              <ReviewLine label="Total Documents" value={String(formData.documents.length)} />
              <ReviewLine label="Latest Document" value={formData.documents[formData.documents.length - 1]?.documentType || '-'} />
              <ReviewLine label="Latest File" value={formData.documents[formData.documents.length - 1]?.fileUploadPath || '-'} />
              <ReviewLine label="Upload Ready" value={formData.documents.length > 0 ? 'Yes' : 'No'} />
            </ReviewCard>
          </div>

          <WizardButtons label="Save Teacher Record" onNext={handleSave} onBack={() => setCurrentStep(3)} isFinal />
        </div>
      )}
    </section>
  </div>
);

const StatCard = ({ label, value, tone, icon }) => {
  const toneClasses = {
    emerald: 'border-emerald-400/20 bg-emerald-400/10 text-emerald-100',
    cyan: 'border-cyan-400/20 bg-cyan-400/10 text-cyan-100',
    amber: 'border-amber-400/20 bg-amber-400/10 text-amber-100',
  };

  return (
    <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-300">{label}</p>
          <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
        </div>
        <div className={`flex h-12 w-12 items-center justify-center rounded-2xl border ${toneClasses[tone]}`}>
          {React.createElement(icon, { size: 20 })}
        </div>
      </div>
    </div>
  );
};

const TeacherCard = ({ teacher, onDelete }) => (
  <article className="group overflow-hidden rounded-[1.9rem] border border-slate-200/80 bg-white p-6 shadow-[0_16px_40px_-28px_rgba(15,23,42,0.35)] transition hover:-translate-y-1 hover:shadow-[0_24px_50px_-28px_rgba(16,185,129,0.35)]">
    <div className="flex items-start justify-between">
      <div className="flex items-center gap-4">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#d1fae5_0%,#ccfbf1_100%)] text-lg font-black uppercase text-slate-900">
          {(teacher.firstName?.[0] || 'T') + (teacher.lastName?.[0] || 'R')}
        </div>
        <div>
          <h4 className="text-lg font-black tracking-tight text-slate-950">{teacher.firstName} {teacher.lastName}</h4>
          <p className="mt-1 text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">{teacher.specialization || 'General Faculty'}</p>
        </div>
      </div>

      <button
        onClick={() => onDelete(teacher.id)}
        className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
      >
        <Trash2 size={16} />
      </button>
    </div>

    <div className="mt-6 grid gap-3 text-sm text-slate-600">
      <PreviewRow icon={Mail} value={teacher.personalEmail || 'No email added'} light />
      <PreviewRow icon={Phone} value={teacher.mobileNumber || 'No phone added'} light />
      <PreviewRow icon={Briefcase} value={teacher.employeeId || 'Employee ID pending'} light />
      <PreviewRow icon={Banknote} value={`Salary: ${formatSalary(teacher.salary)}`} light />
      <PreviewRow icon={ShieldCheck} value={`Portal password: ${teacher.teacherPortalPassword || 'Not set'}`} light />
    </div>

    <div className="mt-6 flex items-center justify-between border-t border-slate-200 pt-4">
      <div>
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Teacher ID</p>
        <p className="mt-1 text-sm font-semibold text-slate-700">{teacher.teacherSystemId || 'Auto pending'}</p>
      </div>
      <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-700">
        {teacher.contractType || 'Full Time'}
      </span>
    </div>
  </article>
);

const TimelineStep = ({ step, current, title, desc }) => (
  <div className={`flex gap-4 transition ${current >= step ? 'opacity-100' : 'opacity-45'}`}>
    <div
      className={`mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border-2 text-sm font-black transition ${
        current === step
          ? 'border-emerald-500 bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-100'
          : current > step
            ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
            : 'border-slate-200 bg-slate-50 text-slate-400'
      }`}
    >
      {current > step ? <CheckCircle2 size={18} /> : step}
    </div>
    <div>
      <p className="text-sm font-black text-slate-950">{title}</p>
      <p className="mt-1 text-sm leading-6 text-slate-500">{desc}</p>
    </div>
  </div>
);

const FormHeader = ({ eyebrow, title, desc }) => (
  <div>
    <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-600">{eyebrow}</p>
    <h2 className="mt-3 font-serif text-4xl font-black italic leading-none tracking-tight text-slate-950">{title}</h2>
    <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-500">{desc}</p>
  </div>
);

const CreativeInput = ({ label, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <input
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    />
  </div>
);

const CreativeSelect = ({ label, options, ...props }) => (
  <div className="space-y-2.5">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <select
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
      {...props}
    >
      {options.map((option) => (
        <option key={option} value={option === 'Select' ? '' : option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);

const DocumentUploadField = ({ label, value, onBrowse }) => (
  <div className="space-y-2.5 md:col-span-2">
    <label className="text-xs font-black uppercase tracking-[0.18em] text-slate-700">{label}</label>
    <label className="flex w-full cursor-pointer items-center justify-between gap-4 rounded-2xl border-2 border-slate-200 bg-slate-50 px-5 py-4 text-sm font-semibold text-slate-700 transition hover:border-emerald-300 hover:bg-white">
      <div className="min-w-0">
        <p className={`truncate ${value ? 'text-slate-900' : 'text-slate-400'}`}>
          {value || 'Click anywhere in this field to browse and select a file'}
        </p>
      </div>
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-950 text-white">
        <Upload size={18} />
      </div>
      <input type="file" className="hidden" onChange={onBrowse} />
    </label>
  </div>
);

const WizardButtons = ({ label, onNext, onBack, isFinal, isDisabled = false }) => (
  <div className="mt-10 flex flex-col gap-3 border-t border-slate-200 pt-6 sm:flex-row">
    {onBack && (
      <button
        type="button"
        onClick={onBack}
        className="inline-flex flex-1 items-center justify-center rounded-2xl border-2 border-slate-200 bg-white px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
      >
        Back
      </button>
    )}
    <button
      type="button"
      onClick={onNext}
      disabled={isDisabled}
      className={`inline-flex flex-[1.5] items-center justify-center gap-2 rounded-2xl px-5 py-3.5 text-[11px] font-black uppercase tracking-[0.2em] transition ${
        isDisabled
          ? 'cursor-not-allowed bg-slate-200 text-slate-400'
          :
        isFinal
          ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100 hover:bg-emerald-700'
          : 'bg-slate-950 text-white shadow-lg shadow-slate-300 hover:bg-emerald-600'
      }`}
    >
      {label}
      <ArrowRight size={14} />
    </button>
  </div>
);

const PreviewRow = ({ icon, value, light = false }) => (
  <div className={`flex items-center gap-3 rounded-2xl px-3 py-2 ${light ? 'bg-slate-50 text-slate-600' : 'bg-white/5 text-slate-200'}`}>
    {React.createElement(icon, { size: 15, className: light ? 'text-emerald-700' : 'text-emerald-300' })}
    <span className="truncate text-sm font-medium">{value}</span>
  </div>
);

const ReviewCard = ({ title, children }) => (
  <div className="rounded-[1.75rem] border border-slate-200 bg-slate-50 p-5">
    <p className="text-[11px] font-black uppercase tracking-[0.24em] text-slate-500">{title}</p>
    <div className="mt-4 space-y-3">{children}</div>
  </div>
);

const ReviewLine = ({ label, value }) => (
  <div className="flex items-start justify-between gap-4 border-b border-slate-200/80 pb-3 last:border-b-0 last:pb-0">
    <span className="text-xs font-black uppercase tracking-[0.16em] text-slate-500">{label}</span>
    <span className="text-sm font-semibold text-slate-800">{value}</span>
  </div>
);

export default TeacherManagement;
