import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Search,
  UserRound,
  UserX,
} from 'lucide-react';
import { db } from '../../utils/db';

const StudentAttendance = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [students] = useState(() => db.getAll('students'));
  const [attendanceRecords] = useState(() => db.getAll('attendance_records'));
  const [searchValue, setSearchValue] = useState('');

  const student = useMemo(() => {
    if (!session || session.role !== 'student') return null;

    return students.find((entry) => {
      const matchesId = session.studentId && String(entry.id) === String(session.studentId);
      const matchesSystemId = session.studentSystemId && String(entry.systemId) === String(session.studentSystemId);
      const matchesEnrollment = session.enrollmentNo && String(entry.enrollmentNo) === String(session.enrollmentNo);
      return matchesId || matchesSystemId || matchesEnrollment;
    }) || null;
  }, [session, students]);

  const studentName = student
    ? `${student.firstName || ''} ${student.lastName || ''}`.trim() || student.enrollmentNo || student.systemId || 'Student'
    : 'Student';

  const studentRecords = useMemo(() => {
    if (!student) return [];

    const studentKeys = [student.systemId, student.enrollmentNo, String(student.id)]
      .filter(Boolean)
      .map((value) => String(value));
    const query = searchValue.trim().toLowerCase();

    return attendanceRecords
      .filter((record) => {
        const recordStudentId = String(record.studentId || '');
        const recordRollNo = String(record.rollNo || '');
        const recordName = String(record.studentName || '').trim().toLowerCase();
        return (
          studentKeys.includes(recordStudentId) ||
          studentKeys.includes(recordRollNo) ||
          recordName === studentName.toLowerCase()
        );
      })
      .filter((record) => {
        if (!query) return true;
        return (
          String(record.date || '').toLowerCase().includes(query) ||
          String(record.className || '').toLowerCase().includes(query) ||
          String(record.subject || '').toLowerCase().includes(query) ||
          String(record.status || '').toLowerCase().includes(query) ||
          String(record.markedBy || '').toLowerCase().includes(query) ||
          String(record.lectureNumber || '').toLowerCase().includes(query)
        );
      })
      .sort((a, b) => new Date(b.createdAt || b.date || 0).getTime() - new Date(a.createdAt || a.date || 0).getTime());
  }, [attendanceRecords, searchValue, student, studentName]);

  const today = new Date().toISOString().split('T')[0];
  const todayRecords = studentRecords.filter((record) => record.date === today);
  const presentCount = studentRecords.filter((record) => record.status === 'Present').length;
  const absentCount = studentRecords.filter((record) => record.status === 'Absent').length;
  const attendanceRate = studentRecords.length ? Math.round((presentCount / studentRecords.length) * 100) : 0;

  useEffect(() => {
    if (!session || session.role !== 'student') {
      navigate('/login');
    }
  }, [navigate, session]);

  if (!session || session.role !== 'student') return null;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#eefbf4_44%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/student')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-600">Student Attendance</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">My Attendance Record</h1>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#052e16_0%,#14532d_55%,#022c22_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(20,83,45,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-200">Student View</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Review only your own attendance entries.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-emerald-50/80">
                This page is student-specific. It shows the attendance records linked to {studentName} across saved class sessions.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Attendance Rate" value={`${attendanceRate}%`} icon={CheckCircle2} />
              <MetricCard label="Total Records" value={studentRecords.length} icon={BookOpen} />
              <MetricCard label="Present" value={presentCount} icon={UserRound} />
              <MetricCard label="Absent" value={absentCount} icon={UserX} />
            </div>
          </div>
        </section>

        <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Saved Attendance Records</h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Search your attendance by date, class, subject, teacher, lecture, or status.
              </p>
            </div>
            <SearchInput value={searchValue} onChange={setSearchValue} placeholder="Search date, subject, teacher..." />
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <HighlightCard label="Today Records" value={todayRecords.length} icon={CalendarDays} tone="emerald" />
            <HighlightCard label="Class" value={student?.assignedClass || 'Not assigned'} icon={BookOpen} tone="slate" />
            <HighlightCard label="Student ID" value={student?.enrollmentNo || student?.systemId || 'Pending'} icon={Clock3} tone="slate" />
          </div>

          {studentRecords.length > 0 ? (
            <div className="mt-8 grid gap-4">
              {studentRecords.map((record) => (
                <article
                  key={record.id}
                  className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5 transition hover:border-emerald-200 hover:bg-white"
                >
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                      <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">
                        {record.className || student?.assignedClass || 'Class pending'}
                      </p>
                      <h3 className="mt-2 text-xl font-black tracking-tight text-slate-950">
                        {record.subject || 'Subject pending'}
                      </h3>
                      <p className="mt-2 text-sm font-semibold text-slate-500">
                        Marked by {record.markedBy || 'Teacher pending'} | Lecture {record.lectureNumber || '-'}
                      </p>
                    </div>
                    <span
                      className={`inline-flex rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] ${
                        record.status === 'Present'
                          ? 'border border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'border border-rose-200 bg-rose-50 text-rose-700'
                      }`}
                    >
                      {record.status || 'Pending'}
                    </span>
                  </div>

                  <div className="mt-5 grid gap-3 md:grid-cols-3">
                    <InfoPill label="Date" value={record.date || 'Not added'} />
                    <InfoPill label="Roll No" value={record.rollNo || student?.enrollmentNo || student?.systemId || '-'} />
                    <InfoPill label="Recorded At" value={formatDateTime(record.createdAt || record.date)} />
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              title="No attendance found"
              description="No attendance records are linked to this student yet. Once a teacher saves attendance for your class, it will appear here."
            />
          )}
        </section>
      </main>
    </div>
  );
};

const MetricCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-50/80">{label}</p>
        <p className="mt-3 text-3xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-200/20 bg-emerald-200/10 text-emerald-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative w-full lg:w-80">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
    />
  </div>
);

const HighlightCard = ({ label, value, icon: Icon, tone }) => (
  <div className={`rounded-[1.6rem] border p-5 ${tone === 'emerald' ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200 bg-slate-50'}`}>
    <div className="flex items-start justify-between gap-3">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">{label}</p>
        <p className="mt-3 text-lg font-black tracking-tight text-slate-900">{value}</p>
      </div>
      <div className={`flex h-11 w-11 items-center justify-center rounded-2xl ${tone === 'emerald' ? 'bg-emerald-100 text-emerald-700' : 'bg-white text-slate-700'}`}>
        <Icon size={18} />
      </div>
    </div>
  </div>
);

const InfoPill = ({ label, value }) => (
  <div className="rounded-2xl bg-white px-4 py-3 shadow-sm">
    <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">{label}</p>
    <p className="mt-2 text-sm font-bold text-slate-800">{value}</p>
  </div>
);

const EmptyState = ({ title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <BookOpen size={34} />
    </div>
    <h3 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const formatDateTime = (value) => {
  if (!value) return 'Not available';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return String(value);
  return parsed.toLocaleString();
};

export default StudentAttendance;
