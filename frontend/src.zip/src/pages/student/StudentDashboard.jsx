import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  Bus,
  CheckCircle2,
  CreditCard,
  CalendarClock,
  FileText,
  GraduationCap,
  Library,
  LogOut,
  Receipt,
  ScrollText,
  UserRound,
} from 'lucide-react';
import { db } from '../../utils/db';

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [students] = useState(() => db.getAll('students'));
  const [classTimetables] = useState(() => db.getAll('timetable_class_slots'));
  const [attendanceRecords] = useState(() => db.getAll('attendance_records'));
  const [dateSheets] = useState(() => db.getAll('exam_datesheets'));
  const [admitCards] = useState(() => db.getAll('exam_admit_cards'));
  const [transportRecords] = useState(() => db.getAll('transport_students'));
  const [libraryIssues] = useState(() => db.getAll('library_issues'));
  const [books] = useState(() => db.getAll('library_books'));
  const [feePayments] = useState(() => db.getAll('fee_payments'));

  const student = useMemo(() => {
    if (!session || session.role !== 'student') return null;

    return students.find((entry) => {
      const matchesId = session.studentId && String(entry.id) === String(session.studentId);
      const matchesSystemId = session.studentSystemId && String(entry.systemId) === String(session.studentSystemId);
      const matchesEnrollment = session.enrollmentNo && String(entry.enrollmentNo) === String(session.enrollmentNo);
      return matchesId || matchesSystemId || matchesEnrollment;
    }) || null;
  }, [session, students]);

  const studentName = student
    ? `${student.firstName || ''} ${student.lastName || ''}`.trim() || student.enrollmentNo || student.systemId || 'Student'
    : 'Student';

  const studentAttendance = useMemo(() => {
    if (!student) return [];
    const studentKeys = [student.systemId, student.enrollmentNo, String(student.id)].filter(Boolean).map(String);
    return attendanceRecords.filter((record) => {
      const recordStudentId = String(record.studentId || '');
      const recordRollNo = String(record.rollNo || '');
      const recordName = String(record.studentName || '').trim().toLowerCase();
      return (
        studentKeys.includes(recordStudentId) ||
        studentKeys.includes(recordRollNo) ||
        recordName === studentName.toLowerCase()
      );
    });
  }, [attendanceRecords, student, studentName]);

  const presentCount = studentAttendance.filter((record) => record.status === 'Present').length;
  const attendanceRate = studentAttendance.length
    ? Math.round((presentCount / studentAttendance.length) * 100)
    : 0;

  const classDateSheets = useMemo(() => {
    if (!student?.assignedClass) return [];
    return dateSheets.filter((record) => record.className === student.assignedClass);
  }, [dateSheets, student]);

  const classTimetableRecord = useMemo(() => {
    if (!student?.assignedClass) return null;
    return classTimetables.find((record) => record.className === student.assignedClass) || null;
  }, [classTimetables, student]);

  const studentAdmitCards = useMemo(() => {
    if (!student) return [];
    const studentKeys = [student.systemId, student.enrollmentNo, String(student.id)].filter(Boolean).map(String);
    return admitCards.filter((record) => {
      const recordStudentId = String(record.studentId || '');
      const recordRollNo = String(record.rollNo || '');
      const recordName = String(record.studentName || '').trim().toLowerCase();
      return (
        studentKeys.includes(recordStudentId) ||
        studentKeys.includes(recordRollNo) ||
        recordName === studentName.toLowerCase()
      );
    });
  }, [admitCards, student, studentName]);

  const transportAssignment = useMemo(() => {
    if (!student) return null;
    const studentKeys = [String(student.id), String(student.systemId || ''), String(student.enrollmentNo || '')];
    return transportRecords.find((record) =>
      studentKeys.includes(String(record.studentId || '')) ||
      String(record.studentName || '').trim().toLowerCase() === studentName.toLowerCase(),
    ) || null;
  }, [student, studentName, transportRecords]);

  const activeLibraryIssues = useMemo(() => {
    if (!student) return [];
    return libraryIssues
      .filter((issue) => String(issue.borrowerId) === String(student.id) && !issue.returnDate)
      .map((issue) => ({
        ...issue,
        bookTitle: books.find((book) => book.id === issue.bookId)?.title || 'Library Book',
      }));
  }, [books, libraryIssues, student]);

  const studentPayments = useMemo(() => {
    if (!student) return [];
    return feePayments.filter((payment) => String(payment.studentId) === String(student.id));
  }, [feePayments, student]);

  const paidAmount = studentPayments
    .filter((payment) => payment.paymentStatus === 'Success')
    .reduce((sum, payment) => sum + (Number(payment.paidAmount) || 0), 0);

  const pendingBalance = studentPayments.reduce((sum, payment) => sum + (Number(payment.balanceRemaining) || 0), 0);

  const handleLogout = () => {
    localStorage.removeItem('active_session');
    localStorage.removeItem('current_college_id');
    navigate('/login');
  };

  useEffect(() => {
    if (!session || session.role !== 'student') {
      navigate('/login');
    }
  }, [navigate, session]);

  if (!session || session.role !== 'student') return null;

  return (
    <div className="min-h-screen bg-[#F8FAFC] pb-20 font-sans text-slate-900">
      <header className="sticky top-0 z-50 h-20 border-b border-slate-100 bg-white">
        <div className="mx-auto flex h-full max-w-screen-2xl items-center justify-between px-6 md:px-12 lg:px-20">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-cyan-600 p-1.5 shadow-sm">
              <GraduationCap size={20} className="text-white" />
            </div>
            <span className="hidden font-black uppercase italic tracking-tighter text-cyan-800 sm:block sm:text-xl">EduStream</span>
          </div>

          <div className="flex items-center gap-4 lg:gap-8">
            <div className="flex items-center gap-3 border-r border-slate-100 pr-4 lg:gap-6 lg:pr-8">
              <button className="rounded-full bg-slate-50 p-2 text-slate-400 transition-all hover:text-cyan-600">
                <Bell size={18} />
              </button>
              <div className="hidden text-right md:block">
                <p className="text-[10px] font-black uppercase text-slate-400">{studentName}</p>
                <span className="rounded bg-cyan-100 px-2 py-0.5 text-[9px] font-black uppercase tracking-widest text-cyan-700">
                  Student Session
                </span>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-rose-100 transition-all hover:bg-rose-700 md:px-6 md:py-2.5 md:text-sm"
            >
              <LogOut size={16} />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-screen-2xl px-6 pt-16 md:px-12 lg:px-20">
        <div className="mb-10 px-4 text-center">
          <h1 className="flex flex-wrap items-center justify-center gap-3 text-3xl font-black tracking-tighter text-slate-950 md:gap-4 md:text-5xl">
            <UserRound size={38} className="text-cyan-700" />
            Student Dashboard
          </h1>
          <p className="mt-4 text-sm font-semibold text-slate-500">
            {session.instituteName} | {student?.assignedClass || 'Class not assigned'} | {student?.enrollmentNo || student?.systemId || 'Enrollment pending'}
          </p>
        </div>

        <section className="mb-12 overflow-hidden rounded-[2.5rem] bg-[linear-gradient(145deg,#082f49_0%,#0e7490_52%,#155e75_100%)] px-8 py-8 text-white shadow-[0_30px_80px_-40px_rgba(8,47,73,0.85)] md:px-12 md:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-cyan-200">Student Portal</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Welcome {studentName}, keep your academic records and daily essentials in one place.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-cyan-50/85">
                This dashboard gives each student a focused view of attendance, examination records, transport details, fee payments, and profile information saved by the institution.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Attendance Rate" value={`${attendanceRate}%`} icon={CheckCircle2} />
              <MetricCard label="Exam Documents" value={classDateSheets.length + studentAdmitCards.length} icon={FileText} />
              <MetricCard label="Timetable" value={classTimetableRecord ? 'Available' : 'Pending'} icon={CalendarClock} />
              <MetricCard label="Library Loans" value={activeLibraryIssues.length} icon={Library} />
              <MetricCard label="Fees Paid" value={`Rs ${paidAmount}`} icon={CreditCard} />
            </div>
          </div>
        </section>

        <section className="mb-12 grid grid-cols-1 gap-6 md:grid-cols-2 md:gap-10 lg:grid-cols-3">
          <ModuleCard
            icon={<CheckCircle2 className="text-emerald-700" size={42} />}
            title="Attendance"
            desc={`${studentAttendance.length} saved attendance records for this student.`}
            onClick={() => navigate('/student/attendance')}
          />
          <ModuleCard
            icon={<CalendarClock className="text-cyan-700" size={42} />}
            title="Timetable"
            desc={classTimetableRecord?.fileName
              ? `${classTimetableRecord.fileName} available for your class.`
              : 'College timetable upload hote hi yahan read-only view me milega.'}
            onClick={() => navigate('/student/timetable')}
          />
          <ModuleCard
            icon={<ScrollText className="text-indigo-700" size={42} />}
            title="Examinations"
            desc={`${studentAdmitCards.length} admit cards and ${classDateSheets.length} class date sheets available.`}
            onClick={() => navigate('/student/examinations')}
          />
          <ModuleCard
            icon={<Bus className="text-sky-700" size={42} />}
            title="Transport"
            desc={transportAssignment?.routeName
              ? `${transportAssignment.routeName} | Bus ${transportAssignment.busNumber || 'Assigned'}`
              : ((student?.transportOptIn === 'yes' || student?.transportOptIn === true)
                ? `Transport ${student?.transportStatus || 'inactive'} | Waiting for assignment`
                : 'No transport facility requested yet.')}
            onClick={() => navigate('/student/transport')}
          />
          <ModuleCard
            icon={<Library className="text-amber-700" size={42} />}
            title="Library"
            desc={`${activeLibraryIssues.length} active book issues currently linked to this student.`}
            onClick={() => navigate('/student/library')}
          />
          <ModuleCard
            icon={<Receipt className="text-rose-700" size={42} />}
            title="Fees"
            desc={`Paid Rs ${paidAmount} | Pending balance Rs ${pendingBalance}`}
            onClick={() => navigate('/student/fees')}
          />
          <ModuleCard
            icon={<UserRound className="text-cyan-700" size={42} />}
            title="My Profile"
            desc={`${student?.email || 'Email not added'} | ${student?.mobile || 'Phone not added'}`}
            onClick={() => navigate('/student/profile')}
          />
        </section>
      </div>
    </div>
  );
};

const MetricCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-cyan-50/80">{label}</p>
        <p className="mt-3 text-3xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-cyan-200/20 bg-cyan-200/10 text-cyan-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const ModuleCard = ({ icon, title, desc, onClick }) => (
  <button
    onClick={onClick}
    className="flex w-full flex-col items-center rounded-4xl border border-slate-100 bg-white p-8 text-center shadow-xl shadow-slate-200/40 transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl md:rounded-[2.5rem] md:p-12"
  >
    <div className="mb-6 md:mb-8">
      {icon}
    </div>
    <h3 className="mb-2 text-xl font-bold tracking-tight text-slate-800 md:mb-3 md:text-2xl">{title}</h3>
    <p className="max-w-60 text-xs leading-relaxed text-slate-500 md:text-sm">{desc}</p>
  </button>
);

export default StudentDashboard;
