import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Bus,
  Clock3,
  MapPin,
  Phone,
  Route,
  UserRound,
} from 'lucide-react';
import { db } from '../../utils/db';

const StudentTransport = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [students] = useState(() => db.getAll('students'));
  const [transportRecords] = useState(() => db.getAll('transport_students'));
  const [drivers] = useState(() => db.getAll('transport_drivers'));

  const student = useMemo(() => {
    if (!session || session.role !== 'student') return null;
    return students.find((entry) => {
      const matchesId = session.studentId && String(entry.id) === String(session.studentId);
      const matchesSystemId = session.studentSystemId && String(entry.systemId) === String(session.studentSystemId);
      const matchesEnrollment = session.enrollmentNo && String(entry.enrollmentNo) === String(session.enrollmentNo);
      return matchesId || matchesSystemId || matchesEnrollment;
    }) || null;
  }, [session, students]);

  const studentName = student
    ? `${student.firstName || ''} ${student.lastName || ''}`.trim() || student.enrollmentNo || student.systemId || 'Student'
    : 'Student';

  const transportAssignment = useMemo(() => {
    if (!student) return null;
    const studentKeys = [String(student.id), String(student.systemId || ''), String(student.enrollmentNo || '')];
    return transportRecords.find((record) =>
      studentKeys.includes(String(record.studentId || '')) ||
      String(record.studentName || '').trim().toLowerCase() === studentName.toLowerCase(),
    ) || null;
  }, [student, studentName, transportRecords]);

  const assignedDriver = useMemo(() => {
    if (!transportAssignment?.assignedDriverId) return null;
    return drivers.find((driver) => String(driver.id) === String(transportAssignment.assignedDriverId)) || null;
  }, [drivers, transportAssignment]);

  const driverPhone = transportAssignment?.driverPhone || assignedDriver?.driverPhone || 'Not added';
  const pickupPoints = assignedDriver?.pickupPoints || 'Not added';
  const vehicleType = assignedDriver?.vehicleType || 'Not added';
  const transportRequested = student?.transportOptIn === 'yes' || student?.transportOptIn === true;
  const transportStatus = student?.transportStatus || 'inactive';

  useEffect(() => {
    if (!session || session.role !== 'student') {
      navigate('/login');
    }
  }, [navigate, session]);

  if (!session || session.role !== 'student') return null;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#ecfeff_45%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/student')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-sky-300 hover:text-sky-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-sky-600">Student Transport</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">My Transport Details</h1>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#0c4a6e_0%,#0284c7_50%,#164e63_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(14,116,144,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.08fr_0.92fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-sky-200">Student Transport Workspace</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                View only your own route, bus, and pickup details.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-sky-50/80">
                This page shows the transport assignment saved for {studentName}. If no transport record is linked yet, the page will stay empty until the institution assigns one.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Class" value={student?.assignedClass || 'Not assigned'} icon={UserRound} />
              <MetricCard label="Facility Status" value={transportRequested ? transportStatus : 'Not requested'} icon={Clock3} />
              <MetricCard label="Route" value={transportAssignment?.routeName || 'Not assigned'} icon={Route} />
              <MetricCard label="Bus Number" value={transportAssignment?.busNumber || 'Not assigned'} icon={Bus} />
              <MetricCard label="Pickup Stop" value={transportAssignment?.pickupStop || 'Not added'} icon={MapPin} />
            </div>
          </div>
        </section>

        {transportAssignment ? (
          <section className="mt-8 grid gap-8 xl:grid-cols-[1.05fr_0.95fr]">
            <div className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
              <p className="text-[11px] font-black uppercase tracking-[0.24em] text-sky-600">Route Summary</p>
              <h2 className="mt-3 font-serif text-3xl font-black italic tracking-tight text-slate-950">
                {transportAssignment.routeName || 'Route not assigned'}
              </h2>
              <p className="mt-3 text-sm leading-6 text-slate-500">
                This transport record is mapped only to the logged-in student and shows the assigned route, bus, pickup stop, and driver contact.
              </p>

              <div className="mt-8 grid gap-4 md:grid-cols-2">
                <FeatureCard icon={Bus} label="Bus Number" value={transportAssignment.busNumber || 'Not assigned'} />
                <FeatureCard icon={MapPin} label="Pickup Stop" value={transportAssignment.pickupStop || 'Not added'} />
                <FeatureCard icon={Route} label="Route Name" value={transportAssignment.routeName || 'Not assigned'} />
                <FeatureCard icon={Clock3} label="Vehicle Type" value={vehicleType} />
              </div>
            </div>

            <div className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
              <p className="text-[11px] font-black uppercase tracking-[0.24em] text-sky-600">Contact Details</p>
              <h2 className="mt-3 font-serif text-3xl font-black italic tracking-tight text-slate-950">
                Driver And Student Info
              </h2>
              <div className="mt-8 grid gap-4">
                <InfoRow label="Student" value={transportAssignment.studentName || studentName} />
                <InfoRow label="Class" value={transportAssignment.className || student?.assignedClass || 'Not assigned'} />
                <InfoRow label="Driver Name" value={transportAssignment.driverName || assignedDriver?.driverName || 'Not assigned'} />
                <InfoRow label="Driver Mobile" value={driverPhone} />
                <InfoRow label="Pickup Points" value={pickupPoints} />
              </div>
            </div>
          </section>
        ) : (
          <section className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center shadow-[0_20px_60px_-35px_rgba(15,23,42,0.2)]">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-slate-50 text-slate-300">
              <Bus size={34} />
            </div>
            <h3 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">No transport assignment yet</h3>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-slate-500">
              {transportRequested
                ? `Transport facility is ${transportStatus} for this student. Once the institution assigns a route, bus, and pickup stop, it will appear here.`
                : 'No transport facility is requested for this student yet. The college can enable it later from the student data and then assign a route.'}
            </p>
          </section>
        )}
      </main>
    </div>
  );
};

const MetricCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-sky-50/80">{label}</p>
        <p className="mt-3 text-lg font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-sky-200/20 bg-sky-200/10 text-sky-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const FeatureCard = ({ icon: Icon, label, value }) => (
  <div className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-sky-700 shadow-sm">
      <Icon size={20} />
    </div>
    <p className="mt-4 text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">{label}</p>
    <p className="mt-2 text-base font-black tracking-tight text-slate-950">{value}</p>
  </div>
);

const InfoRow = ({ label, value }) => (
  <div className="flex items-center justify-between gap-4 rounded-2xl bg-slate-50 px-4 py-3">
    <span className="text-[11px] font-black uppercase tracking-[0.16em] text-slate-500">{label}</span>
    <span className="text-right text-sm font-black text-slate-900">{value}</span>
  </div>
);

export default StudentTransport;
