import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  CalendarClock,
  Download,
  Eye,
  FileText,
  GraduationCap,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const StudentTimetable = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [students] = useState(() => db.getAll('students'));
  const [classTimetables] = useState(() => db.getAll('timetable_class_slots'));
  const [previewRecord, setPreviewRecord] = useState(null);

  const student = useMemo(() => {
    if (!session || session.role !== 'student') return null;

    return students.find((entry) => {
      const matchesId = session.studentId && String(entry.id) === String(session.studentId);
      const matchesSystemId = session.studentSystemId && String(entry.systemId) === String(session.studentSystemId);
      const matchesEnrollment = session.enrollmentNo && String(entry.enrollmentNo) === String(session.enrollmentNo);
      return matchesId || matchesSystemId || matchesEnrollment;
    }) || null;
  }, [session, students]);

  const studentName = student
    ? `${student.firstName || ''} ${student.lastName || ''}`.trim() || student.enrollmentNo || student.systemId || 'Student'
    : 'Student';

  const classTimetableRecord = useMemo(() => {
    if (!student?.assignedClass) return null;
    return classTimetables.find((record) => record.className === student.assignedClass) || null;
  }, [classTimetables, student]);

  useEffect(() => {
    if (!session || session.role !== 'student') {
      navigate('/login');
    }
  }, [navigate, session]);

  const handleDownload = (record) => {
    if (!record?.fileData) return;
    const link = document.createElement('a');
    link.href = record.fileData;
    link.download = record.fileName || 'class-timetable';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!session || session.role !== 'student') return null;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#eef7ff_46%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/student')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-cyan-300 hover:text-cyan-700"
            >
              <ArrowLeft size={14} />
              Back
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-cyan-600">Student Timetable</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">My Class Timetable</h1>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#0f172a_0%,#0e7490_48%,#164e63_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(14,116,144,0.75)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.08fr_0.92fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-cyan-200">Student Timetable View</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Class timetable uploaded by college is visible here in read-only mode.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-cyan-50/80">
                {studentName} sirf apni assigned class ka timetable dekh sakta hai. College ne kisi bhi format me file upload ki ho, woh yahan student view me available hogi.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Student" value={studentName} icon={GraduationCap} />
              <MetricCard label="Assigned Class" value={student?.assignedClass || 'Not assigned'} icon={CalendarClock} />
              <MetricCard label="Timetable File" value={classTimetableRecord?.fileName || 'Not uploaded'} icon={FileText} />
              <MetricCard label="Access" value="Read Only" icon={Eye} />
            </div>
          </div>
        </section>

        <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Assigned Class Timetable</h2>
              <p className="mt-1 text-sm leading-6 text-slate-500">
                Only timetable for {student?.assignedClass || 'your class'} is visible here.
              </p>
            </div>
          </div>

          {classTimetableRecord ? (
            <article className="mt-8 rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.18em] text-cyan-700">
                    {classTimetableRecord.className || student?.assignedClass || 'Class pending'}
                  </p>
                  <h3 className="mt-2 text-xl font-black tracking-tight text-slate-950">
                    {classTimetableRecord.fileName || 'Uploaded timetable'}
                  </h3>
                  <p className="mt-2 text-sm font-semibold text-slate-500">
                    Uploaded {formatDateTime(classTimetableRecord.uploadedAt || classTimetableRecord.createdAt)}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {isPreviewableFile(classTimetableRecord) ? (
                    <button
                      type="button"
                      onClick={() => setPreviewRecord(classTimetableRecord)}
                      className="inline-flex items-center gap-2 rounded-full border border-cyan-200 bg-cyan-50 px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-cyan-700 transition hover:bg-cyan-100"
                    >
                      <Eye size={14} />
                      View
                    </button>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => handleDownload(classTimetableRecord)}
                    className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-slate-700 transition hover:border-cyan-300 hover:text-cyan-700"
                  >
                    <Download size={14} />
                    Download
                  </button>
                </div>
              </div>

              {!isPreviewableFile(classTimetableRecord) ? (
                <div className="mt-5 rounded-[1.4rem] border border-dashed border-slate-300 bg-white px-5 py-5 text-sm leading-7 text-slate-500">
                  Ye file browser ke andar preview nahi hoti. Student isse sirf download/open kar sakta hai.
                </div>
              ) : null}
            </article>
          ) : (
            <EmptyState
              title="No timetable uploaded"
              description="College ne abhi tak aapki class ka timetable upload nahi kiya hai. Upload hote hi yahan read-only view me dikh jayega."
            />
          )}
        </section>
      </main>

      {previewRecord ? <FilePreviewModal record={previewRecord} onClose={() => setPreviewRecord(null)} /> : null}
    </div>
  );
};

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-cyan-50/80">{label}</p>
        <p className="mt-3 text-2xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-cyan-200/20 bg-cyan-200/10 text-cyan-50">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const EmptyState = ({ title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <FileText size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const FilePreviewModal = ({ record, onClose }) => {
  const canPreview = isPreviewableFile(record);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/70 px-4 py-6 backdrop-blur-sm">
      <div className="flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-4xl bg-white shadow-[0_30px_90px_-35px_rgba(15,23,42,0.75)]">
        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between lg:px-7">
          <div className="min-w-0">
            <p className="text-[11px] font-black uppercase tracking-[0.22em] text-cyan-700">{record.className}</p>
            <h3 className="mt-1 truncate font-serif text-2xl font-black italic tracking-tight text-slate-950">{record.fileName || 'Uploaded timetable'}</h3>
          </div>
          <div className="flex items-center gap-2">
            {record.fileData ? (
              <a
                href={record.fileData}
                download={record.fileName || 'class-timetable'}
                className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-white transition hover:bg-cyan-600"
                title="Download"
              >
                <Download size={18} />
              </a>
            ) : null}
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              title="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-auto bg-slate-100 p-4 lg:p-6">
          {canPreview ? (
            <div className="min-h-[65vh] overflow-hidden rounded-[1.6rem] border border-slate-200 bg-white">
              {isImageFile(record) ? (
                <img src={record.fileData} alt={record.fileName || 'Uploaded timetable'} className="mx-auto max-h-[72vh] w-auto max-w-full object-contain" />
              ) : (
                <iframe title={record.fileName || 'Uploaded timetable'} src={record.fileData} className="h-[72vh] w-full bg-white" />
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

const formatDateTime = (value) => {
  if (!value) return 'Date pending';
  return new Date(value).toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const isImageFile = (record) => {
  return record.fileType?.startsWith('image/') || /\.(png|jpe?g|gif|webp|svg)$/i.test(record.fileName || '');
};

const isPdfFile = (record) => {
  return record.fileType === 'application/pdf' || /\.pdf$/i.test(record.fileName || '');
};

const isHtmlFile = (record) => {
  return record.fileType === 'text/html' || /\.(html?)$/i.test(record.fileName || '');
};

const isPreviewableFile = (record) => {
  return Boolean(record?.fileData) && (isImageFile(record) || isPdfFile(record) || isHtmlFile(record));
};

export default StudentTimetable;
