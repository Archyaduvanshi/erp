import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  CalendarDays,
  Download,
  FileText,
  Search,
  Ticket,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const StudentExaminations = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [activeSection, setActiveSection] = useState('home');
  const [searchValue, setSearchValue] = useState('');
  const [students] = useState(() => db.getAll('students'));
  const [dateSheets] = useState(() => db.getAll('exam_datesheets'));
  const [admitCards] = useState(() => db.getAll('exam_admit_cards'));

  const student = useMemo(() => {
    if (!session || session.role !== 'student') return null;

    return students.find((entry) => {
      const matchesId = session.studentId && String(entry.id) === String(session.studentId);
      const matchesSystemId = session.studentSystemId && String(entry.systemId) === String(session.studentSystemId);
      const matchesEnrollment = session.enrollmentNo && String(entry.enrollmentNo) === String(session.enrollmentNo);
      return matchesId || matchesSystemId || matchesEnrollment;
    }) || null;
  }, [session, students]);

  const studentName = student
    ? `${student.firstName || ''} ${student.lastName || ''}`.trim() || student.enrollmentNo || student.systemId || 'Student'
    : 'Student';

  const classDateSheets = useMemo(() => {
    if (!student?.assignedClass) return [];
    const query = searchValue.trim().toLowerCase();

    return dateSheets
      .filter((record) => record.className === student.assignedClass)
      .filter((record) => {
        if (!query) return true;
        return (
          String(record.examType || '').toLowerCase().includes(query) ||
          String(record.className || '').toLowerCase().includes(query) ||
          String(record.fileName || '').toLowerCase().includes(query)
        );
      })
      .sort((a, b) => String(a.examType || '').localeCompare(String(b.examType || '')));
  }, [dateSheets, searchValue, student]);

  const studentAdmitCards = useMemo(() => {
    if (!student) return [];
    const query = searchValue.trim().toLowerCase();
    const studentKeys = [student.systemId, student.enrollmentNo, String(student.id)].filter(Boolean).map(String);

    return admitCards
      .filter((record) => {
        const recordStudentId = String(record.studentId || '');
        const recordRollNo = String(record.rollNo || '');
        const recordName = String(record.studentName || '').trim().toLowerCase();
        return (
          studentKeys.includes(recordStudentId) ||
          studentKeys.includes(recordRollNo) ||
          recordName === studentName.toLowerCase()
        );
      })
      .filter((record) => {
        if (!query) return true;
        return (
          String(record.examTitle || '').toLowerCase().includes(query) ||
          String(record.rollNo || '').toLowerCase().includes(query) ||
          String(record.centerName || '').toLowerCase().includes(query) ||
          String(record.examDate || '').toLowerCase().includes(query)
        );
      })
      .sort((a, b) => new Date(a.examDate || 0).getTime() - new Date(b.examDate || 0).getTime());
  }, [admitCards, searchValue, student, studentName]);

  useEffect(() => {
    if (!session || session.role !== 'student') {
      navigate('/login');
    }
  }, [navigate, session]);

  const handleDownloadFile = (record, fallbackName) => {
    if (!record?.fileData) return;
    const link = document.createElement('a');
    link.href = record.fileData;
    link.download = record.fileName || fallbackName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!session || session.role !== 'student') return null;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#eef7ff_46%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => activeSection === 'home' ? navigate('/student') : setActiveSection('home')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-indigo-300 hover:text-indigo-700"
            >
              <ArrowLeft size={14} />
              {activeSection === 'home' ? 'Back' : 'Back To Cards'}
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-indigo-600">Student Examinations</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">My Examination Desk</h1>
            </div>
          </div>

          {activeSection !== 'home' ? (
            <button
              onClick={() => setActiveSection('home')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] text-slate-600 transition hover:border-indigo-300 hover:text-indigo-700"
            >
              <X size={14} />
              Close Section
            </button>
          ) : (
            <div className="hidden rounded-full border border-slate-200 bg-white px-5 py-3 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 md:inline-flex">
              Choose Datesheet Or Admit Card
            </div>
          )}
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#312e81_0%,#1d4ed8_48%,#0f172a_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(30,41,59,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.08fr_0.92fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-indigo-200">Student Exam Workspace</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Open your class datesheet or your own admit card from two clear sections.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-indigo-50/80">
                This page shows only exam records related to {studentName}. Date sheets are filtered by class, and admit cards are filtered by student.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Date Sheets" value={classDateSheets.length} icon={FileText} />
              <MetricCard label="Admit Cards" value={studentAdmitCards.length} icon={Ticket} />
              <MetricCard label="Class" value={student?.assignedClass || 'Not assigned'} icon={CalendarDays} />
              <MetricCard label="Student ID" value={student?.enrollmentNo || student?.systemId || 'Pending'} icon={Ticket} />
            </div>
          </div>
        </section>

        {activeSection === 'home' && (
          <section className="mt-8 grid gap-6 md:grid-cols-2">
            <EntryCard
              icon={<CalendarDays className="text-indigo-700" size={40} />}
              title="Datesheet"
              description="See only your own class exam datesheets and download the saved files."
              meta={`${classDateSheets.length} datesheet record${classDateSheets.length === 1 ? '' : 's'}`}
              onClick={() => setActiveSection('datesheet')}
            />
            <EntryCard
              icon={<Ticket className="text-emerald-700" size={40} />}
              title="Admit Card"
              description="Open the admit cards generated only for this logged-in student."
              meta={`${studentAdmitCards.length} admit card record${studentAdmitCards.length === 1 ? '' : 's'}`}
              onClick={() => setActiveSection('admit')}
            />
          </section>
        )}

        {activeSection === 'datesheet' && (
          <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h2 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">My Class Datesheet</h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Only datesheets for {student?.assignedClass || 'this class'} are visible here.
                </p>
              </div>
              <SearchInput value={searchValue} onChange={setSearchValue} placeholder="Search exam type or file..." />
            </div>

            {classDateSheets.length ? (
              <div className="mt-8 grid gap-4">
                {classDateSheets.map((record) => (
                  <article key={record.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div>
                        <p className="text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700">{record.className || student?.assignedClass || 'Class pending'}</p>
                        <h3 className="mt-2 text-xl font-black tracking-tight text-slate-950">{record.examType || 'Exam schedule'}</h3>
                        <p className="mt-2 text-sm font-semibold text-slate-500">{record.fileName || 'Datesheet available'}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDownloadFile(record, `${record.examType || 'date-sheet'}.pdf`)}
                        className="inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-4 py-2 text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700 transition hover:bg-indigo-100"
                      >
                        <Download size={14} />
                        Download
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <EmptyState title="No datesheet available" description="No exam datesheet is currently saved for this student's class." />
            )}
          </section>
        )}

        {activeSection === 'admit' && (
          <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h2 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">My Admit Card</h2>
                <p className="mt-1 text-sm leading-6 text-slate-500">
                  Only admit cards created for {studentName} are shown here.
                </p>
              </div>
              <SearchInput value={searchValue} onChange={setSearchValue} placeholder="Search exam, center, date..." />
            </div>

            {studentAdmitCards.length ? (
              <div className="mt-8 grid gap-4">
                {studentAdmitCards.map((card) => (
                  <article key={card.id} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                    <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">{card.examTitle || 'Exam pending'}</p>
                    <h3 className="mt-2 text-xl font-black tracking-tight text-slate-950">{card.className || student?.assignedClass || 'Class pending'}</h3>
                    <div className="mt-4 grid gap-3 md:grid-cols-2">
                      <InfoPill label="Roll No" value={card.rollNo || student?.enrollmentNo || student?.systemId || '-'} />
                      <InfoPill label="Exam Date" value={card.examDate || 'Not scheduled'} />
                      <InfoPill label="Center" value={card.centerName || 'Not assigned'} />
                      <InfoPill label="Reporting Time" value={card.reportingTime || 'Not added'} />
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <EmptyState title="No admit card yet" description="Once the institution generates an admit card for this student, it will appear here." />
            )}
          </section>
        )}
      </main>
    </div>
  );
};

const MetricCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-indigo-50/80">{label}</p>
        <p className="mt-3 text-2xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-indigo-200/20 bg-indigo-200/10 text-indigo-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const EntryCard = ({ icon, title, description, meta, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="rounded-[2rem] border border-slate-200 bg-white p-8 text-left shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] transition hover:-translate-y-2 hover:border-indigo-200 hover:shadow-[0_30px_70px_-40px_rgba(79,70,229,0.35)]"
  >
    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-50">
      {icon}
    </div>
    <h3 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-3 text-sm leading-7 text-slate-500">{description}</p>
    <p className="mt-5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-400">{meta}</p>
  </button>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative w-full lg:w-80">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
    />
  </div>
);

const InfoPill = ({ label, value }) => (
  <div className="rounded-2xl bg-white px-4 py-3 shadow-sm">
    <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">{label}</p>
    <p className="mt-2 text-sm font-bold text-slate-800">{value}</p>
  </div>
);

const EmptyState = ({ title, description }) => (
  <div className="rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <FileText size={34} />
    </div>
    <h3 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

export default StudentExaminations;
