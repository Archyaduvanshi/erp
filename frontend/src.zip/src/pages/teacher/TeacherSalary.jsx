import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Banknote, CalendarDays, CheckCircle2, Clock3, GraduationCap, IndianRupee } from 'lucide-react';
import { db } from '../../utils/db';
import { buildSalaryTimeline, formatSalary, getCurrentMonthSalaryStatus, getMonthLabel, normalizeTeacherSalary } from '../../utils/salaryUtils';

const TeacherSalary = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [teachers] = useState(() => db.getAll('teachers'));

  const teacher = useMemo(() => {
    if (!session || session.role !== 'teacher') return null;
    const matchingTeacher = teachers.find((entry) => String(entry.id) === String(session.teacherId)) || null;
    return matchingTeacher ? normalizeTeacherSalary(matchingTeacher) : null;
  }, [session, teachers]);

  const teacherName = teacher
    ? `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || teacher.teacherSystemId || 'Teacher'
    : 'Teacher';

  const currentSalaryStatus = useMemo(() => getCurrentMonthSalaryStatus(teacher), [teacher]);
  const salaryTimeline = useMemo(() => buildSalaryTimeline(teacher), [teacher]);
  const paidMonths = salaryTimeline.filter((entry) => entry.isPaid).length;
  const pendingMonths = salaryTimeline.filter((entry) => !entry.isPaid).length;

  useEffect(() => {
    if (!session || session.role !== 'teacher') {
      navigate('/login');
    }
  }, [navigate, session]);

  if (!session || session.role !== 'teacher') return null;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#ecfdf5_48%,#ffffff_100%)] pb-16 text-slate-900">
      <header className="sticky top-0 z-50 border-b border-slate-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-screen-2xl items-center justify-between px-6 py-5 md:px-12 lg:px-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/teacher')}
              className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={16} />
              Dashboard
            </button>
            <div className="rounded-lg bg-emerald-600 p-1.5 shadow-sm">
              <GraduationCap size={20} className="text-white" />
            </div>
            <span className="hidden font-black uppercase italic tracking-tighter text-emerald-800 sm:block sm:text-xl">EduStream</span>
          </div>

          <span className="rounded-full bg-emerald-100 px-3 py-1 text-[11px] font-black uppercase tracking-[0.2em] text-emerald-700">
            Teacher Salary
          </span>
        </div>
      </header>

      <div className="mx-auto max-w-screen-2xl px-6 pt-12 md:px-12 lg:px-20">
        <section className="overflow-hidden rounded-[2.5rem] bg-[linear-gradient(145deg,#0f172a_0%,#14532d_52%,#0f766e_100%)] px-8 py-8 text-white shadow-[0_30px_80px_-40px_rgba(15,23,42,0.85)] md:px-12 md:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-200">My Salary</p>
              <h1 className="mt-4 font-serif text-4xl font-black italic tracking-tight">
                {teacherName}
              </h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-emerald-50/85">
                Check whether your salary for {getMonthLabel(currentSalaryStatus?.monthKey)} is paid or pending, and review your payment timeline added by the college.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard label="This Month" value={currentSalaryStatus?.isPaid ? 'Paid' : 'Pending'} icon={currentSalaryStatus?.isPaid ? CheckCircle2 : Clock3} />
              <StatCard label="Current Salary" value={formatSalary(teacher?.salary)} icon={IndianRupee} />
              <StatCard label="Paid Months" value={String(paidMonths)} icon={Banknote} />
              <StatCard label="Pending Months" value={String(pendingMonths)} icon={CalendarDays} />
            </div>
          </div>
        </section>

        <section className="mt-8 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <InfoPanel
            title="Salary Summary"
            description="This view is read-only for teachers. The college payroll desk updates your salary and marks each month as paid."
          >
            <InfoRow icon={Banknote} label={`${getMonthLabel(currentSalaryStatus?.monthKey)} Status`} value={currentSalaryStatus?.isPaid ? 'Paid' : 'Pending'} />
            <InfoRow icon={IndianRupee} label="Monthly Salary" value={formatSalary(teacher?.salary)} />
            <InfoRow icon={CalendarDays} label="Teaching Start Date" value={teacher?.joiningDate || 'Not added'} />
            <InfoRow icon={CalendarDays} label="Assigned Class" value={teacher?.assignedClass || 'Not assigned'} />
            <InfoRow icon={CalendarDays} label="Specialization" value={teacher?.specialization || 'Not assigned'} />
          </InfoPanel>

          <InfoPanel
            title="Salary Timeline"
            description="Every month in your timeline shows whether your salary payment has been marked by the college."
          >
            {salaryTimeline.length ? (
              <div className="grid gap-3">
                {salaryTimeline.map((entry) => (
                  <div
                    key={entry.monthKey}
                    className={`rounded-3xl border px-4 py-4 ${
                      entry.isPaid ? 'border-emerald-200 bg-emerald-50' : 'border-amber-200 bg-amber-50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-600">{entry.label}</p>
                      <span className={`rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] ${entry.isPaid ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                        {entry.isPaid ? 'Paid' : 'Pending'}
                      </span>
                    </div>
                    <p className="mt-2 text-base font-black text-slate-950">{formatSalary(entry.amount)}</p>
                    <p className="mt-1 text-xs font-semibold text-slate-500">
                      {entry.isPaid ? `Paid on ${new Date(entry.paidOn).toLocaleDateString('en-IN')}` : 'Awaiting salary payment from college'}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState text="Your college has not added salary details yet." />
            )}
          </InfoPanel>
        </section>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-50/80">{label}</p>
        <p className="mt-3 text-lg font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-200/20 bg-emerald-200/10 text-emerald-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const InfoPanel = ({ title, description, children }) => (
  <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
    <h2 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h2>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
    <div className="mt-6 grid gap-3">{children}</div>
  </section>
);

const InfoRow = ({ icon, label, value }) => (
  <div className="flex items-center justify-between gap-4 rounded-2xl bg-slate-50 px-4 py-3">
    <div className="flex min-w-0 items-center gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white text-emerald-700 shadow-sm">
        {React.createElement(icon, { size: 18 })}
      </div>
      <span className="text-[11px] font-black uppercase tracking-[0.16em] text-slate-500">{label}</span>
    </div>
    <span className="text-right text-sm font-black text-slate-800">{value}</span>
  </div>
);

const EmptyState = ({ text }) => (
  <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center text-sm font-semibold text-slate-500">
    {text}
  </div>
);

export default TeacherSalary;
