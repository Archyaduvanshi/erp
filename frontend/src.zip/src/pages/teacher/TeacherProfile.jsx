import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Banknote,
  Briefcase,
  CalendarDays,
  FileBadge2,
  GraduationCap,
  IdCard,
  Mail,
  Phone,
  Shield,
  UserRound,
} from 'lucide-react';
import { db } from '../../utils/db';
import { formatSalary, normalizeTeacherSalary } from '../../utils/salaryUtils';

const TeacherProfile = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [teachers] = useState(() => db.getAll('teachers'));

  const teacher = useMemo(() => {
    if (!session || session.role !== 'teacher') return null;
    const matchingTeacher = teachers.find((entry) => String(entry.id) === String(session.teacherId)) || null;
    return matchingTeacher ? normalizeTeacherSalary(matchingTeacher) : null;
  }, [session, teachers]);

  const teacherName = teacher
    ? `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || teacher.teacherSystemId || 'Teacher'
    : 'Teacher';

  useEffect(() => {
    if (!session || session.role !== 'teacher') {
      navigate('/login');
    }
  }, [navigate, session]);

  if (!session || session.role !== 'teacher') return null;

  return (
    <div className="min-h-screen bg-[#F8FAFC] pb-16 font-sans text-slate-900">
      <header className="sticky top-0 z-50 border-b border-slate-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-screen-2xl items-center justify-between px-6 py-5 md:px-12 lg:px-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/teacher')}
              className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 transition hover:border-emerald-300 hover:text-emerald-700"
            >
              <ArrowLeft size={16} />
              Dashboard
            </button>
            <div className="rounded-lg bg-emerald-600 p-1.5 shadow-sm">
              <GraduationCap size={20} className="text-white" />
            </div>
            <span className="hidden font-black uppercase italic tracking-tighter text-emerald-800 sm:block sm:text-xl">EduStream</span>
          </div>

          <span className="rounded-full bg-emerald-100 px-3 py-1 text-[11px] font-black uppercase tracking-[0.2em] text-emerald-700">
            Teacher Profile
          </span>
        </div>
      </header>

      <div className="mx-auto max-w-screen-2xl px-6 pt-12 md:px-12 lg:px-20">
        <section className="overflow-hidden rounded-[2.5rem] bg-[linear-gradient(145deg,#0f172a_0%,#0f766e_52%,#14532d_100%)] px-8 py-8 text-white shadow-[0_30px_80px_-40px_rgba(15,23,42,0.85)] md:px-12 md:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-200">My Profile</p>
              <h1 className="mt-4 font-serif text-4xl font-black italic tracking-tight">
                {teacherName}
              </h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-emerald-50/85">
                View the profile details created by your college administration for your teacher account.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <StatCard label="Teacher ID" value={teacher?.teacherSystemId || 'Pending'} icon={IdCard} />
              <StatCard label="Employee ID" value={teacher?.employeeId || 'Pending'} icon={Briefcase} />
              <StatCard label="Assigned Class" value={teacher?.assignedClass || 'Not assigned'} icon={CalendarDays} />
              <StatCard label="Specialization" value={teacher?.specialization || 'Not assigned'} icon={Shield} />
            </div>
          </div>
        </section>

        <section className="mt-10 grid gap-8 lg:grid-cols-2">
          <InfoPanel
            title="Personal Details"
            description="Your basic account and contact details available in the teacher portal."
          >
            <InfoRow icon={UserRound} label="Full Name" value={teacherName} />
            <InfoRow icon={Mail} label="Personal Email" value={teacher?.personalEmail || 'Not added'} />
            <InfoRow icon={Phone} label="Mobile Number" value={teacher?.mobileNumber || 'Not added'} />
            <InfoRow icon={IdCard} label="Teacher ID" value={teacher?.teacherSystemId || 'Pending'} />
            <InfoRow icon={Briefcase} label="Employee ID" value={teacher?.employeeId || 'Pending'} />
          </InfoPanel>

          <InfoPanel
            title="Work Details"
            description="Academic and employment information assigned to your teacher profile."
          >
            <InfoRow icon={CalendarDays} label="Assigned Class" value={teacher?.assignedClass || 'Not assigned'} />
            <InfoRow icon={Shield} label="Specialization" value={teacher?.specialization || 'Not assigned'} />
            <InfoRow icon={Briefcase} label="Contract Type" value={teacher?.contractType || 'Not added'} />
            <InfoRow icon={Banknote} label="Monthly Salary" value={formatSalary(teacher?.salary)} />
            <InfoRow icon={CalendarDays} label="Teaching Start Date" value={teacher?.joiningDate || 'Not added'} />
            <InfoRow icon={CalendarDays} label="Experience" value={teacher?.experienceYears ? `${teacher.experienceYears} years` : 'Not added'} />
            <InfoRow icon={CalendarDays} label="Leave Balance" value={teacher?.leaveBalance || 'Not added'} />
          </InfoPanel>
        </section>

        <section className="mt-8 grid gap-8 lg:grid-cols-2">
          <InfoPanel
            title="Documents"
            description="Documents and identity records added by the college while creating your profile."
          >
            {teacher?.documents?.length ? (
              <div className="grid gap-3">
                {teacher.documents.map((document) => (
                  <div
                    key={document.id}
                    className="rounded-3xl border border-slate-200 bg-slate-50 px-4 py-4"
                  >
                    <p className="text-[11px] font-black uppercase tracking-[0.18em] text-emerald-700">
                      {document.documentType || 'Document'}
                    </p>
                    <p className="mt-2 text-sm font-semibold text-slate-700">
                      {document.fileUploadPath || 'File path not available'}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState text="No documents are linked to this profile yet." />
            )}
          </InfoPanel>

          <InfoPanel
            title="Portal Identity"
            description="Reference values generated for login and profile administration."
          >
            <InfoRow icon={FileBadge2} label="QR Code Data" value={teacher?.qrCodeData || 'Not generated'} />
            <InfoRow icon={Shield} label="Status" value={teacher?.status || 'Active'} />
            <InfoRow icon={IdCard} label="Card Expiry Date" value={teacher?.cardExpiryDate || 'Not added'} />
            <InfoRow
              icon={CalendarDays}
              label="Created On"
              value={teacher?.createdAt ? new Date(teacher.createdAt).toLocaleDateString() : 'Not available'}
            />
          </InfoPanel>
        </section>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-emerald-50/80">{label}</p>
        <p className="mt-3 text-lg font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-200/20 bg-emerald-200/10 text-emerald-50">
        {React.createElement(icon, { size: 20 })}
      </div>
    </div>
  </div>
);

const InfoPanel = ({ title, description, children }) => (
  <section className="rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
    <h2 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h2>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
    <div className="mt-6 grid gap-3">{children}</div>
  </section>
);

const InfoRow = ({ icon, label, value }) => (
  <div className="flex items-center justify-between gap-4 rounded-2xl bg-slate-50 px-4 py-3">
    <div className="flex min-w-0 items-center gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white text-emerald-700 shadow-sm">
        {React.createElement(icon, { size: 18 })}
      </div>
      <span className="text-[11px] font-black uppercase tracking-[0.16em] text-slate-500">{label}</span>
    </div>
    <span className="text-right text-sm font-black text-slate-800">{value}</span>
  </div>
);

const EmptyState = ({ text }) => (
  <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center text-sm font-semibold text-slate-500">
    {text}
  </div>
);

export default TeacherProfile;
