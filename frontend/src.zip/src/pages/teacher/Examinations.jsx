import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  Download,
  FileText,
  GraduationCap,
  ScrollText,
  Search,
  Upload,
  UserRound,
  X,
} from 'lucide-react';
import { db } from '../../utils/db';

const TeacherExaminations = () => {
  const navigate = useNavigate();
  const [session] = useState(() => JSON.parse(localStorage.getItem('active_session')) || null);
  const [activeSection, setActiveSection] = useState('home');
  const [selectedDateSheetClass, setSelectedDateSheetClass] = useState('');
  const [selectedQuestionPaperClass, setSelectedQuestionPaperClass] = useState('');
  const [dateSheetSearch, setDateSheetSearch] = useState('');
  const [questionSearch, setQuestionSearch] = useState('');
  const [previewRecord, setPreviewRecord] = useState(null);
  const [teachers] = useState(() => db.getAll('teachers'));
  const [students] = useState(() => db.getAll('students'));
  const [dateSheets, setDateSheets] = useState(() => db.getAll('exam_datesheets'));
  const [questionPapers, setQuestionPapers] = useState(() => db.getAll('exam_question_papers'));
  const [questionPaperDrafts, setQuestionPaperDrafts] = useState({});

  const teacher = useMemo(() => {
    if (!session || session.role !== 'teacher') return null;
    return teachers.find((entry) => String(entry.id) === String(session.teacherId)) || null;
  }, [session, teachers]);

  const teacherName = teacher
    ? `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || teacher.teacherSystemId || 'Teacher'
    : 'Teacher';
  const teacherSubjects = useMemo(() => {
    if (!teacher?.specialization) return [];
    return teacher.specialization
      .split(',')
      .map((subjectName) => subjectName.trim())
      .filter(Boolean);
  }, [teacher]);

  const assignedClasses = useMemo(() => {
    if (!teacher?.assignedClass) return [];
    return teacher.assignedClass
      .split(',')
      .map((className) => className.trim())
      .filter(Boolean)
      .sort(compareClassNames);
  }, [teacher]);

  const collegeClasses = useMemo(() => {
    const classSet = new Set([
      ...students.map((student) => student.assignedClass).filter(Boolean),
      ...dateSheets.map((record) => record.className).filter(Boolean),
    ]);

    return [...classSet].sort(compareClassNames);
  }, [dateSheets, students]);

  const filteredDateSheetClasses = useMemo(() => {
    const query = dateSheetSearch.trim().toLowerCase();
    return collegeClasses.filter((className) => {
      if (!query) return true;

      const classRecords = dateSheets.filter((record) => record.className === className);
      return (
        className?.toLowerCase().includes(query) ||
        classRecords.some((record) =>
          record.examType?.toLowerCase().includes(query) ||
          record.fileName?.toLowerCase().includes(query),
        )
      );
    });
  }, [collegeClasses, dateSheetSearch, dateSheets]);

  const selectedClassDateSheets = useMemo(() => {
    if (!selectedDateSheetClass) return [];

    return dateSheets
      .filter((record) => record.className === selectedDateSheetClass)
      .sort((a, b) => {
        const examTypeCompare = String(a.examType || '').localeCompare(String(b.examType || ''));
        if (examTypeCompare !== 0) return examTypeCompare;
        return String(a.fileName || '').localeCompare(String(b.fileName || ''));
      });
  }, [dateSheets, selectedDateSheetClass]);

  const availableQuestionPaperTitles = useMemo(() => {
    const titles = [
      ...dateSheets.map((record) => record.examType),
      ...questionPapers.map((record) => record.examTitle),
    ].filter(Boolean);

    return [...new Set(titles)].sort((a, b) => String(a).localeCompare(String(b)));
  }, [dateSheets, questionPapers]);

  const selectedQuestionClassSubjects = useMemo(() => {
    return teacherSubjects;
  }, [teacherSubjects]);

  const filteredQuestionPapers = useMemo(() => {
    const query = questionSearch.trim().toLowerCase();
    return questionPapers
      .filter((record) => {
        const classMatch = assignedClasses.includes(record.className);
        const subjectMatch = teacherSubjects.includes(record.subjectName);
        return classMatch && subjectMatch;
      })
      .filter((record) => {
        if (!query) return true;
        return (
          record.examTitle?.toLowerCase().includes(query) ||
          record.className?.toLowerCase().includes(query) ||
          record.subjectName?.toLowerCase().includes(query) ||
          record.fileName?.toLowerCase().includes(query)
        );
      })
      .sort((a, b) => {
        const examCompare = String(a.examTitle || '').localeCompare(String(b.examTitle || ''));
        if (examCompare !== 0) return examCompare;
        return compareClassNames(a.className || '', b.className || '');
      });
  }, [assignedClasses, questionPapers, questionSearch, teacherSubjects]);

  useEffect(() => {
    if (!session || session.role !== 'teacher') {
      navigate('/login');
    }
  }, [navigate, session]);

  useEffect(() => {
    if (!filteredDateSheetClasses.length) {
      if (selectedDateSheetClass) {
        setSelectedDateSheetClass('');
      }
      return;
    }

    if (!selectedDateSheetClass || !filteredDateSheetClasses.includes(selectedDateSheetClass)) {
      setSelectedDateSheetClass(filteredDateSheetClasses[0]);
    }
  }, [filteredDateSheetClasses, selectedDateSheetClass]);

  useEffect(() => {
    if (!assignedClasses.length) {
      if (selectedQuestionPaperClass) {
        setSelectedQuestionPaperClass('');
      }
      return;
    }

    if (!selectedQuestionPaperClass || !assignedClasses.includes(selectedQuestionPaperClass)) {
      setSelectedQuestionPaperClass(assignedClasses[0]);
    }
  }, [assignedClasses, selectedQuestionPaperClass]);

  const refreshExamRecords = () => {
    setDateSheets(db.getAll('exam_datesheets'));
    setQuestionPapers(db.getAll('exam_question_papers'));
  };

  const handleQuestionPaperBrowse = (className, subjectName, e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setQuestionPaperDrafts((current) => ({
        ...current,
        [buildQuestionDraftKey(className, subjectName)]: {
          ...(current[buildQuestionDraftKey(className, subjectName)] || {}),
          className,
          subjectName,
          uploadedBy: teacherName,
          fileName: file.name,
          fileData: String(reader.result || ''),
          fileType: file.type || 'application/octet-stream',
        },
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleQuestionDraftChange = (className, subjectName, value) => {
    setQuestionPaperDrafts((current) => ({
      ...current,
      [buildQuestionDraftKey(className, subjectName)]: {
        ...(current[buildQuestionDraftKey(className, subjectName)] || {}),
        className,
        subjectName,
        uploadedBy: teacherName,
        examTitle: value,
      },
    }));
  };

  const handleQuestionPaperSave = (className, subjectName) => {
    const draft = questionPaperDrafts[buildQuestionDraftKey(className, subjectName)];
    if (!draft?.fileData || !draft?.examTitle?.trim() || !className || !subjectName) return;

    db.save('exam_question_papers', {
      ...draft,
      examTitle: draft.examTitle.trim(),
      className: className.trim(),
      subjectName: subjectName.trim(),
      uploadedBy: teacherName,
    });

    setQuestionPaperDrafts((current) => ({
      ...current,
      [buildQuestionDraftKey(className, subjectName)]: {
        className,
        subjectName,
        uploadedBy: teacherName,
        examTitle: '',
        fileName: '',
        fileData: '',
        fileType: '',
      },
    }));
    refreshExamRecords();
  };

  if (!session || session.role !== 'teacher') return null;

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#f8fafc_0%,#eef7ff_46%,#f8fafc_100%)] text-slate-900">
      <div className="border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => activeSection === 'home' ? navigate('/teacher') : setActiveSection('home')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500 transition hover:border-indigo-300 hover:text-indigo-700"
            >
              <ArrowLeft size={14} />
              {activeSection === 'home' ? 'Back' : 'Back To Cards'}
            </button>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.28em] text-indigo-600">Teacher Examinations</p>
              <h1 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">Exam Desk For Teachers</h1>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-6 py-8 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-4xl bg-[linear-gradient(145deg,#312e81_0%,#1d4ed8_48%,#0f172a_100%)] px-7 py-8 text-white shadow-[0_30px_80px_-40px_rgba(30,41,59,0.8)] lg:px-10 lg:py-10">
          <div className="grid gap-8 lg:grid-cols-[1.08fr_0.92fr]">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-indigo-200">Teacher Exam Workspace</p>
              <h2 className="mt-4 max-w-3xl font-serif text-4xl font-black italic leading-none tracking-tight">
                Review college date sheets and your teaching-related exam records.
              </h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-indigo-50/80">
                This page keeps the teacher workflow read-only. Teachers can browse all class date sheets uploaded by the college, while question papers remain focused on the classes and subjects linked to {teacherName}.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <MetricCard label="Date Sheets" value={dateSheets.length} icon={CalendarDays} />
              <MetricCard label="Classes Covered" value={collegeClasses.length} icon={GraduationCap} />
              <MetricCard label="Question Papers" value={filteredQuestionPapers.length} icon={ScrollText} />
            </div>
          </div>
        </section>

        {activeSection === 'home' ? (
          <section className="mt-8 grid gap-5 md:grid-cols-2">
            <ActionCard
              icon={CalendarDays}
              title="Date Sheets"
              text="Open the class-wise examination date sheets uploaded by the college and browse every class in order."
              onClick={() => setActiveSection('datesheet')}
            />
            <ActionCard
              icon={ScrollText}
              title="Question Papers"
              text="View and upload question papers only for your own subject in the classes assigned to you."
              onClick={() => setActiveSection('questionpaper')}
            />
          </section>
        ) : null}

        {activeSection === 'datesheet' ? (
          <div className="mt-8 grid gap-8 xl:grid-cols-[0.76fr_1.24fr]">
            <Panel
              title="All College Classes"
              description="Teachers can only view class date sheets here. Uploading remains available only on the college examination page."
            >
              <div className="mt-6">
                <SearchInput value={dateSheetSearch} onChange={setDateSheetSearch} placeholder="Search class, exam type, file..." />
              </div>

              {filteredDateSheetClasses.length > 0 ? (
                <div className="mt-6 grid gap-3">
                  {filteredDateSheetClasses.map((className, index) => {
                    const classRecordCount = dateSheets.filter((record) => record.className === className).length;
                    const isActive = selectedDateSheetClass === className;

                    return (
                      <button
                        key={className}
                        type="button"
                        onClick={() => setSelectedDateSheetClass(className)}
                        className={`flex items-center justify-between rounded-[1.6rem] border px-4 py-4 text-left transition ${
                          isActive
                            ? 'border-indigo-300 bg-indigo-50 text-indigo-950'
                            : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-indigo-200 hover:bg-white'
                        }`}
                      >
                        <div className="min-w-0">
                          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700">
                            {String(index + 1).padStart(2, '0')}
                          </p>
                          <h4 className="mt-1 truncate text-lg font-black tracking-tight">{className}</h4>
                        </div>
                        <div className="shrink-0 rounded-2xl bg-white px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-slate-500 shadow-sm">
                          {classRecordCount} Sheet{classRecordCount === 1 ? '' : 's'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <EmptyState
                  icon={GraduationCap}
                  title="No classes found"
                  description="No class records or uploaded examination date sheets are available right now."
                />
              )}
            </Panel>

            <Panel
              title={selectedDateSheetClass ? `${selectedDateSheetClass} Date Sheet` : 'Class Date Sheet'}
              description="Click any class on the left to open the date sheet records uploaded by the college. Teachers cannot upload or edit these files."
            >
              {selectedDateSheetClass ? (
                selectedClassDateSheets.length > 0 ? (
                  <div className="mt-6 grid gap-5">
                    {selectedClassDateSheets.map((record) => (
                      <RecordCard key={record.id} icon={CalendarDays} title={record.examType || 'Exam type pending'} subtitle={record.className || 'Class pending'}>
                        <InfoPill icon={FileText} text={record.fileName || 'File missing'} />
                        <button
                          type="button"
                          onClick={() => setPreviewRecord(record)}
                          className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-700 transition hover:border-indigo-300 hover:text-indigo-700"
                        >
                          <Upload size={14} />
                          Open File
                        </button>
                      </RecordCard>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={CalendarDays}
                    title="Date sheet not uploaded"
                    description="The college has not uploaded a date sheet for this class yet."
                  />
                )
              ) : (
                <EmptyState
                  icon={CalendarDays}
                  title="Select a class"
                  description="Choose a class from the left side to view its uploaded examination date sheet."
                />
              )}
            </Panel>
          </div>
        ) : null}

        {activeSection === 'questionpaper' ? (
          <div className="mt-8 grid gap-8 xl:grid-cols-[0.76fr_1.24fr]">
            <Panel
              title="My Teaching Classes"
              description="Click a class to open the subjects you teach there. Upload is available only on your own subjects."
            >
              {assignedClasses.length > 0 ? (
                <div className="mt-6 grid gap-3">
                  {assignedClasses.map((className, index) => {
                    const isActive = selectedQuestionPaperClass === className;
                    const paperCount = filteredQuestionPapers.filter((record) => record.className === className).length;

                    return (
                      <button
                        key={className}
                        type="button"
                        onClick={() => setSelectedQuestionPaperClass(className)}
                        className={`flex items-center justify-between rounded-[1.6rem] border px-4 py-4 text-left transition ${
                          isActive
                            ? 'border-indigo-300 bg-indigo-50 text-indigo-950'
                            : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-indigo-200 hover:bg-white'
                        }`}
                      >
                        <div>
                          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700">
                            {String(index + 1).padStart(2, '0')}
                          </p>
                          <h4 className="mt-1 text-lg font-black tracking-tight">{className}</h4>
                        </div>
                        <div className="shrink-0 rounded-2xl bg-white px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-slate-500 shadow-sm">
                          {paperCount} Paper{paperCount === 1 ? '' : 's'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <EmptyState
                  icon={ScrollText}
                  title="No teaching classes found"
                  description="Assign classes to this teacher first, then the class-wise question paper upload view will appear here."
                />
              )}
            </Panel>

            <Panel
              title={selectedQuestionPaperClass ? `${selectedQuestionPaperClass} Subjects` : 'Class Subjects'}
              description="Each subject card below belongs to this teacher. Add an exam title, choose a file, and upload the paper for that subject."
            >
              <div className="mt-6">
                <SearchInput value={questionSearch} onChange={setQuestionSearch} placeholder="Search exam title, class, subject..." />
              </div>
              {selectedQuestionPaperClass && selectedQuestionClassSubjects.length > 0 ? (
                <div className="mt-8 grid gap-5">
                  {selectedQuestionClassSubjects.map((subjectName) => {
                    const draftKey = buildQuestionDraftKey(selectedQuestionPaperClass, subjectName);
                    const draft = questionPaperDrafts[draftKey] || {
                      examTitle: '',
                      fileName: '',
                      fileData: '',
                    };
                    const subjectPapers = filteredQuestionPapers.filter((record) => {
                      const matchesClass = record.className === selectedQuestionPaperClass;
                      const matchesSubject = record.subjectName === subjectName;
                      const query = questionSearch.trim().toLowerCase();

                      if (!matchesClass || !matchesSubject) return false;
                      if (!query) return true;

                      return (
                        record.examTitle?.toLowerCase().includes(query) ||
                        record.className?.toLowerCase().includes(query) ||
                        record.subjectName?.toLowerCase().includes(query) ||
                        record.fileName?.toLowerCase().includes(query)
                      );
                    });

                    return (
                      <article key={draftKey} className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
                        <div className="flex flex-col gap-5">
                          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                            <div>
                              <p className="text-[11px] font-black uppercase tracking-[0.18em] text-indigo-700">{selectedQuestionPaperClass}</p>
                              <h4 className="mt-1 text-xl font-black tracking-tight text-slate-950">{subjectName}</h4>
                              <p className="mt-2 text-sm font-semibold text-slate-500">Teacher: {teacherName}</p>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              <InfoPill icon={UserRound} text={teacherName} />
                              <InfoPill icon={ScrollText} text={`${subjectPapers.length} Uploaded`} />
                            </div>
                          </div>

                          <div className="grid gap-4 md:grid-cols-[1fr_auto]">
                            <CreativeInput
                              list="teacher-exam-title-options"
                              label="Exam Title"
                              value={draft.examTitle || ''}
                              onChange={(e) => handleQuestionDraftChange(selectedQuestionPaperClass, subjectName, e.target.value)}
                              placeholder="Mid Term Examination"
                            />
                            <div className="md:min-w-56">
                              <FileUploadField
                                label="Question Paper File"
                                fileName={draft.fileName}
                                onBrowse={(e) => handleQuestionPaperBrowse(selectedQuestionPaperClass, subjectName, e)}
                              />
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-3">
                            <button
                              type="button"
                              onClick={() => handleQuestionPaperSave(selectedQuestionPaperClass, subjectName)}
                              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-white transition hover:bg-indigo-700"
                            >
                              <Upload size={16} />
                              Upload Paper
                            </button>
                            <div className="inline-flex items-center rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-500">
                              {draft.fileName || 'No file selected'}
                            </div>
                          </div>

                          {subjectPapers.length > 0 ? (
                            <div className="grid gap-3 border-t border-slate-200 pt-4">
                              {subjectPapers.map((record) => (
                                <RecordCard key={record.id} icon={ScrollText} title={record.examTitle || 'Exam title pending'} subtitle={record.fileName || 'File missing'}>
                                  <InfoPill icon={FileText} text={record.className || 'Class pending'} />
                                  <InfoPill icon={UserRound} text={record.uploadedBy || 'Uploader pending'} />
                                  <button
                                    type="button"
                                    onClick={() => setPreviewRecord(record)}
                                    className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-700 transition hover:border-indigo-300 hover:text-indigo-700"
                                  >
                                    <Upload size={14} />
                                    Open File
                                  </button>
                                </RecordCard>
                              ))}
                            </div>
                          ) : (
                            <div className="rounded-[1.4rem] border border-dashed border-slate-300 bg-white px-5 py-8 text-center">
                              <p className="text-sm font-semibold text-slate-500">No paper uploaded yet for this subject in this class.</p>
                            </div>
                          )}
                        </div>
                      </article>
                    );
                  })}
                </div>
              ) : (
                <EmptyState
                  icon={ScrollText}
                  title="No subjects available"
                  description="Select a class to view the subjects taught by this teacher and upload papers subject-wise."
                />
              )}
              <datalist id="teacher-exam-title-options">
                {availableQuestionPaperTitles.map((examTitle) => (
                  <option key={examTitle} value={examTitle} />
                ))}
              </datalist>
            </Panel>
          </div>
        ) : null}
      </main>

      {previewRecord ? (
        <FilePreviewModal record={previewRecord} onClose={() => setPreviewRecord(null)} />
      ) : null}
    </div>
  );
};

const compareClassNames = (a, b) => {
  const left = getClassSortValue(a);
  const right = getClassSortValue(b);
  return left.rank - right.rank || left.section.localeCompare(right.section) || a.localeCompare(b);
};

const getClassSortValue = (className) => {
  const normalized = String(className || '').toLowerCase();
  const section = String(className || '').split('/')[1]?.trim() || '';

  if (normalized.includes('nursery')) return { rank: 0, section };
  if (normalized.includes('lkg')) return { rank: 1, section };
  if (normalized.includes('ukg')) return { rank: 2, section };

  const classMatch = normalized.match(/class\s*(\d+)/);
  if (classMatch) {
    return { rank: 2 + Number(classMatch[1]), section };
  }

  return { rank: 1000, section };
};

const isImageFile = (record) => {
  return record.fileType?.startsWith('image/') || /\.(png|jpe?g|gif|webp)$/i.test(record.fileName || '');
};

const isPdfFile = (record) => {
  return record.fileType === 'application/pdf' || /\.pdf$/i.test(record.fileName || '');
};

const isPreviewableFile = (record) => {
  return Boolean(record.fileData) && (isImageFile(record) || isPdfFile(record));
};

const buildQuestionDraftKey = (className, subjectName) => `${className}::${subjectName}`;

const MetricCard = ({ label, value, icon: Icon }) => (
  <div className="rounded-[1.6rem] border border-white/10 bg-white/5 p-5 backdrop-blur-sm">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-[11px] font-black uppercase tracking-[0.24em] text-indigo-50/80">{label}</p>
        <p className="mt-3 text-4xl font-black tracking-tight text-white">{value}</p>
      </div>
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-indigo-200/20 bg-indigo-200/10 text-indigo-50">
        <Icon size={20} />
      </div>
    </div>
  </div>
);

const ActionCard = ({ icon: Icon, title, text, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="group flex min-h-56 flex-col justify-between rounded-4xl border border-slate-200/80 bg-white p-6 text-left shadow-[0_20px_60px_-38px_rgba(15,23,42,0.45)] transition hover:-translate-y-1 hover:border-indigo-300 lg:p-8"
  >
    <div>
      <div className="flex items-start justify-between gap-5">
        <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-indigo-100 text-indigo-700 transition group-hover:bg-indigo-600 group-hover:text-white">
          <Icon size={24} />
        </div>
        <ArrowRight className="text-slate-300 transition group-hover:text-indigo-700" size={20} />
      </div>
      <h3 className="mt-7 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h3>
      <p className="mt-3 text-sm leading-7 text-slate-500">{text}</p>
    </div>
    <span className="mt-6 text-[11px] font-black uppercase tracking-[0.22em] text-indigo-700">Open Page</span>
  </button>
);

const Panel = ({ title, description, children }) => (
  <section className="mt-8 rounded-4xl border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-35px_rgba(15,23,42,0.35)] lg:p-8">
    <h3 className="font-serif text-2xl font-black italic tracking-tight text-slate-950">{title}</h3>
    <p className="mt-2 text-sm leading-7 text-slate-500">{description}</p>
    {children}
  </section>
);

const RecordCard = ({ icon: Icon, title, subtitle, children }) => (
  <article className="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-5">
    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-700">
          <Icon size={20} />
        </div>
        <div className="min-w-0">
          <h4 className="truncate text-lg font-black tracking-tight text-slate-950">{title}</h4>
          <p className="text-[11px] font-black uppercase tracking-[0.16em] text-indigo-700">{subtitle}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  </article>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="relative">
    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-12 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
    />
  </div>
);

const CreativeInput = ({ label, list, ...props }) => (
  <label className="block">
    <span className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">{label}</span>
    <input
      list={list}
      {...props}
      className="mt-2 w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
    />
  </label>
);

const CreativeSelect = ({ label, value, onChange, options, renderOptionLabel }) => (
  <label className="block">
    <span className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">{label}</span>
    <select
      value={value}
      onChange={onChange}
      className="mt-2 w-full rounded-2xl border-2 border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-4 focus:ring-indigo-100"
    >
      {options.map((option) => (
        <option key={option || 'blank-option'} value={option}>
          {renderOptionLabel ? renderOptionLabel(option) : option}
        </option>
      ))}
    </select>
  </label>
);

const StaticField = ({ label, value }) => (
  <div>
    <span className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">{label}</span>
    <div className="mt-2 rounded-2xl border-2 border-slate-200 bg-slate-100 px-4 py-3.5 text-sm font-semibold text-slate-700">
      {value || 'Not available'}
    </div>
  </div>
);

const FileUploadField = ({ label, fileName, onBrowse }) => (
  <label className="flex cursor-pointer flex-col rounded-[1.8rem] border-2 border-dashed border-slate-300 bg-slate-50 px-5 py-6 text-center transition hover:border-indigo-300 hover:bg-white">
    <span className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">{label}</span>
    <span className="mt-3 text-sm font-semibold text-slate-700">{fileName || 'Choose PDF, image, or document file'}</span>
    <span className="mt-2 text-xs font-semibold text-slate-400">Click here to browse a question paper file</span>
    <input type="file" className="hidden" onChange={onBrowse} />
  </label>
);

const InfoPill = ({ icon: Icon, text }) => (
  <div className="inline-flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">
    <Icon size={15} className="text-indigo-700" />
    <span>{text}</span>
  </div>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="mt-8 rounded-4xl border border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center">
    <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-slate-300 shadow-sm">
      <Icon size={34} />
    </div>
    <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">{title}</h4>
    <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">{description}</p>
  </div>
);

const FilePreviewModal = ({ record, onClose }) => {
  const canPreview = isPreviewableFile(record);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/70 px-4 py-6 backdrop-blur-sm">
      <div className="flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-4xl bg-white shadow-[0_30px_90px_-35px_rgba(15,23,42,0.75)]">
        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between lg:px-7">
          <div className="min-w-0">
            <p className="text-[11px] font-black uppercase tracking-[0.22em] text-indigo-700">{record.className || record.examTitle || 'Examination File'}</p>
            <h3 className="mt-1 truncate font-serif text-2xl font-black italic tracking-tight text-slate-950">{record.fileName || 'Uploaded file'}</h3>
          </div>
          <div className="flex items-center gap-2">
            {record.fileData ? (
              <a
                href={record.fileData}
                download={record.fileName || 'examination-file'}
                className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-white transition hover:bg-indigo-600"
                title="Download"
              >
                <Download size={18} />
              </a>
            ) : null}
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              title="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-auto bg-slate-100 p-4 lg:p-6">
          {canPreview ? (
            <div className="min-h-[65vh] overflow-hidden rounded-[1.6rem] border border-slate-200 bg-white">
              {isImageFile(record) ? (
                <img src={record.fileData} alt={record.fileName || 'Uploaded file'} className="mx-auto max-h-[72vh] w-auto max-w-full object-contain" />
              ) : (
                <iframe title={record.fileName || 'Uploaded file'} src={record.fileData} className="h-[72vh] w-full bg-white" />
              )}
            </div>
          ) : (
            <div className="flex min-h-[55vh] flex-col items-center justify-center rounded-[1.6rem] border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-indigo-100 text-indigo-700">
                <FileText size={34} />
              </div>
              <h4 className="mt-6 font-serif text-3xl font-black italic tracking-tight text-slate-950">Preview not available</h4>
              <p className="mt-3 max-w-md text-sm leading-7 text-slate-500">
                This file type cannot be previewed here. Use download to open the examination file.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TeacherExaminations;
