import React from 'react';
import { useNavigate } from 'react-router-dom';
import PlatformLayout from '../../components/platform/PlatformLayout';
const PlatformUsagePage=()=>{const navigate=useNavigate();return <PlatformLayout title="Platform Usage" subtitle="Aggregate usage is available per institute"><div className="rounded-2xl border border-slate-100 bg-white p-8 shadow-xl shadow-slate-200/30"><h2 className="font-serif text-2xl font-black italic">Institute Usage Directory</h2><button type="button" onClick={()=>navigate('/platform/institutes')} className="mt-6 rounded-xl bg-slate-950 px-5 py-3 text-xs font-black uppercase text-white">Select Institute</button></div></PlatformLayout>;};
export default PlatformUsagePage;
