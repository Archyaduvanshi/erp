import React from 'react';
import { useNavigate } from 'react-router-dom';
import { GraduationCap, LogOut } from 'lucide-react';
import { usePlatformAuth } from '../../context/PlatformAuthContext';

const PlatformLayout = ({ children, title, subtitle }) => {
  const { session, logout } = usePlatformAuth();
  const navigate = useNavigate();
  const signOut = () => logout().finally(() => navigate('/platform/login'));

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-100 bg-white">
        <div className="mx-auto flex min-h-20 max-w-screen-2xl items-center justify-between gap-5 px-5 py-4 md:px-10">
          <div className="flex min-w-0 items-center gap-6">
            <button type="button" onClick={() => navigate('/platform/dashboard')} className="flex shrink-0 items-center gap-3">
              <span className="rounded-lg bg-emerald-600 p-2 text-white"><GraduationCap size={20} /></span>
              <span className="hidden text-lg font-black uppercase italic text-emerald-800 sm:block">VidyantraErp</span>
            </button>
            <div className="min-w-0 border-l border-slate-100 pl-6">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-700">Platform Console</p>
              <h1 className="truncate font-serif text-xl font-black italic text-slate-950 md:text-2xl">{title}</h1>
              {subtitle && <p className="mt-1 hidden text-xs text-slate-500 lg:block">{subtitle}</p>}
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-4">
            <div className="hidden text-right md:block">
              <p className="text-xs font-black text-slate-700">{session?.displayName}</p>
              <span className="text-[9px] font-black uppercase tracking-widest text-emerald-700">Super Admin</span>
            </div>
            <button type="button" onClick={signOut} className="flex h-11 items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 text-xs font-black uppercase tracking-[0.12em] text-white shadow-lg shadow-rose-100">
              <LogOut size={16} /><span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-screen-2xl px-5 py-8 md:px-10">{children}</main>
    </div>
  );
};

export default PlatformLayout;
